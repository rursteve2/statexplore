StatExplore reproducibility bundle (1.3.6 (commit 090d120e691f))

Run in R (no network needed):  Rscript One_sample_t_test_3fc604c3e9c5.R   (from this folder), or source("One_sample_t_test_3fc604c3e9c5.R") from anywhere.
Data: One_sample_t_test_3fc604c3e9c5_data.csv (included: analysis columns only, exported with your consent)
R packages used by this script: effectsize (recorded versions: R R version 4.6.2 (2026-10-29 ucrt))
The script stops with a message if the data file differs from the exported one, if the analysed rows, outcome coding, design or grouping differ from the recorded model, or if n / logLik / AIC / BIC are not reproduced within abs 1e-4 + rel 1e-6.
Results and metadata in this folder are not anonymized. Treat the data file with the same care as the original data.
