# ---- required R packages (checked before anything runs) ----
sx_needed <- c("effectsize")
sx_missing <- sx_needed[!vapply(sx_needed, requireNamespace, logical(1), quietly = TRUE)]
if (length(sx_missing)) stop("Missing R packages: ", paste(sx_missing, collapse = ", "), ". Install them ",
  "(offline: install.packages('<file>.zip', repos = NULL)) and run this script again.", call. = FALSE)
dir.create("plots", showWarnings = FALSE)  # output folder for any plots
# ---- StatExplore helper functions ----
sx_item_mean <- function(d, min_valid) {
  n <- rowSums(!is.na(d)); out <- rowMeans(d, na.rm = TRUE); out[n < min_valid] <- NA_real_; out
}
sx_item_sum <- function(d) rowSums(d)  # NA when any item is missing
sx_log <- function(x) { out <- rep(NA_real_, length(x)); ok <- !is.na(x) & x > 0; out[ok] <- log(x[ok]); out }
sx_sqrt <- function(x) { out <- rep(NA_real_, length(x)); ok <- !is.na(x) & x >= 0; out[ok] <- sqrt(x[ok]); out }
sx_z <- function(x) (x - mean(x, na.rm = TRUE)) / stats::sd(x, na.rm = TRUE)
sx_center <- function(x) x - mean(x, na.rm = TRUE)
sx_binarize <- function(x, cutoff, strict) as.numeric(if (strict) x > cutoff else x >= cutoff)
sx_recode <- function(x, from, to, keep_other) {
  m <- match(x, from)
  out <- if (keep_other) as.numeric(x) else rep(NA_real_, length(x))
  out[!is.na(m)] <- to[m[!is.na(m)]]
  out
}
# Complete cases on the analysis variables, unused factor levels dropped.
sx_complete <- function(data, vars) {
  droplevels(data[stats::complete.cases(data[, vars, drop = FALSE]), vars, drop = FALSE])
}
# Shapiro-Wilk is defined for 3 <= n <= 5000; otherwise not reported.
sx_shapiro <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) < 3 || length(x) > 5000 || stats::var(x) == 0) return(c(W = NA_real_, p = NA_real_))
  t <- stats::shapiro.test(x); c(W = unname(t$statistic), p = t$p.value)
}
# Proportional-odds check for an ordinal::clm fit: the tests of ordinal::nominal_test() (each term in turn made
# category-specific, likelihood-ratio test against the fitted model) plus a global test (all terms at once).
# nominal_test() refits through update(), which cannot see local data and turns every failure into a silent NA;
# here each refit is explicit and a term that cannot be tested carries the specific reason.
sx_po_check <- function(fit, form, data, link = "logit") {
  y <- data[[all.vars(form)[1]]]
  ll0 <- as.numeric(stats::logLik(fit))
  one <- function(label, nom, cells_check = TRUE) {
    w <- character()
    m <- withCallingHandlers(
      tryCatch(ordinal::clm(form, nominal = nom, data = data, link = link), error = function(e) e),
      warning = function(x) { w <<- c(w, conditionMessage(x)); invokeRestart("muffleWarning") })
    out <- data.frame(term = label, df = NA_real_, LRT = NA_real_, p = NA_real_,
        status = "not tested",
                      reason = "", stringsAsFactors = FALSE)
    vars <- intersect(all.vars(nom), names(data))
    fac <- vars[vapply(data[vars], is.factor, logical(1))]
    notes <- character()
    if (cells_check && length(fac)) {
      cells <- table(interaction(data[fac], drop = TRUE), y)
      if (any(cells == 0)) notes <- c(notes, sprintf(
        "sparse: %d of %d outcome-by-category cells are empty", sum(cells == 0), length(cells)))
    }
    if (inherits(m, "error")) {
      out$reason <- paste(c(paste("the category-specific model could not be fitted:",
          conditionMessage(m)), notes),
                          collapse = "; ")
      return(out)
    }
    code <- as.integer(m$convergence$code)
    msgs <- unique(gsub("\\s+", " ", trimws(c(m$convergence$messages, m$convergence$alg.message))))
    # the location coefficients a nominal term replaces are aliased by design; only threshold-side aliasing counts
    al <- sum(m$aliased$alpha)
    if (al) notes <- c(notes, sprintf("%d category-specific coefficient(s) not identifiable (aliased) and dropped",
        al))
    w <- unique(gsub("\\s+", " ", trimws(sub("^\\(\\d+\\)\\s*", "", w))))
    w <- w[!vapply(w, function(x) any(startsWith(x, msgs) | startsWith(msgs, x)), logical(1))]
    if (length(w)) notes <- c(notes, paste("warning:", w))
    df <- m$edf - fit$edf
    lr <- 2 * (as.numeric(stats::logLik(m)) - ll0)
    if (is.na(code) || code < 0L) {
      out$reason <- paste(c(paste("the category-specific model did not converge:",
          paste(msgs, collapse = "; ")), notes),
                          collapse = "; ")
    } else if (df <= 0) {
      out$reason <- paste(c("no estimable category-specific parameters beyond the fitted model (rank deficient)",
                            notes), collapse = "; ")
    } else if (!is.finite(lr) || lr < -1e-6) {
      out$reason <- paste(c(sprintf("the category-specific fit has a lower likelihood (LR = %.4g): optimizer failure",
          lr),
                            notes), collapse = "; ")
    } else {
      out$df <- df; out$LRT <- max(lr, 0); out$p <- stats::pchisq(max(lr,
          0), df, lower.tail = FALSE)
      if (code == 0L) {
        out$status <- "tested"
      } else {
        # code 1: the likelihood reached its maximum but some parameters are not uniquely determined, so the
        # parameter count (df) is uncertain; ordinal::nominal_test reports these values without comment
        out$status <- "approximate"
        notes <- c(paste0("df uncertain: ", paste(msgs, collapse = "; ")), notes)
      }
      out$reason <- paste(notes, collapse = "; ")
    }
    out
  }
  terms <- attr(stats::terms(form), "term.labels")
  if (!length(terms)) return(data.frame(term = "(none)", df = NA_real_, LRT = NA_real_,
      p = NA_real_,
    status = "not tested", reason = "intercept-only model: there is no effect to make category-specific"))
  rows <- lapply(terms, function(tm) one(tm, stats::as.formula(paste("~", tm))))
  if (length(terms) > 1) rows[[length(rows) + 1]] <- one("All terms (global test)",
    stats::as.formula(paste("~", paste(terms, collapse = " + "))), cells_check = FALSE)
  out <- do.call(rbind, rows)
  # STAT-26: an interaction term made category-specific frees every cell of its design; when that uses as many
  # parameters as the global test it IS the global alternative, not a separate test of the interaction
  if (length(terms) > 1) {
    g <- out$df[nrow(out)]
    span <- seq_len(nrow(out) - 1)[grepl(":", out$term[-nrow(out)]) & is.finite(out$df[-nrow(out)]) &
                                   out$df[-nrow(out)] == g]
    for (i in span) out$reason[i] <- paste(c(if (nzchar(out$reason[i])) out$reason[i],
      "same df as the global test: this interaction test spans the global alternative (cell-based parameterization), not an independent test of the interaction"), collapse = "; ")
  }
  out
}
# Information criteria. Native AIC()/BIC() for every engine except mmrm: its own criteria count only covariance
# parameters under REML and use n = subjects, so it is put on nlme's convention (k = fixed + covariance parameters,
# n = observations, n - p under REML) and structures fitted by different packages share one penalty.
sx_ic <- function(m) {
  ll <- stats::logLik(m)
  if (inherits(m, "mmrm")) {
    p <- length(m$beta_est); k <- p + length(m$theta_est); n <- length(stats::residuals(m))
    nb <- if (isTRUE(m$reml)) n - p else n
    return(list(aic = -2 * as.numeric(ll) + 2 * k, bic = -2 * as.numeric(ll) + log(nb) * k,
        k = k, n_bic = nb,
                basis = "nlme convention (mmrm's own BIC differs)"))
  }
  nb <- attr(ll, "nobs")
  if (is.null(nb)) nb <- tryCatch(stats::nobs(m), error = function(e) NA_real_)
  list(aic = stats::AIC(m), bic = stats::BIC(m), k = attr(ll, "df"), n_bic = as.numeric(nb),
      basis = "native")
}
# Package a data frame as a result table.
sx_table <- function(name, df, notes = "", row_names = NULL) {
  df <- as.data.frame(df, stringsAsFactors = FALSE, check.names = FALSE)
  list(name = name, columns = I(names(df)),
       data = lapply(df, function(col) if (is.factor(col)) I(as.character(col)) else I(col)),
       row_names = I(as.character(row_names)), notes = notes)
}
# ---- StatExplore: model identity fingerprints (schema 2, SHA-256) ----
# Canonical rows = analysed source rows sorted by row number; every fingerprint is computed in that order, so the
# fitting order does not change it. Values are hashed as exact IEEE doubles; text with length prefixes.
sx_sha_raw <- function(writer) { tf <- tempfile(); con <- file(tf, "wb"); on.exit(unlink(tf))
  tryCatch(writer(con), finally = close(con)); unname(tools::sha256sum(tf)) }
sx_put_txt <- function(con, x) { x <- enc2utf8(as.character(x)); writeBin(as.integer(length(x)),
    con, size = 4)
  # vectorised: every string as <byte length>:<bytes>, one write (length prefixes keep it unambiguous)
  writeBin(charToRaw(paste0(nchar(x, type = "bytes"), ":", x, collapse = "")), con) }
sx_put_num <- function(con, x) { x <- as.double(x); writeBin(as.integer(length(x)), con, size = 4)
  writeBin(is.na(x), con, size = 1); writeBin(ifelse(is.na(x), 0, x), con,
      size = 8, endian = "little") }
sx_canon_names <- function(nm) vapply(strsplit(gsub("sx_timef", "sx_time", nm,
    fixed = TRUE), ":", fixed = TRUE),
  function(p) paste(sort(p), collapse = ":"), "")
sx_ident_cache <- new.env()   # row / response / grouping fingerprints of the last sample (recomputed when it changes)
sx_identity <- function(d, fixed, response, groups = character()) {
  rn <- rownames(d); y0 <- d[[response]]; g0 <- lapply(groups, function(g) d[[g]])
  rid <- suppressWarnings(as.numeric(rn))
  o <- if (anyNA(rid)) order(rn) else order(rid)
  X <- stats::model.matrix(stats::delete.response(stats::terms(fixed)), d[seq_len(min(nrow(d),
      2L)), , drop = FALSE])
  # (only the column names are needed: they encode the terms, coding and reference levels; values are hashed per
  # variable below)
  cn <- sx_canon_names(colnames(X)); ix <- order(cn)
  k <- sx_ident_cache
  if (!(identical(k$rn, rn) && identical(k$y, y0) && identical(k$g, g0))) {
    dc <- d[o, c(response, groups), drop = FALSE]
    y <- dc[[response]]
    k$rows <- sx_sha_raw(function(con) sx_put_txt(con, rn[o]))
    k$rows_ordered <- sx_sha_raw(function(con) sx_put_txt(con, rn))
    k$response <- sx_sha_raw(function(con) { if (is.factor(y)) { sx_put_txt(con,
        levels(y)); sx_put_num(con, as.integer(y)) }
                                             else sx_put_num(con, y) })
    k$groups <- sx_sha_raw(function(con) for (g in groups) { f <- dc[[g]]   # partitions only: names and labels never enter
      sx_put_num(con, match(as.character(f), unique(as.character(f)))) })
    k$rn <- rn; k$y <- y0; k$g <- g0
  }
  # design: the canonical design-column names (terms, coding, reference levels) + the SHA-256 of every variable the
  # design uses (values in canonical row order; factors as level labels + codes). X is an exact function of these,
  # so this equals a hash of the realized matrix while hashing only a few bytes per model (variables are cached).
  vars <- intersect(all.vars(stats::delete.response(stats::terms(fixed))), names(d))
  vh <- vapply(vars, function(v) {
    col <- d[[v]]; e <- k$vars[[v]]
    if (!is.null(e) && identical(e$rn, rn) && identical(e$col, col)) return(e$sha)
    co <- col[o]
    sha <- sx_sha_raw(function(con) { if (is.factor(co)) { sx_put_txt(con,
        levels(co)); sx_put_num(con, as.integer(co)) }
                                       else sx_put_num(con, co) })
    if (is.null(k$vars)) k$vars <- list()
    k$vars[[v]] <- list(rn = rn, col = col, sha = sha)
    sha
  }, "")
  vn <- sx_canon_names(names(vh)); vo <- order(vn)
  list(schema = 2L, algorithm = "sha256", n = nrow(d), rows = k$rows, rows_ordered = k$rows_ordered,
    response = k$response,
    design = sx_sha_raw(function(con) { sx_put_txt(con, cn[ix]); sx_put_txt(con,
        vn[vo]); sx_put_txt(con, unname(vh)[vo]) }),
    groups = k$groups, design_columns = I(cn[ix]))
}

# ---- StatExplore: data preparation ----
# Source file: "scores.csv"
# Values declared as user-missing in the source were exported as NA.
sx_data_file <- "One_sample_t_test_3fc604c3e9c5_data.csv"  # exported with this script (analysis columns only); edit if you move it
if (!file.exists(sx_data_file)) {  # source("analysis.R") from another folder: look next to the script
  sx_here <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) NA_character_)
  if (!is.na(sx_here) && file.exists(file.path(sx_here, sx_data_file))) sx_data_file <- file.path(sx_here,
      sx_data_file)
}
if (!file.exists(sx_data_file)) stop("Data file not found: put ", sx_data_file,
    " next to this script or set sx_data_file.")
sx_data_sha256 <- "1bb4dfe6c9c65522308fc5f42c0fa4487645f939257fdfbdb030804fc47b7030"  # SHA-256 of One_sample_t_test_3fc604c3e9c5_data.csv as exported (see One_sample_t_test_3fc604c3e9c5_manifest.json)
if (!isTRUE(get0("sx_skip_checksum")) && !identical(unname(tools::sha256sum(sx_data_file)),
    sx_data_sha256))
  stop("The data file ", sx_data_file, " is not the file exported with this script (SHA-256 differs). ",
       "Use the exported file, or set sx_skip_checksum <- TRUE before source() to run anyway (the run is then ",
       "UNVERIFIED and is not a reproduction).", call. = FALSE)
if (isTRUE(get0("sx_skip_checksum"))) message("WARNING: the data checksum was skipped - this run is UNVERIFIED.")
sx_raw <- utils::read.csv(
  sx_data_file, na.strings = "", fileEncoding = "UTF-8", check.names = FALSE,
  colClasses = c(
    v001 = "numeric",
    sx_split = "character"
  )
)
sx_result <- list(n_raw = nrow(sx_raw))
# Internal names (v001, ...) -> variable names
sx_names <- c(
    v001 = "score"
)
dat <- sx_raw
# Holdout: 25% of rows reserved (seed 2); exploration uses the training rows only
sx_holdout_dat <- dat[dat$sx_split == "holdout", , drop = FALSE]
dat <- dat[dat$sx_split == "train", , drop = FALSE]
sx_result <- list(n_rows = nrow(dat), n_cols = ncol(dat))

# ---- StatExplore: analysis ----
sx_used <- c("v001")
sx_d <- sx_complete(dat, sx_used)
if (nrow(sx_d) < 3) stop("Fewer than 3 complete cases for these variables.")
sx_x <- sx_d$v001
sx_tt <- stats::t.test(sx_x, mu = 0.0, alternative = "two.sided", conf.level = 0.95)
sx_es <- effectsize::cohens_d(sx_x, mu = 0.0, ci = 0.95)
sx_g <- effectsize::hedges_g(sx_x, mu = 0.0, ci = 0.95)
sx_sw <- sx_shapiro(sx_x)
sx_result <- list(tables = list(
  sx_table("One-sample t-test", data.frame(n = length(sx_x), mean = mean(sx_x),
      sd = stats::sd(sx_x),
    test_value = 0.0, t = unname(sx_tt$statistic), df = unname(sx_tt$parameter),
    p = sx_tt$p.value, ci_low = sx_tt$conf.int[1], ci_high = sx_tt$conf.int[2]),
    notes = paste0("CI is for the mean (", sx_tt$alternative, ").")),
  sx_table("Effect size", data.frame(measure = c("Cohen's d", "Hedges' g"),
    estimate = c(sx_es$Cohens_d, sx_g$Hedges_g), ci_low = c(sx_es$CI_low, sx_g$CI_low),
    ci_high = c(sx_es$CI_high, sx_g$CI_high)), notes = "d = (mean - test value) / SD; two-sided CI."),
  sx_table("Assumption check", data.frame(check = "Shapiro-Wilk normality", W = sx_sw[["W"]],
    p = sx_sw[["p"]]), notes = "Reported for 3 <= n <= 5000. With large n, small deviations are 'significant'.")),
  n_used = nrow(sx_d), n_excluded = nrow(dat) - nrow(sx_d))

# ---- write the result so it can be compared with StatExplore ----
jsonlite::write_json(sx_result, "result_3fc604c3e9c5.json", auto_unbox = TRUE, digits = I(17), null = "null", na = "null", force = TRUE)
