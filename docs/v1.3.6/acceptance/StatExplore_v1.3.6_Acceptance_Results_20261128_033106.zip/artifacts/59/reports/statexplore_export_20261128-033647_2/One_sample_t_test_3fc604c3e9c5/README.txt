StatExplore reproducibility bundle (1.3.6 (commit 090d120e691f))

Run in R (no network needed):  Rscript One_sample_t_test_3fc604c3e9c5.R   (from this folder), or source("One_sample_t_test_3fc604c3e9c5.R") from anywhere.
Data: One_sample_t_test_3fc604c3e9c5_data.csv (NOT included - code-only bundle: place the analysis-columns file here; its SHA-256 must be 1bb4dfe6c9c65522308fc5f42c0fa4487645f939257fdfbdb030804fc47b7030)
R packages used by this script: effectsize (recorded versions: R R version 4.6.2 (2026-10-29 ucrt))
The script stops with a message if the data file differs from the exported one, if the analysed rows, outcome coding, design or grouping differ from the recorded model, or if n / logLik / AIC / BIC are not reproduced within abs 1e-4 + rel 1e-6.
Results and metadata in this folder are not anonymized.
