# StatExplore audit report — search 769a28943ba6

Generated 2026-11-28T08:36:46+00:00 by StatExplore 1.3.6 (fit rules 4, audit schema 3).

## Search
- Status: Complete — every candidate in the defined search space was evaluated or classified invalid
- Fit identity: `9d2246e550d91a2a9e77ba151b186fecf0734b2afdbe3a6b68e0cbdbbd31a6d3`; data signature `86f2c8977182b62786920860e5acf523302b09a49824fd8fd669cdcafb8383ad`
- Resume: the search is complete
- Candidates: 1 attempted of 1 declared (grammar 2; the current grammar 4 defines 1 for these settings; strategy time, mode C); 0 after the stop point; 0 reused fits
- Candidate order: GROUP; required: none
- Budgets: run 1: 50000 models / 30.0 min (candidates 0–0) — each continuation evaluates up to its own budget of further models
- Multiplicity: BH within each test-type family, alpha = 0.05

## Data analysed by this search (historical record)
- Source file: unknown (not recorded by the version that ran this search) (source-file SHA-256 `3586bd714b9918393bfbc23c74820ae7dfae2ab2899df60e2050b0088e180210`)
- Analysed-content signature `86f2c8977182b62786920860e5acf523302b09a49824fd8fd669cdcafb8383ad`; fit identity `9d2246e550d91a2a9e77ba151b186fecf0734b2afdbe3a6b68e0cbdbbd31a6d3`
- Shared sample: 960

## Export-time project context (not the analysed data unless stated)
- StatExplore_Test50E_ModifiedValues.csv (SHA-256 `8b7d2a4fc8075c74791cc2498f9b1965037694366c43c0e55d1a0ee90269478c`): DIFFERS from the analysed data: the source data file differs from the one the search used; this search was recorded with data identity schema 2 (StatExplore 1.3.5 or earlier: source file hash + metadata), which cannot prove which imported values it analysed (for example which worksheet of a workbook); its results stay viewable as history, but they are not reused, resumed or reproduced as verified

## Environment
- R R version 4.6.2 (2026-10-29 ucrt); packages: jsonlite 2.0.0, detectseparation 0.4.0, lme4 2.1.0, ordinal 2026.7.26, nnet 7.3.21, stats 4.6.2, nlme 3.1.171, mmrm 0.3.19, geepack 1.3.13

## Hypotheses (first 50 by log p)

| test | label | statistic | df | log10 p | adj. p | family | status |
|---|---|---|---|---|---|---|---|
| 0.0 | TIME × GROUP | 63.52091220094371 | 1.0 | -14.799 | 1.586733858179841e-15 | 1 | tested |

## Limitations
- Exploratory search: adjusted p-values are within each test-type family of THIS search; provisional when the search is incomplete.
- Rows fitted under older fit rules are historical evidence and are not reused.
- Selection frequencies are not probabilities that a hypothesis is true.
