Validation status: PARTIAL (fit budget reached: 6 of 6 model-fitting invocations used; 1 part(s) stopped by the budget and 0 planned part(s) not run (finished parts are kept; a part stopped by the budget is never scored))
Target: New independent observations — rows are the sampling units (only for searches without repeated measures).
Procedure: Whole selection pipeline (search repeated inside each training part); selection rule: Smallest training p-value (natural-log tail) of the candidate's primary test (the search's discovery ranking); exact ties: lower candidate index.
Candidate pool: the whole declared search space (3 candidates).
Search: 12dea8f1e2b6 (fit identity d3ce1fe4e7954ea7…); validation run 85681b09765d.
Modes: Holdout; holdout 20%, K = 5, repeats = 1, B = 200, seed = 5.
Execution: 1 of 1 planned parts committed (1 of 1 chunks); 1 stopped by the fit budget.
This is a predictive check of the stated target, separate from the discovery p-values; it is not a confirmatory test, and bootstrap selection frequencies are not probabilities that a hypothesis is true.

Files: validation_reproduce.R (complete reproduction with self-checks, only with verified data), execution_ledger.csv (planned / committed / not run parts), candidate_trace.csv (every candidate in every training part / draw), bootstrap_estimands.csv, realized_sizes.csv, split_manifest.csv (the PLANNED fold of every analysed row per split; fold 0 = training only), bootstrap_draws.csv (planned draws: draw IDs and original IDs), predictions.csv (held-out rows), folds.csv, performance.csv, stability.csv, validation_code.R, bundle_inventory.json.
