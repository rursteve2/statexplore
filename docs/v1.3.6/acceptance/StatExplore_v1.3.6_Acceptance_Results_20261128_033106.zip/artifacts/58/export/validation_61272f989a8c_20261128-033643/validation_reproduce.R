# Participant IDs in the data file are order-preserving codes (1, 2, ...), not the original IDs; grouping, row order and results are unchanged.
# ---- required R packages (checked before anything runs) ----
sx_needed <- c("Matrix", "detectseparation", "geepack", "lme4", "mmrm", "nlme", "nnet", "ordinal")
sx_missing <- sx_needed[!vapply(sx_needed, requireNamespace, logical(1), quietly = TRUE)]
if (length(sx_missing)) stop("Missing R packages: ", paste(sx_missing, collapse = ", "), ". Install them ",
  "(offline: install.packages('<file>.zip', repos = NULL)) and run this script again.", call. = FALSE)
dir.create("plots", showWarnings = FALSE)  # output folder for any plots
# ==== StatExplore AMD validation: complete reproduction ====
# Run from the exported folder (Rscript validation_reproduce.R). It needs the data file named in the data-load
# section and verifies its results against the CSV files StatExplore exported (same folder).
# ---- StatExplore helper functions ----
sx_item_mean <- function(d, min_valid) {
  n <- rowSums(!is.na(d)); out <- rowMeans(d, na.rm = TRUE); out[n < min_valid] <- NA_real_; out
}
sx_item_sum <- function(d) rowSums(d)  # NA when any item is missing
sx_log <- function(x) { out <- rep(NA_real_, length(x)); ok <- !is.na(x) & x > 0; out[ok] <- log(x[ok]); out }
sx_sqrt <- function(x) { out <- rep(NA_real_, length(x)); ok <- !is.na(x) & x >= 0; out[ok] <- sqrt(x[ok]); out }
sx_z <- function(x) (x - mean(x, na.rm = TRUE)) / stats::sd(x, na.rm = TRUE)
sx_center <- function(x) x - mean(x, na.rm = TRUE)
sx_binarize <- function(x, cutoff, strict) as.numeric(if (strict) x > cutoff else x >= cutoff)
sx_recode <- function(x, from, to, keep_other) {
  m <- match(x, from)
  out <- if (keep_other) as.numeric(x) else rep(NA_real_, length(x))
  out[!is.na(m)] <- to[m[!is.na(m)]]
  out
}
# Complete cases on the analysis variables, unused factor levels dropped.
sx_complete <- function(data, vars) {
  droplevels(data[stats::complete.cases(data[, vars, drop = FALSE]), vars, drop = FALSE])
}
# Shapiro-Wilk is defined for 3 <= n <= 5000; otherwise not reported.
sx_shapiro <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) < 3 || length(x) > 5000 || stats::var(x) == 0) return(c(W = NA_real_, p = NA_real_))
  t <- stats::shapiro.test(x); c(W = unname(t$statistic), p = t$p.value)
}
# Proportional-odds check for an ordinal::clm fit: the tests of ordinal::nominal_test() (each term in turn made
# category-specific, likelihood-ratio test against the fitted model) plus a global test (all terms at once).
# nominal_test() refits through update(), which cannot see local data and turns every failure into a silent NA;
# here each refit is explicit and a term that cannot be tested carries the specific reason.
sx_po_check <- function(fit, form, data, link = "logit") {
  y <- data[[all.vars(form)[1]]]
  ll0 <- as.numeric(stats::logLik(fit))
  one <- function(label, nom, cells_check = TRUE) {
    w <- character()
    m <- withCallingHandlers(
      tryCatch(ordinal::clm(form, nominal = nom, data = data, link = link), error = function(e) e),
      warning = function(x) { w <<- c(w, conditionMessage(x)); invokeRestart("muffleWarning") })
    out <- data.frame(term = label, df = NA_real_, LRT = NA_real_, p = NA_real_,
        status = "not tested",
                      reason = "", stringsAsFactors = FALSE)
    vars <- intersect(all.vars(nom), names(data))
    fac <- vars[vapply(data[vars], is.factor, logical(1))]
    notes <- character()
    if (cells_check && length(fac)) {
      cells <- table(interaction(data[fac], drop = TRUE), y)
      if (any(cells == 0)) notes <- c(notes, sprintf(
        "sparse: %d of %d outcome-by-category cells are empty", sum(cells == 0), length(cells)))
    }
    if (inherits(m, "error")) {
      out$reason <- paste(c(paste("the category-specific model could not be fitted:",
          conditionMessage(m)), notes),
                          collapse = "; ")
      return(out)
    }
    code <- as.integer(m$convergence$code)
    msgs <- unique(gsub("\\s+", " ", trimws(c(m$convergence$messages, m$convergence$alg.message))))
    # the location coefficients a nominal term replaces are aliased by design; only threshold-side aliasing counts
    al <- sum(m$aliased$alpha)
    if (al) notes <- c(notes, sprintf("%d category-specific coefficient(s) not identifiable (aliased) and dropped",
        al))
    w <- unique(gsub("\\s+", " ", trimws(sub("^\\(\\d+\\)\\s*", "", w))))
    w <- w[!vapply(w, function(x) any(startsWith(x, msgs) | startsWith(msgs, x)), logical(1))]
    if (length(w)) notes <- c(notes, paste("warning:", w))
    df <- m$edf - fit$edf
    lr <- 2 * (as.numeric(stats::logLik(m)) - ll0)
    if (is.na(code) || code < 0L) {
      out$reason <- paste(c(paste("the category-specific model did not converge:",
          paste(msgs, collapse = "; ")), notes),
                          collapse = "; ")
    } else if (df <= 0) {
      out$reason <- paste(c("no estimable category-specific parameters beyond the fitted model (rank deficient)",
                            notes), collapse = "; ")
    } else if (!is.finite(lr) || lr < -1e-6) {
      out$reason <- paste(c(sprintf("the category-specific fit has a lower likelihood (LR = %.4g): optimizer failure",
          lr),
                            notes), collapse = "; ")
    } else {
      out$df <- df; out$LRT <- max(lr, 0); out$p <- stats::pchisq(max(lr,
          0), df, lower.tail = FALSE)
      if (code == 0L) {
        out$status <- "tested"
      } else {
        # code 1: the likelihood reached its maximum but some parameters are not uniquely determined, so the
        # parameter count (df) is uncertain; ordinal::nominal_test reports these values without comment
        out$status <- "approximate"
        notes <- c(paste0("df uncertain: ", paste(msgs, collapse = "; ")), notes)
      }
      out$reason <- paste(notes, collapse = "; ")
    }
    out
  }
  terms <- attr(stats::terms(form), "term.labels")
  if (!length(terms)) return(data.frame(term = "(none)", df = NA_real_, LRT = NA_real_,
      p = NA_real_,
    status = "not tested", reason = "intercept-only model: there is no effect to make category-specific"))
  rows <- lapply(terms, function(tm) one(tm, stats::as.formula(paste("~", tm))))
  if (length(terms) > 1) rows[[length(rows) + 1]] <- one("All terms (global test)",
    stats::as.formula(paste("~", paste(terms, collapse = " + "))), cells_check = FALSE)
  out <- do.call(rbind, rows)
  # STAT-26: an interaction term made category-specific frees every cell of its design; when that uses as many
  # parameters as the global test it IS the global alternative, not a separate test of the interaction
  if (length(terms) > 1) {
    g <- out$df[nrow(out)]
    span <- seq_len(nrow(out) - 1)[grepl(":", out$term[-nrow(out)]) & is.finite(out$df[-nrow(out)]) &
                                   out$df[-nrow(out)] == g]
    for (i in span) out$reason[i] <- paste(c(if (nzchar(out$reason[i])) out$reason[i],
      "same df as the global test: this interaction test spans the global alternative (cell-based parameterization), not an independent test of the interaction"), collapse = "; ")
  }
  out
}
# Information criteria. Native AIC()/BIC() for every engine except mmrm: its own criteria count only covariance
# parameters under REML and use n = subjects, so it is put on nlme's convention (k = fixed + covariance parameters,
# n = observations, n - p under REML) and structures fitted by different packages share one penalty.
sx_ic <- function(m) {
  ll <- stats::logLik(m)
  if (inherits(m, "mmrm")) {
    p <- length(m$beta_est); k <- p + length(m$theta_est); n <- length(stats::residuals(m))
    nb <- if (isTRUE(m$reml)) n - p else n
    return(list(aic = -2 * as.numeric(ll) + 2 * k, bic = -2 * as.numeric(ll) + log(nb) * k,
        k = k, n_bic = nb,
                basis = "nlme convention (mmrm's own BIC differs)"))
  }
  nb <- attr(ll, "nobs")
  if (is.null(nb)) nb <- tryCatch(stats::nobs(m), error = function(e) NA_real_)
  list(aic = stats::AIC(m), bic = stats::BIC(m), k = attr(ll, "df"), n_bic = as.numeric(nb),
      basis = "native")
}
# Package a data frame as a result table.
sx_table <- function(name, df, notes = "", row_names = NULL) {
  df <- as.data.frame(df, stringsAsFactors = FALSE, check.names = FALSE)
  list(name = name, columns = I(names(df)),
       data = lapply(df, function(col) if (is.factor(col)) I(as.character(col)) else I(col)),
       row_names = I(as.character(row_names)), notes = notes)
}
# ---- StatExplore: model identity fingerprints (schema 2, SHA-256) ----
# Canonical rows = analysed source rows sorted by row number; every fingerprint is computed in that order, so the
# fitting order does not change it. Values are hashed as exact IEEE doubles; text with length prefixes.
sx_sha_raw <- function(writer) { tf <- tempfile(); con <- file(tf, "wb"); on.exit(unlink(tf))
  tryCatch(writer(con), finally = close(con)); unname(tools::sha256sum(tf)) }
sx_put_txt <- function(con, x) { x <- enc2utf8(as.character(x)); writeBin(as.integer(length(x)),
    con, size = 4)
  # vectorised: every string as <byte length>:<bytes>, one write (length prefixes keep it unambiguous)
  writeBin(charToRaw(paste0(nchar(x, type = "bytes"), ":", x, collapse = "")), con) }
sx_put_num <- function(con, x) { x <- as.double(x); writeBin(as.integer(length(x)), con, size = 4)
  writeBin(is.na(x), con, size = 1); writeBin(ifelse(is.na(x), 0, x), con,
      size = 8, endian = "little") }
sx_canon_names <- function(nm) vapply(strsplit(gsub("sx_timef", "sx_time", nm,
    fixed = TRUE), ":", fixed = TRUE),
  function(p) paste(sort(p), collapse = ":"), "")
sx_ident_cache <- new.env()   # row / response / grouping fingerprints of the last sample (recomputed when it changes)
sx_identity <- function(d, fixed, response, groups = character()) {
  rn <- rownames(d); y0 <- d[[response]]; g0 <- lapply(groups, function(g) d[[g]])
  rid <- suppressWarnings(as.numeric(rn))
  o <- if (anyNA(rid)) order(rn) else order(rid)
  X <- stats::model.matrix(stats::delete.response(stats::terms(fixed)), d[seq_len(min(nrow(d),
      2L)), , drop = FALSE])
  # (only the column names are needed: they encode the terms, coding and reference levels; values are hashed per
  # variable below)
  cn <- sx_canon_names(colnames(X)); ix <- order(cn)
  k <- sx_ident_cache
  if (!(identical(k$rn, rn) && identical(k$y, y0) && identical(k$g, g0))) {
    dc <- d[o, c(response, groups), drop = FALSE]
    y <- dc[[response]]
    k$rows <- sx_sha_raw(function(con) sx_put_txt(con, rn[o]))
    k$rows_ordered <- sx_sha_raw(function(con) sx_put_txt(con, rn))
    k$response <- sx_sha_raw(function(con) { if (is.factor(y)) { sx_put_txt(con,
        levels(y)); sx_put_num(con, as.integer(y)) }
                                             else sx_put_num(con, y) })
    k$groups <- sx_sha_raw(function(con) for (g in groups) { f <- dc[[g]]   # partitions only: names and labels never enter
      sx_put_num(con, match(as.character(f), unique(as.character(f)))) })
    k$rn <- rn; k$y <- y0; k$g <- g0
  }
  # design: the canonical design-column names (terms, coding, reference levels) + the SHA-256 of every variable the
  # design uses (values in canonical row order; factors as level labels + codes). X is an exact function of these,
  # so this equals a hash of the realized matrix while hashing only a few bytes per model (variables are cached).
  vars <- intersect(all.vars(stats::delete.response(stats::terms(fixed))), names(d))
  vh <- vapply(vars, function(v) {
    col <- d[[v]]; e <- k$vars[[v]]
    if (!is.null(e) && identical(e$rn, rn) && identical(e$col, col)) return(e$sha)
    co <- col[o]
    sha <- sx_sha_raw(function(con) { if (is.factor(co)) { sx_put_txt(con,
        levels(co)); sx_put_num(con, as.integer(co)) }
                                       else sx_put_num(con, co) })
    if (is.null(k$vars)) k$vars <- list()
    k$vars[[v]] <- list(rn = rn, col = col, sha = sha)
    sha
  }, "")
  vn <- sx_canon_names(names(vh)); vo <- order(vn)
  list(schema = 2L, algorithm = "sha256", n = nrow(d), rows = k$rows, rows_ordered = k$rows_ordered,
    response = k$response,
    design = sx_sha_raw(function(con) { sx_put_txt(con, cn[ix]); sx_put_txt(con,
        vn[vo]); sx_put_txt(con, unname(vh)[vo]) }),
    groups = k$groups, design_columns = I(cn[ix]))
}

# ---- StatExplore: data preparation ----
# Source file: "StatExplore_Test51F_Null_13.csv"
# Values declared as user-missing in the source were exported as NA.
sx_data_file <- "validation_reproduce_data.csv"  # exported with this script (analysis columns only); edit if you move it
if (!file.exists(sx_data_file)) {  # source("analysis.R") from another folder: look next to the script
  sx_here <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) NA_character_)
  if (!is.na(sx_here) && file.exists(file.path(sx_here, sx_data_file))) sx_data_file <- file.path(sx_here,
      sx_data_file)
}
if (!file.exists(sx_data_file)) stop("Data file not found: put ", sx_data_file,
    " next to this script or set sx_data_file.")
sx_data_sha256 <- "1c23acc31b69b5b0dbec156ff491f84317735fa6b6a5124c9fb632da27154998"  # SHA-256 of validation_reproduce_data.csv as exported (see validation_reproduce_manifest.json)
if (!isTRUE(get0("sx_skip_checksum")) && !identical(unname(tools::sha256sum(sx_data_file)),
    sx_data_sha256))
  stop("The data file ", sx_data_file, " is not the file exported with this script (SHA-256 differs). ",
       "Use the exported file, or set sx_skip_checksum <- TRUE before source() to run anyway (the run is then ",
       "UNVERIFIED and is not a reproduction).", call. = FALSE)
if (isTRUE(get0("sx_skip_checksum"))) message("WARNING: the data checksum was skipped - this run is UNVERIFIED.")
sx_raw <- utils::read.csv(
  sx_data_file, na.strings = "", fileEncoding = "UTF-8", check.names = FALSE,
  colClasses = c(
    v001 = "numeric",
    v002 = "numeric",
    v003 = "numeric",
    v004 = "numeric",
    v005 = "numeric",
    v006 = "numeric",
    v007 = "numeric",
    v008 = "numeric",
    v009 = "numeric",
    v010 = "numeric"
  )
)
sx_result <- list(n_raw = nrow(sx_raw))
# Internal names (v001, ...) -> variable names
sx_names <- c(
    v001 = "School",
    v002 = "StudentID",
    v003 = "Time",
    v004 = "X01",
    v005 = "X02",
    v006 = "X03",
    v007 = "X04",
    v008 = "X05",
    v009 = "X06",
    v010 = "Y"
)
dat <- sx_raw
sx_result <- list(n_rows = nrow(dat), n_cols = ncol(dat))

# ---- StatExplore: shared longitudinal model helpers (v1.3.2) ----
# One builder for every Gaussian longitudinal fit (Mixed workspace, comparisons, Discovery, exports).
# random: "ri" | "diag" | "rs"; residual: "independent" | "ar1" | "car1"; clustered: participants (composite
# cluster+ID key in `id`) nested in `cluster`. Correlation objects are created fresh for every fit.
sx_re_lme4 <- function(random, clustered = FALSE, slope = "sx_time", id = "sx_id",
    cluster = "sx_cluster") {
  r <- switch(random, ri = paste0("(1 | ", id, ")"), diag = paste0("(1 + ", slope, " || ", id, ")"),
              rs = paste0("(1 + ", slope, " | ", id, ")"), stop("Unsupported random-effects structure: ",
                  random))
  if (clustered) paste0("(1 | ", cluster, ") + ", r) else r
}
sx_re_nlme <- function(random, clustered = FALSE, slope = "sx_time", id = "sx_id",
    cluster = "sx_cluster") {
  fs <- stats::as.formula(paste("~ 1 +", slope))
  if (!clustered) return(switch(random,
    ri = stats::as.formula(paste("~ 1 |", id)),
    diag = stats::setNames(list(nlme::pdDiag(fs)), id),
    rs = stats::as.formula(paste("~ 1 +", slope, "|", id)),
    stop("Unsupported random-effects structure: ", random)))
  switch(random,
    ri = stats::as.formula(paste("~ 1 |", cluster, "/", id)),
    diag = stats::setNames(list(nlme::pdDiag(~ 1), nlme::pdDiag(fs)), c(cluster, id)),
    rs = stats::setNames(list(nlme::pdDiag(~ 1), nlme::pdSymm(fs)), c(cluster, id)),
    stop("Unsupported random-effects structure: ", random))
}
sx_cor_nlme <- function(residual, clustered = FALSE, occ = "sx_tidx", tnum = "sx_tnum",
    id = "sx_id",
                        cluster = "sx_cluster") {
  g <- if (clustered) paste0(cluster, "/", id) else id
  switch(residual, independent = NULL,
    ar1 = nlme::corAR1(form = stats::as.formula(paste("~", occ, "|", g))),
    car1 = nlme::corCAR1(form = stats::as.formula(paste("~", tnum, "|", g))),
    stop("Unsupported residual covariance structure: ", residual))
}
# Composite participant key for nested designs: length-prefixed (cluster, ID) labels, ordered by cluster then ID, so
# locally reused IDs never merge and no concatenation is ambiguous.
sx_nested_id <- function(cluster, id) {
  cl <- as.character(cluster); pid <- as.character(id)
  key <- paste0(nchar(cl, type = "chars"), ":", cl, "|", pid)
  o <- order(as.integer(factor(cluster)), as.integer(factor(id)))
  factor(key, levels = unique(key[o]))
}
# Optimizer errors that justify retrying the SAME model with another optimizer; any other error is structural.
sx_optimizer_error <- function(msg) grepl("convergence|iteration limit|evaluation limit|nlminb problem|false convergence|singular convergence|optim problem",
    msg, ignore.case = TRUE)
# Run fit(opt) for each optimizer in turn until one succeeds; record every attempt, its warnings and errors. Only an
# optimizer failure moves on to the next optimizer; the requested model is never changed.
sx_fit_attempts <- function(fit, optimizers) {
  attempts <- list(); warns <- character(); m <- NULL; err <- NULL
  for (opt in optimizers) {
    w <- character()
    # AUD134-10: every optimizer attempt is a fitting invocation (outside the tryCatch: a budget stop is not a fit error)
    if (exists("sx_budget_take", mode = "function")) sx_budget_take(if (length(attempts)) "retry" else "fit")
    m <- withCallingHandlers(tryCatch(fit(opt), error = function(e) e),
      warning = function(x) { w <<- c(w, conditionMessage(x)); invokeRestart("muffleWarning") },
      message = function(x) invokeRestart("muffleMessage"))
    bad <- inherits(m, "error")
    attempts[[length(attempts) + 1]] <- data.frame(optimizer = opt, status = if (bad) "failed" else "fitted",
      error = if (bad) conditionMessage(m) else "", warnings = paste(unique(w),
          collapse = "; "), stringsAsFactors = FALSE)
    if (!bad) { warns <- unique(w); break }
    err <- conditionMessage(m)
    if (!sx_optimizer_error(err)) break
  }
  list(fit = if (inherits(m, "error")) NULL else m, attempts = do.call(rbind,
      attempts), warnings = warns, error = err)
}
# Diagnostics of a fitted Gaussian mixed model (STAT-18 / STAT-32). Flags may coexist; `clean` only when none.
#   lme4: optimizer code, lme4 check code and messages, warnings, isSingular (lme4 tolerance 1e-4 on theta)
#   nlme: every random-effects block G / sigma^2: non positive definite -> singular; smallest eigenvalue < 1e-6, eigenvalue
#         ratio < 1e-6 or |correlation| > 0.999 -> near-boundary (positive definite but at the edge); apVar (approximate
#         covariance of the variance parameters) reported separately; optimizer fallback reported as a warning.
sx_diag <- function(m, run = NULL) {
  out <- list(engine = if (inherits(m, "merMod")) "lme4" else if (inherits(m,
      "lme")) "nlme" else class(m)[1],
              optimizer = NA_character_, opt_code = NA_real_, check_code = NA_real_, singular = NA,
              near_boundary = NA, boundary = character(), apvar = "not applicable", messages = character(),
              flags = character())
  att <- if (is.null(run)) NULL else run$attempts
  w <- if (is.null(run)) character() else run$warnings
  if (!is.null(att) && nrow(att)) {
    out$optimizer <- utils::tail(att$optimizer, 1)
    if (nrow(att) > 1) out$flags <- c(out$flags, paste0("optimizer fallback: ",
        paste(sprintf("%s failed (%s)",
      att$optimizer[att$status == "failed"], att$error[att$status == "failed"]), collapse = "; "), "; estimated with ",
      out$optimizer))
  }
  if (inherits(m, "merMod")) {
    oi <- m@optinfo
    out$optimizer <- oi$optimizer
    out$opt_code <- if (is.null(oi$conv$opt)) NA_real_ else as.numeric(oi$conv$opt)
    cc <- oi$conv$lme4$code; out$check_code <- if (is.null(cc) || !length(cc)) 0 else as.numeric(cc[1])
    msgs <- unique(c(unlist(oi$conv$lme4$messages), unlist(oi$warnings)))
    out$singular <- lme4::isSingular(m)
    if (isTRUE(out$singular)) out$flags <- c(out$flags, "Singular fit: a random-effect variance is ~0 or a correlation is +/-1 (lme4 tolerance 1e-4); simplify the random-effects structure")
    msgs <- msgs[!grepl("singular", msgs, ignore.case = TRUE) | !isTRUE(out$singular)]
    out$messages <- msgs
    if (isTRUE(out$opt_code != 0)) out$flags <- c(out$flags, sprintf("optimizer returned code %g",
        out$opt_code))
    if (isTRUE(out$check_code != 0) && !length(msgs)) out$flags <- c(out$flags,
        sprintf("lme4 convergence check code %g", out$check_code))
    if (length(msgs)) out$flags <- c(out$flags, paste("convergence:", msgs))
  } else if (inherits(m, "lme")) {
    s2 <- m$sigma^2; nb <- FALSE; sing <- FALSE
    for (g in names(m$modelStruct$reStruct)) {
      G <- tryCatch(nlme::pdMatrix(m$modelStruct$reStruct[[g]]), error = function(e) NULL)
      if (is.null(G)) { out$boundary <- c(out$boundary, paste0(g, ": covariance unavailable")); next }
      ev <- eigen(G, symmetric = TRUE, only.values = TRUE)$values
      r <- if (nrow(G) > 1) stats::cov2cor(G) else matrix(1)
      rmax <- if (nrow(G) > 1) max(abs(r[upper.tri(r)])) else 0
      if (!all(is.finite(ev)) || min(ev) <= 0) { sing <- TRUE
        out$boundary <- c(out$boundary, sprintf("%s: covariance not positive definite (smallest eigenvalue %.3g)",
            g, min(ev)))
      } else if (min(ev) < 1e-6 || min(ev) / max(ev) < 1e-6 || rmax > 0.999) { nb <- TRUE
        out$boundary <- c(out$boundary, sprintf("%s: near-boundary (smallest variance/sigma^2 eigenvalue %.3g, ratio %.3g, max |r| %.4f)",
                                                g, min(ev), min(ev) / max(ev), rmax)) }
    }
    out$singular <- sing; out$near_boundary <- nb
    if (sing) out$flags <- c(out$flags, paste("singular random-effects covariance:",
        paste(out$boundary, collapse = "; ")))
    if (nb) out$flags <- c(out$flags, paste("near-boundary random-effects covariance (positive definite; scaled eigenvalue / eigenvalue-ratio tolerance 1e-6, |r| > 0.999):",
        paste(out$boundary, collapse = "; ")))
    out$apvar <- if (is.matrix(m$apVar)) "positive definite" else as.character(m$apVar)[1]
    if (!is.matrix(m$apVar)) out$flags <- c(out$flags, paste0("approximate covariance of the variance parameters (apVar) unavailable: ",
        out$apvar,
                                                             " (variance-component standard errors and intervals are not available; this is not by itself singularity)"))
  } else if (inherits(m, "clmm")) {
    out$optimizer <- "ucminf (ordinal default)"
    code <- m$optRes$convergence; out$opt_code <- if (is.null(code)) NA_real_ else as.numeric(code)
    if (!isTRUE(out$opt_code == 0)) out$flags <- c(out$flags, sprintf("optimizer convergence code %s",
        format(out$opt_code)))
    ch <- tryCatch(summary(m)$condHess, error = function(e) NA_real_)
    if (isTRUE(ch > 1e4)) out$flags <- c(out$flags, sprintf("ill-conditioned Hessian (condition number %.3g)",
        ch))
    vc <- tryCatch(getExportedValue("ordinal", "VarCorr")(m), error = function(e) NULL); sing <- FALSE
    for (g in names(vc)) { ev <- eigen(as.matrix(vc[[g]]), symmetric = TRUE,
        only.values = TRUE)$values
      if (min(ev) < 1e-6) { sing <- TRUE; out$boundary <- c(out$boundary,
          sprintf("%s: smallest variance eigenvalue %.3g", g, min(ev))) } }
    out$singular <- sing
    if (sing) out$flags <- c(out$flags, paste("random-effect variance at or near zero:",
        paste(out$boundary, collapse = "; ")))
  } else if (inherits(m, "geeglm")) {
    out$optimizer <- "geese (Fisher scoring)"
    if (!identical(as.integer(m$geese$error), 0L)) out$flags <- c(out$flags,
        "GEE estimating equations did not converge")
  } else if (inherits(m, "mmrm")) {
    out$optimizer <- "mmrm default"
    if (!isTRUE(attr(m, "converged"))) out$flags <- c(out$flags, "mmrm did not report convergence")
  } else if (inherits(m, "mblogit")) {
    out$optimizer <- "PQL"
    if (!isTRUE(m$converged)) out$flags <- c(out$flags, "the PQL algorithm did not converge")
  } else {
    out$flags <- c(out$flags, "diagnostics unknown for this engine")
  }
  w <- unique(w[!vapply(w, function(x) any(grepl(x, out$messages, fixed = TRUE)), logical(1))])
  if (length(w)) out$flags <- c(out$flags, paste("warning:", w))
  out$flags <- unique(out$flags)
  out$clean <- !length(out$flags)
  out$status <- if (isTRUE(out$singular)) "singular" else if (isTRUE(out$near_boundary)) "near_boundary" else
    if (out$clean) "clean" else "warned"
  out
}
# Marginal / conditional R2 by direct variance decomposition (STAT-45): var(X beta) / (var(X beta) + sum over every
# grouping level of mean diag(Z G Z') + sigma^2). Never the package fallback that silently drops random variance.
sx_r2_direct <- function(m, d) {
  na <- function(why) list(m = NA_real_, c = NA_real_, fixed = NA_real_, random = NA_real_,
      residual = NA_real_, reason = why)
  tryCatch({
    if (inherits(m, "merMod")) {
      s2 <- stats::sigma(m)^2
      fv <- stats::var(as.vector(lme4::getME(m, "X") %*% lme4::fixef(m)))
      rv <- mean(Matrix::rowSums((lme4::getME(m, "Z") %*% lme4::getME(m, "Lambda"))^2)) * s2
    } else if (inherits(m, "lme")) {
      s2 <- m$sigma^2
      fv <- stats::var(as.numeric(stats::predict(m, level = 0)))
      rv <- 0
      for (g in names(m$modelStruct$reStruct)) {
        G <- nlme::pdMatrix(m$modelStruct$reStruct[[g]]) * s2
        Z <- stats::model.matrix(stats::formula(m$modelStruct$reStruct[[g]]), d)
        rv <- rv + mean(rowSums((Z %*% G) * Z))
      }
    } else return(na("not a random-effects model"))
    tot <- fv + rv + s2
    if (!is.finite(tot) || tot <= 0) return(na("variance components unavailable"))
    list(m = fv / tot, c = (fv + rv) / tot, fixed = fv, random = rv, residual = s2, reason = "")
  }, error = function(e) na(paste("variance decomposition failed:", conditionMessage(e))))
}
# Random-effects covariance of an nlme fit, every grouping level (STAT-43): variance, SD, covariance and correlation
# from the scaled pdMatrix; DIAG covariances are constrained to 0, not estimated.
sx_vc_nlme <- function(m) {
  s2 <- m$sigma^2; rows <- list()
  for (g in rev(names(m$modelStruct$reStruct))) {
    pd <- m$modelStruct$reStruct[[g]]; G <- nlme::pdMatrix(pd) * s2; nm <- colnames(G)
    diag_only <- inherits(pd, "pdDiag")
    for (i in seq_len(nrow(G))) rows[[length(rows) + 1]] <- data.frame(group = g,
        term = nm[i], with = "",
      variance_or_cov = G[i, i], sd_or_corr = sqrt(G[i, i]), estimated = "estimated", stringsAsFactors = FALSE)
    if (nrow(G) > 1) for (i in 1:(nrow(G) - 1)) for (j in (i + 1):nrow(G)) rows[[length(rows) + 1]] <- data.frame(
      group = g, term = nm[i], with = nm[j], variance_or_cov = G[i, j],
      sd_or_corr = if (diag_only) 0 else G[i, j] / sqrt(G[i, i] * G[j, j]),
      estimated = if (diag_only) "constrained to 0 (uncorrelated structure)" else "estimated", stringsAsFactors = FALSE)
  }
  rows[[length(rows) + 1]] <- data.frame(group = "Residual", term = "(residual)",
      with = "", variance_or_cov = s2,
    sd_or_corr = sqrt(s2), estimated = "estimated", stringsAsFactors = FALSE)
  do.call(rbind, rows)
}
# Grouping counts at every level of the fitted object (UI-57 / STAT-46): groups, smallest and largest group size.
sx_group_counts <- function(m) {
  fl <- if (inherits(m, "merMod")) lme4::getME(m, "flist") else if (inherits(m,
      "lme")) as.list(m$groups) else list()
  if (!length(fl)) return(NULL)
  do.call(rbind, lapply(names(fl), function(g) { k <- table(droplevels(as.factor(fl[[g]])))
    data.frame(level = g, groups = length(k), min_size = min(k), max_size = max(k)) }))
}
# What was ACTUALLY fitted (v1.3.3, J4), read back from the fitted object, never from the request: class, fixed-effect
# term labels, grouping factors, random-effect blocks (columns, correlated or diagonal), residual correlation class,
# estimation method, GEE working correlation, number of observations.
sx_effective <- function(m) {
  # optional helpers looked up only when needed (a Gaussian script does not depend on reformulas / ordinal)
  nobars <- function(x) getExportedValue(if (requireNamespace("reformulas",
      quietly = TRUE)) "reformulas" else "lme4",
                                         "nobars")(x)
  f <- tryCatch(if (inherits(m, "merMod")) stats::formula(m, fixed.only = TRUE)
                else if (inherits(m, "clmm")) nobars(m$formula) else stats::formula(m), error = function(e) NULL)
  blocks <- list(); groups <- character()
  if (inherits(m, "merMod") || inherits(m, "clmm")) {
    vc <- tryCatch(if (inherits(m, "clmm")) getExportedValue("ordinal", "VarCorr")(m) else lme4::VarCorr(m),
                   error = function(e) list())
    groups <- names(vc)
    blocks <- lapply(names(vc), function(g) { v <- as.matrix(vc[[g]])
      list(group = g, columns = I(colnames(v)), structure = if (ncol(v) > 1) "correlated" else "single") })
  } else if (inherits(m, "lme")) {
    groups <- names(m$groups)
    blocks <- lapply(names(m$modelStruct$reStruct), function(g) { p <- m$modelStruct$reStruct[[g]]
      list(group = g, columns = I(colnames(as.matrix(p))),
           structure = if (inherits(p, "pdDiag")) "diagonal" else if (ncol(as.matrix(p)) > 1) "correlated" else "single") })
  }
  list(class = class(m)[1], fixed = I(if (is.null(f)) character() else attr(stats::terms(f),
      "term.labels")),
       groups = I(groups), blocks = blocks,
       correlation = if (inherits(m, "lme") && !is.null(m$modelStruct$corStruct)) class(m$modelStruct$corStruct)[1] else "none",
       # nlme turns corAR1 into the equivalent corARMA(p = 1, q = 0) when the occasion index has gaps: keep the order
       cor_pq = I(if (inherits(m, "lme") && inherits(m$modelStruct$corStruct, "corARMA"))
                    c(attr(m$modelStruct$corStruct, "p"),
                        attr(m$modelStruct$corStruct, "q")) else integer()),
       method = if (inherits(m, "merMod") && !inherits(m, "glmerMod")) (if (lme4::isREML(m)) "REML" else "ML")
                else if (inherits(m, "lme")) m$method else "",
       corstr = if (inherits(m, "geeglm")) m$corstr else "",
       nobs = tryCatch(stats::nobs(m), error = function(e) NA_real_))
}
# Likelihood-ratio test with the reference distribution of the hypothesis (STAT-17 / 23 / 41): |LR| <= tol below 0 is
# numerical noise (LR = 0, raw value kept); a materially negative, non-finite LR or df <= 0 gives no p-value.
# reference "chisq" = chi-square(df); "mixture" = 50:50 chi-square(df - 1) : chi-square(df) (chi-square(0) = point mass 0).
sx_lr_test <- function(ll0, ll1, df, reference = "chisq", tol = 1e-6) {
  raw <- 2 * (ll1 - ll0)
  out <- list(LR_raw = raw, LR = NA_real_, df = df, p = NA_real_, log_p = NA_real_,
      reference = reference,
              status = "tested", reason = "")
  if (!is.finite(raw)) { out$status <- "withheld"; out$reason <- "non-finite likelihood-ratio statistic"; return(out) }
  if (!is.finite(df) || df <= 0) { out$status <- "withheld"; out$reason <- "no extra parameters (df <= 0)"; return(out) }
  if (raw < -tol) { out$status <- "withheld"; out$reason <- sprintf(paste0("the larger model has a lower likelihood ",
    "(LR = %.6g): at least one optimization is unreliable; no p-value"), raw); return(out) }
  lr <- max(raw, 0); out$LR <- lr
  if (raw < 0) out$reason <- sprintf("negligible negative LR %.3g set to 0 (tolerance %g)",
      raw, tol)
  lp <- function(k) if (k == 0) (if (lr > 0) -Inf else 0) else stats::pchisq(lr,
      k, lower.tail = FALSE, log.p = TRUE)
  out$log_p <- if (reference == "mixture") { a <- log(0.5) + lp(df - 1); b <- log(0.5) + lp(df)
    mx <- max(a, b); if (!is.finite(mx)) mx else mx + log(exp(a - mx) + exp(b - mx)) } else lp(df)
  out$p <- exp(out$log_p)
  out
}
# Upper-tail F probability from full-precision statistics (STAT-42); log10 kept when the probability underflows.
sx_pf <- function(F, df1, df2) {
  p <- stats::pf(F, df1, df2, lower.tail = FALSE)
  lp <- stats::pf(F, df1, df2, lower.tail = FALSE, log.p = TRUE) / log(10)
  data.frame(p = p, log10_p = lp)
}

# ---- StatExplore: discovery helpers ----
# Fit one candidate's full model once, then evaluate each planned hypothesis as a nested
# comparison with a reduced model (tests[[1]] is the candidate's declared focal test).
# v1.3.4 (V134-001 / V134-012): fit statistics are cached only under a FIT KEY that proves what was fitted - the
# content of every column the model uses (response, design variables, grouping, time, occasion) in the exact row order
# with the row identities, plus the estimation context (family, structure, cluster, REML/ML, GEE family and working
# correlation, optimizer rules) and the sample context set by the caller. Row names, counts or formulas alone never
# justify reuse; validation resets the cache for every training part and bootstrap draw (sx_cache_reset).
# AUD134-01: the primary-test score shared by EVERY selection path (AMD validation and the legacy stability / procedure
# CV): the natural-log upper tail of tests[[1]], taken from the test distribution itself (log.p = TRUE). NA when the fit
# is not ok / warning, the test was withheld or has no p: never log(0) and never a substituted value.
sx_primary_logp <- function(r) {
  if (is.null(r) || !(r$status %in% c("ok", "warning")) || !length(r$tests)) return(NA_real_)
  t1 <- r$tests[[1]]
  if (!is.null(t1$withheld) || is.null(t1$log_p) || !length(t1$log_p)) return(NA_real_)
  as.numeric(t1$log_p)[1]
}
# argmin with the declared tie rule: the smallest score wins; exact ties -> the lower candidate position; NA never wins
sx_select_min <- function(score) {
  ok <- which(!is.na(score))
  if (!length(ok)) NA_integer_ else ok[which.min(score[ok])]
}
# AUD134-10: hard budget of model-fitting invocations (validation sets a finite cap per chunk). Every call of a model
# fitter counts - full, reduced, null and selected refits - each optimizer retry counts as one more, and so do the
# auxiliary fits (binary separation check, GEE QIC independence refit). Cache hits are counted apart and cost nothing.
sx_fit_budget <- new.env()
sx_budget_reset <- function(cap = Inf) {
  sx_fit_budget$cap <- cap; sx_fit_budget$used <- 0; sx_fit_budget$retries <- 0; sx_fit_budget$aux <- 0
  sx_fit_budget$denied <- 0   # AUD135-05: fits REFUSED by the cap (work truncated), distinct from reaching the cap
}
sx_budget_reset()
sx_budget_take <- function(kind = "fit") {
  if (sx_fit_budget$used >= sx_fit_budget$cap) {
    sx_fit_budget$denied <- sx_fit_budget$denied + 1
    stop(structure(class = c("sx_budget", "error", "condition"), list(call = NULL,
        message = sprintf(
      "fit budget reached: %d model-fitting invocations of the %s allowed", as.integer(sx_fit_budget$used),
      format(sx_fit_budget$cap)))))
  }
  sx_fit_budget$used <- sx_fit_budget$used + 1
  if (kind == "retry") sx_fit_budget$retries <- sx_fit_budget$retries + 1
  if (kind == "aux") sx_fit_budget$aux <- sx_fit_budget$aux + 1
  invisible(TRUE)
}
sx_disc_cache <- new.env()            # fit key -> fit statistics (with the producing fit's own diagnostics)
sx_disc_ctx <- "search"               # sample context: "search", or a validation split / bootstrap draw id
sx_disc_cache_log <- new.env()        # hits / misses (audit)
sx_disc_cache_log$hits <- 0L; sx_disc_cache_log$misses <- 0L
sx_disc_current <- NA_integer_        # candidate being evaluated (cache provenance)
sx_cache_reset <- function(ctx = "search") {
  rm(list = ls(sx_disc_cache, all.names = TRUE), envir = sx_disc_cache)
  rm(list = ls(sx_col_hashes, all.names = TRUE), envir = sx_col_hashes)
  sx_disc_ctx <<- ctx
}
sx_col_hashes <- new.env()            # column name -> (row names, column, MD5): each column hashed once per sample
sx_col_hash <- function(d, v) {
  rn <- rownames(d); col <- d[[v]]; e <- sx_col_hashes[[v]]
  if (!is.null(e) && identical(e$rn, rn) && identical(e$col, col)) return(e$h)
  h <- unname(tools::md5sum(bytes = serialize(list(v, rn, if (is.factor(col)) levels(col),
      unclass(col)), NULL, xdr = TRUE)))
  assign(v, list(rn = rn, col = col, h = h), envir = sx_col_hashes)
  h
}
sx_fit_key <- function(f, d) {
  cols <- intersect(c("sx_y", all.vars(f), "sx_gid", "sx_cluster", "sx_time",
      "sx_timef", "sx_occ"), names(d))
  terms <- sort(sx_canon_names(attr(stats::terms(f), "term.labels")))
  paste(c(sx_disc_ctx, sx_disc_family, sx_disc_struct, sx_disc_clustered, sx_disc_reml,
          if (sx_disc_family == "gee") c(sx_disc_gee_family, sx_gee_corstr(sx_disc_struct)), sx_disc_fit_rules,
          paste(terms, collapse = "+"), nrow(d), vapply(cols, function(v) paste0(v,
              "=", sx_col_hash(d, v)), "")),
        collapse = "|")
}
sx_gee_corstr <- function(st) switch(st, gee_exch = "exchangeable", gee_ar1 = "ar1",
    gee_ind = "independence",
                                      stop("not a GEE structure: ", st))
# Analysis-row signature: MD5 of the row identities in fitting order plus the levels of every factor model column
# (participant codes excluded: only their grouping matters). Equal signatures = same rows, order and coding.
sx_rows_sig <- function(d) {
  fac <- setdiff(names(d)[vapply(d, is.factor, logical(1))], "sx_gid")
  txt <- c(rownames(d), vapply(fac, function(v) paste0(v, ":", paste(levels(d[[v]]),
      collapse = "|")), ""))
  tf <- tempfile(); on.exit(unlink(tf)); writeLines(txt, tf, useBytes = TRUE)
  unname(tools::md5sum(tf))
}
sx_add <- function(f, extra) stats::update(f, stats::as.formula(paste(". ~ . +", extra)))
sx_last_run <- NULL                   # optimizer attempts of the most recent Gaussian longitudinal fit
sx_fit_lmm <- function(f, d, st, reml, clustered = sx_disc_clustered) {
  if (startsWith(st, "mmrm")) {
    cs <- switch(st, mmrm_us = "us", mmrm_cs = "cs", mmrm_ar1 = "ar1")
    sx_last_run <<- NULL
    return(mmrm::mmrm(sx_add(f, paste0(cs, "(sx_timef | sx_gid)")), data = d, reml = reml))
  }
  g <- sx_disc_gstruct[[st]]
  if (is.null(g)) stop("Unknown covariance structure: ", st)
  # one structure builder for every module (random part, residual correlation, nested cluster)
  run <- if (g[3] == "lme4")
    sx_fit_attempts(function(opt) lme4::lmer(sx_add(f, sx_re_lme4(g[1], clustered,
        "sx_time", "sx_gid")), data = d,
                                             REML = reml), "default") else
    sx_fit_attempts(function(opt) nlme::lme(f, random = sx_re_nlme(g[1],
        clustered, "sx_time", "sx_gid"),
      correlation = sx_cor_nlme(g[2], clustered, "sx_occ", "sx_time", "sx_gid"), data = d,
      method = if (reml) "REML" else "ML", control = nlme::lmeControl(opt = opt, msMaxIter = 200)),
      c("nlminb", "optim"))
  sx_last_run <<- run
  if (is.null(run$fit)) stop(run$error)
  run$fit
}
sx_fit_model <- function(f, d) {
  st <- sx_disc_struct
  if (sx_disc_family != "lmm" || startsWith(st, "mmrm")) sx_budget_take()     # nlme / lme4 attempts count themselves
  switch(sx_disc_family,
    lmm = sx_fit_lmm(f, d, st, sx_disc_reml, sx_disc_clustered),
    glmm = lme4::glmer(sx_add(f, if (st == "glmer_rs") "(1 + sx_time | sx_gid)" else "(1 | sx_gid)"),
        data = d,
                       family = stats::binomial()),
    clmm = ordinal::clmm(sx_add(f, if (st == "clmm_rs") "(1 + sx_time | sx_gid)" else "(1 | sx_gid)"),
        data = d,
                         link = "logit"),
    gee = sx_fit_gee(f, d, st),
    gaussian = stats::lm(f, d),
    ordinal = ordinal::clm(f, data = d, link = "logit"),
    multinomial = nnet::multinom(f, data = d, trace = FALSE, maxit = 1000, model = FALSE),
    stats::glm(f, data = d, family = stats::binomial()))
}
# GEE (V134-005): the working correlation of THIS candidate's structure, passed explicitly and read back from the
# fitted object; a mismatch fails closed.
sx_fit_gee <- function(f, d, st) {
  cs <- sx_gee_corstr(st)
  m <- geepack::geeglm(f, data = d, id = sx_gid, waves = sx_occ, corstr = cs,
                       family = if (sx_disc_gee_family == "binomial") stats::binomial() else stats::gaussian())
  if (!identical(as.character(m$corstr), cs))
    stop(sprintf("the fitted working correlation (%s) differs from the requested one (%s)",
        m$corstr, cs))
  m
}
sx_gee_readback <- function(m) {
  # what geepack actually estimated (never the request): working correlation, its parameter(s), scale, clusters
  list(corstr = as.character(m$corstr), alpha = I(as.numeric(m$geese$alpha)),
      scale = as.numeric(m$geese$gamma),
       clusters = length(unique(m$id)), nobs = length(m$y), family = m$family$family, link = m$family$link,
       robust_se = I(as.numeric(sqrt(diag(as.matrix(m$geese$vbeta))))))
}
# Fit a model and its statistics, capturing the warnings of THIS fit (V134-010): they belong to the fit that produced
# them and travel with it into the cache, so a reused reduced model keeps its diagnostics and an unrelated fit's warning
# never flags another test.
sx_fit_capture <- function(f, d) {
  w <- character()
  st <- withCallingHandlers({ m <- sx_fit_model(f, d); s <- sx_fit_stats(m,
      d); list(m = m, s = s) },
    warning = function(x) { w <<- c(w, conditionMessage(x)); invokeRestart("muffleWarning") })
  w <- unique(w)
  if (length(w)) {
    known <- if (is.null(st$s$diag)) character() else st$s$diag$flags
    extra <- w[!vapply(w, function(x) any(grepl(x, known, fixed = TRUE)), logical(1))]
    if (length(extra)) st$s$conv <- paste(c(if (nzchar(st$s$conv)) st$s$conv,
        paste("warning:", extra)), collapse = "; ")
  }
  st$s$warnings <- w
  st
}
sx_fit_stats <- function(m, d) {
  if (sx_disc_family == "gee") return(list(ll = NA_real_, k = length(stats::coef(m)), conv = ""))
  ll <- stats::logLik(m)
  out <- list(ll = as.numeric(ll), k = attr(ll, "df"), conv = "")
  if (sx_disc_family == "gaussian") { out$rss <- stats::deviance(m); out$dfres <- m$df.residual }
  if (sx_disc_family == "binomial") { out$dev <- m$deviance; out$dfres <- m$df.residual
    if (!m$converged) out$conv <- "did not converge" }
  if (sx_disc_family == "multinomial") { out$dev <- m$deviance; out$k <- m$edf
    if (m$convergence != 0) out$conv <- "did not converge (iteration limit)" }
  if (sx_disc_family == "ordinal" && !identical(as.integer(m$convergence$code), 0L))
    out$conv <- paste("did not converge:", paste(m$convergence$messages, collapse = " "))
  if (sx_disc_family == "glmm" && inherits(m, "merMod")) {
    conv <- unlist(m@optinfo$conv$lme4$messages)
    if (length(conv)) out$conv <- paste("convergence:", conv[1])
  }
  out$r2m <- NA_real_
  if (sx_disc_family == "lmm") {
    # every diagnostic of the fit (convergence, singular / near-boundary, apVar, optimizer fallback): STAT-18 / 32
    out$diag <- sx_diag(m, if (inherits(m, c("merMod", "lme"))) sx_last_run else NULL)
    out$conv <- paste(out$diag$flags, collapse = "; ")
    if (inherits(m, c("merMod", "lme"))) out$r2m <- sx_r2_direct(m, d)$m     # direct decomposition (STAT-45)
  }
  out
}
sx_reduced_stats <- function(reduced, d) {
  f0 <- stats::reformulate(if (length(reduced)) reduced else "1", response = "sx_y")
  key <- sx_fit_key(f0, d)
  hit <- sx_disc_cache[[key]]
  if (!is.null(hit)) {
    sx_disc_cache_log$hits <- sx_disc_cache_log$hits + 1L
    hit$source <- "cache"; return(hit)
  }
  sx_disc_cache_log$misses <- sx_disc_cache_log$misses + 1L
  st <- sx_fit_capture(f0, d)$s
  st$m <- NULL
  st$source <- "fitted"; st$fitted_for <- sx_disc_current; st$key_md5 <- unname(tools::md5sum(bytes = charToRaw(key)))
  assign(key, st, envir = sx_disc_cache)
  st
}
sx_null_scale <- function(d) {
  # denominators of the pseudo-R2 effects: -2 log L (ordinal) or deviance (logistic, multinomial) of y ~ 1, fitted to
  # exactly these rows (same fit key as any other model)
  st <- sx_reduced_stats(character(), d)
  if (sx_disc_family == "ordinal") -2 * st$ll else st$dev
}
# columns of the design matrix X that belong to model term `term` ("a:b" matches "b:a")
sx_term_cols <- function(X, f, term) {
  labs <- attr(stats::terms(f), "term.labels")
  norm <- function(x) vapply(strsplit(x, ":", fixed = TRUE), function(p) paste(sort(p),
      collapse = ":"), "")
  j <- match(norm(term), norm(labs))
  if (is.na(j)) character() else colnames(X)[attr(X, "assign") == j]
}
sx_wald <- function(m, X, f, drop) {
  # robust (sandwich) Wald test of all coefficients of the dropped terms (GEE)
  cols <- unlist(lapply(drop, function(t) sx_term_cols(X, f, t)))
  b <- stats::coef(m)[cols]; V <- as.matrix(stats::vcov(m))[cols, cols, drop = FALSE]
  w <- as.numeric(t(b) %*% solve(V, b))
  list(statistic = w, df1 = length(cols), df_den = NA_real_, p = stats::pchisq(w,
      length(cols), lower.tail = FALSE),
       log_p = stats::pchisq(w, length(cols), lower.tail = FALSE, log.p = TRUE), effect = NA_real_, partial_eta2 = NA_real_)
}
sx_compare <- function(s1, s0, d) {
  # V134-002: the natural log of the upper tail comes from the distribution itself (log.p = TRUE), never log(p)
  r <- list(statistic = NA_real_, df1 = NA_real_, df_den = NA_real_, p = NA_real_,
      log_p = NA_real_, effect = NA_real_,
            partial_eta2 = NA_real_)
  if (sx_disc_family == "gaussian") {
    ss <- s0$rss - s1$rss; r$df1 <- s0$dfres - s1$dfres; r$df_den <- s1$dfres
    r$statistic <- (ss / r$df1) / (s1$rss / s1$dfres)
    if (!is.finite(r$statistic) || r$df1 <= 0) {
      r$statistic <- NA_real_; r$withheld <- "no extra parameters or non-finite F statistic"
    } else if (r$statistic < 0) {
      # residual SS of the larger model above the smaller one's: only rounding noise can do this for nested OLS
      if (ss < -1e-8 * max(1, s0$rss)) r$withheld <- sprintf("the larger model has a larger residual SS (%.6g): no p-value",
          ss)
      else { r$statistic <- 0; r$p <- 1; r$log_p <- 0 }
    } else {
      r$p <- stats::pf(r$statistic, r$df1, r$df_den, lower.tail = FALSE)
      r$log_p <- stats::pf(r$statistic, r$df1, r$df_den, lower.tail = FALSE, log.p = TRUE)
    }
    r$effect <- ss / sum((d$sx_y - mean(d$sx_y))^2)                # delta R-squared
    r$partial_eta2 <- ss / (ss + s1$rss)
    return(r)
  }
  if (sx_disc_family %in% c("binomial", "multinomial")) {
    lr <- s0$dev - s1$dev
    r$df1 <- if (sx_disc_family == "binomial") s0$dfres - s1$dfres else s1$k - s0$k
  } else {
    lr <- 2 * (s1$ll - s0$ll); r$df1 <- s1$k - s0$k
  }
  r$statistic <- lr
  # STAT-41: a materially negative LR (larger model fits worse) means an unreliable optimization: no p-value
  t <- sx_lr_test(0, lr / 2, r$df1, "chisq")
  r$p <- t$p; r$log_p <- t$log_p; r$LR_raw <- t$LR_raw
  if (!identical(t$status, "tested")) r$withheld <- t$reason
  r$effect <- switch(sx_disc_family, lmm = s1$r2m - s0$r2m,             # delta marginal R-squared (lme4 RI)
                     glmm = NA_real_, clmm = NA_real_,
                     lr / sx_null_scale(d))                             # delta McFadden pseudo-R-squared
  r
}
sx_long <- function() sx_disc_family %in% c("lmm", "glmm", "clmm", "gee")
sx_discover_one <- function(full, tests, vars, focal_vars, struct = NULL, clustered = NULL,
    i = NA_integer_) {
  sx_disc_current <<- i
  if (!is.null(struct)) {      # workflow B: this candidate's structure
    old_struct <- sx_disc_struct; sx_disc_struct <<- struct; on.exit(sx_disc_struct <<- old_struct)
  }
  if (!is.null(clustered)) {   # workflow B exploratory: this candidate with or without the cluster variance
    old_cl <- sx_disc_clustered; sx_disc_clustered <<- clustered; on.exit(sx_disc_clustered <<- old_cl,
        add = TRUE)
  }
  res <- list(status = "ok", reason = "", flags = character(), n = NA_real_, n_params = NA_real_,
              n_groups = NA_real_, statistic = NA_real_, df1 = NA_real_, df2 = NA_real_, p = NA_real_,
              effect = NA_real_, partial_eta2 = NA_real_, estimate = NA_real_, se = NA_real_,
              ci_low = NA_real_, ci_high = NA_real_, r2 = NA_real_, adj_r2 = NA_real_, aic = NA_real_,
              bic = NA_real_, loglik = NA_real_, tests = list())
  invalid <- function(why) { res$status <- "invalid"; res$reason <- why; res$flags <- ""; res$tests <- NULL; res }
  d <- sx_complete(sx_dd, c("sx_y", vars, if (sx_long()) c("sx_gid", if (sx_disc_has_cluster) "sx_cluster",
                                                            if (sx_disc_has_time) c("sx_time",
                                                                "sx_timef", "sx_occ"))))
  # occasion index over the model's own rows (sx_timef levels were dropped above): a time value no analysed row has
  # is compressed exactly as in Full Analysis; a participant's skipped occasion still leaves an index gap
  if (sx_long() && sx_disc_has_time) d$sx_occ <- as.integer(d$sx_timef)
  n <- nrow(d); res$n <- n; res$rows_sig <- sx_rows_sig(d)
  if (n < sx_disc_min_obs) return(invalid(sprintf("%d complete rows; the minimum is %d",
      n, sx_disc_min_obs)))
  for (v in vars) if (is.factor(d[[v]]) && nlevels(d[[v]]) < 2)
    return(invalid(paste0(sx_names[[v]], " has fewer than 2 levels in the analysed rows")))
  if (sx_disc_family == "binomial" && length(unique(d$sx_y)) < 2) return(invalid("outcome has one value"))
  K <- if (is.factor(d$sx_y)) nlevels(d$sx_y) else NA_integer_
  if (sx_disc_family %in% c("glmm") || (sx_disc_family == "gee" && sx_disc_gee_family == "binomial"))
    if (length(unique(d$sx_y)) < 2) return(invalid("outcome has one value"))
  if (sx_disc_family %in% c("ordinal", "multinomial", "clmm") && K < 3)
    return(invalid(sprintf("only %d outcome categories observed in the analysed rows", K)))
  if (sx_disc_family == "multinomial" && !(sx_disc_ref %in% levels(d$sx_y)))
    return(invalid("the reference outcome category is not observed in the analysed rows"))
  f1 <- stats::reformulate(if (length(full)) full else "1", response = "sx_y")
  X <- stats::model.matrix(f1, d)
  # parameters: lm/glm = columns of X; ordinal = slopes + (K - 1) thresholds; multinomial = (K - 1) x columns
  k <- switch(sx_disc_family, ordinal = , clmm = ncol(X) - 1 + (K - 1), multinomial = (K - 1) * ncol(X),
      ncol(X))
  res$n_params <- k
  if (k > sx_disc_max_params) return(invalid(sprintf("%d parameters exceed the limit of %d",
      k, sx_disc_max_params)))
  if (n - k < 1) return(invalid("no residual degrees of freedom"))
  # focal_vars: one set of variables (focal interaction) or a list of sets (each interaction term)
  for (fs in if (is.list(focal_vars)) focal_vars else list(focal_vars)) {
    fv <- fs[vapply(d[fs], is.factor, logical(1))]
    if (length(fv)) {
      cells <- table(d[fv])
      if (length(fv) >= 2 && any(cells == 0)) return(invalid("empty cell among the focal factors"))
      if (min(cells) < 5) res$flags <- c(res$flags, sprintf("sparse focal cells (min n = %d)",
          min(cells)))
    }
  }
  # (checked after empty cells, which are the more specific explanation)
  if (qr(X)$rank < ncol(X)) return(invalid("design matrix is rank-deficient (not identifiable)"))
  cv <- vars[vapply(d[vars], is.numeric, logical(1))]
  if (length(cv) >= 2) {
    r <- abs(stats::cor(d[cv])); diag(r) <- 0
    if (max(r) > 0.9) res$flags <- c(res$flags, sprintf("|r| = %.2f between continuous predictors",
        max(r)))
  }
  if (sx_long() && (sx_disc_struct %in% c("glmer_rs", "clmm_rs") ||
                    (!is.null(sx_disc_gstruct[[sx_disc_struct]]) && sx_disc_gstruct[[sx_disc_struct]][1] != "ri"))) {
    k2 <- sum(tapply(d$sx_time, droplevels(d$sx_gid), function(x) length(unique(x))) >= 2)
    if (k2 < 10) return(invalid(sprintf("only %d participants have 2+ time points: a random slope is not estimable",
        k2)))
  }
  fc <- sx_fit_capture(f1, d); m1 <- fc$m; s1 <- fc$s
  if (sx_disc_family == "gee") res$gee <- sx_gee_readback(m1)
  if (!is.null(s1$diag)) {
    res$flags <- c(res$flags, if (nzchar(s1$conv)) strsplit(s1$conv, "; ", fixed = TRUE)[[1]])
    res$diagnostics <- s1$diag[c("status", "optimizer", "apvar")]
    res$diagnostics$attempts <- if (is.null(sx_last_run)) "" else paste(sprintf("%s: %s%s",
        sx_last_run$attempts$optimizer,
      sx_last_run$attempts$status, ifelse(nzchar(sx_last_run$attempts$error),
          paste0(" (", sx_last_run$attempts$error, ")"), "")),
      collapse = "; ")
  } else if (nzchar(s1$conv)) res$flags <- c(res$flags, s1$conv)
  # identity fingerprints of exactly what was fitted (rows, outcome, design, grouping): STAT-22
  res$identity <- sx_identity(d, f1, "sx_y", if (sx_long()) c("sx_gid", if (sx_disc_clustered) "sx_cluster") else character())
  if (sx_long()) {
    res$n_groups <- nlevels(droplevels(d$sx_gid))
    res$clustered <- sx_disc_clustered
    if (sx_disc_has_cluster) res$observed_clusters <- nlevels(droplevels(d$sx_cluster))
    res$modeled_clusters <- if (sx_disc_clustered) nlevels(droplevels(d$sx_cluster)) else 0
    if (sx_disc_family != "lmm" && inherits(m1, "merMod") && lme4::isSingular(m1))
      res$flags <- c(res$flags, "singular fit (a random-effect variance is ~ 0 or a correlation is +/-1)")
    if (sx_disc_family == "gee" && !identical(as.integer(m1$geese$error), 0L))
      res$flags <- c(res$flags, "GEE did not converge")
    if (sx_disc_family == "clmm" && !is.null(m1$condHess) && is.finite(m1$condHess) && m1$condHess > 1e4)
      res$flags <- c(res$flags, sprintf("ill-conditioned Hessian (condition number %.0f)",
          m1$condHess))
    if (sx_disc_family %in% c("glmm") || (sx_disc_family == "gee" && sx_disc_gee_family == "binomial")) {
      epp <- min(sum(d$sx_y), n - sum(d$sx_y)) / max(1, k - 1)
      if (epp < 10) res$flags <- c(res$flags, sprintf("%.1f events per parameter", epp))
    }
    res$r2 <- s1$r2m
    ctab <- switch(sx_disc_family,
      lmm = if (inherits(m1, "merMod")) cbind(lme4::fixef(m1), sqrt(diag(as.matrix(stats::vcov(m1))))) else
        if (inherits(m1, "lme")) summary(m1)$tTable[, 1:2, drop = FALSE] else
        cbind(stats::coef(m1), sqrt(diag(as.matrix(stats::vcov(m1))))),
      glmm = stats::coef(summary(m1))[, 1:2, drop = FALSE],
      clmm = stats::coef(summary(m1))[, 1:2, drop = FALSE],
      gee = stats::coef(summary(m1))[, 1:2, drop = FALSE])
    crit <- stats::qnorm(1 - (1 - sx_disc_conf) / 2)
  } else if (sx_disc_family == "gaussian") {
    sm <- summary(m1); res$r2 <- sm$r.squared; res$adj_r2 <- sm$adj.r.squared
    ctab <- stats::coef(sm)
    crit <- stats::qt(1 - (1 - sx_disc_conf) / 2, m1$df.residual)
  } else if (sx_disc_family == "binomial") {
    sx_budget_take("aux")
    sep <- stats::glm(f1, data = d, family = stats::binomial(), method = detectseparation::detect_separation)
    if (isTRUE(sep$outcome)) res$flags <- c(res$flags, "separation (infinite estimates)")
    ph <- stats::fitted(m1); res$r2 <- mean(ph[d$sx_y == 1]) - mean(ph[d$sx_y == 0])  # Tjur
    epp <- min(sum(d$sx_y), n - sum(d$sx_y)) / max(1, k - 1)
    if (epp < 10) res$flags <- c(res$flags, sprintf("%.1f events per parameter", epp))
    ctab <- stats::coef(summary(m1))
    crit <- stats::qnorm(1 - (1 - sx_disc_conf) / 2)
  } else {
    res$r2 <- if (sx_disc_family == "ordinal") 1 + s1$ll / (sx_null_scale(d) / 2) else 1 - s1$dev / sx_null_scale(d)
    small <- min(table(d$sx_y))
    if (small < 10) res$flags <- c(res$flags, sprintf("smallest outcome category has %d rows",
        small))
    ctab <- if (sx_disc_family == "ordinal") stats::coef(summary(m1)) else NULL
    crit <- stats::qnorm(1 - (1 - sx_disc_conf) / 2)
  }
  if (sx_disc_family != "gee") { ic <- sx_ic(m1); res$aic <- ic$aic; res$bic <- ic$bic; res$loglik <- s1$ll
    res$bic_n <- ic$n_bic; res$ic_basis <- ic$basis
    res$n_lik_params <- ic$k }   # every parameter of the likelihood (fixed + thresholds + covariance)
  for (t in tests) {
    if (sx_disc_family == "gee") {
      tr <- sx_wald(m1, X, f1, t$drop)
    } else {
      s0 <- sx_reduced_stats(t$reduced, d)
      tr <- sx_compare(s1, s0, d)
      # V134-010: the reference (reduced) fit's own diagnostics belong to THIS test only, with their provenance: a
      # flagged reference makes the test provisional; it does not flag the model or its other tests
      tr$reference_flags <- s0$conv
      tr$reference_source <- s0$source
      tr$reference_fitted_for <- if (is.null(s0$fitted_for)) NA_integer_ else s0$fitted_for
      tr$reference_key <- if (is.null(s0$key_md5)) "" else s0$key_md5
      tr$reference_loglik <- if (is.null(s0$ll)) NA_real_ else s0$ll
      tr$reference_k <- if (is.null(s0$k)) NA_real_ else s0$k
    }
    if (sx_disc_family == "multinomial" && isTRUE(tr$statistic < -1e-6))
      tr$reference_flags <- paste(c(if (nzchar(tr$reference_flags)) tr$reference_flags,
                                    "optimizer: the reduced model fitted better than the full model"), collapse = "; ")
    tr$id <- t$id; tr$estimate <- NA_real_; tr$se <- NA_real_; tr$ci_low <- NA_real_; tr$ci_high <- NA_real_
    if (length(t$drop) == 1 && isTRUE(tr$df1 == 1) && !is.null(ctab)) {
      col <- sx_term_cols(X, f1, t$drop)
      if (length(col) == 1 && col %in% rownames(ctab)) {
        co <- ctab[col, ]
        tr$estimate <- co[[1]]; tr$se <- co[[2]]
        tr$ci_low <- co[[1]] - crit * co[[2]]; tr$ci_high <- co[[1]] + crit * co[[2]]
      }
    }
    res$tests[[length(res$tests) + 1]] <- tr
  }
  if (sx_disc_family == "gee") {
    # QIC refits the independence model from the stored call (formula `f`, data `d`): give it both (P1-07)
    # V134-005: QIC, QICu and CIC of the ACTUAL fit (native geepack definitions), kept in their own fields
    qic_env <- list2env(list(f = f1, d = d), parent = environment())
    sx_budget_take("aux")        # QIC refits the independence model (outside the tryCatch: a budget stop is not a flag)
    q <- tryCatch(geepack::QIC(m1, env = qic_env),
                  error = function(e) { res$flags <<- c(res$flags,
                      paste("QIC unavailable:", conditionMessage(e))); NULL })
    pick <- function(nm) if (!is.null(q) && nm %in% names(q)) as.numeric(q[[nm]]) else NA_real_
    res$qic <- pick("QIC"); res$qicu <- pick("QICu"); res$cic <- pick("CIC"); res$quasi_lik <- pick("Quasi Lik")
    res$aic <- NA_real_; res$bic <- NA_real_; res$loglik <- NA_real_
  }
  # the declared focal test, also at the top level (v1.1 row layout)
  if (length(res$tests)) {
    t1 <- res$tests[[1]]
    for (nm in c("statistic", "df1", "p", "log_p", "effect", "partial_eta2",
        "estimate", "se", "ci_low", "ci_high"))
      res[[nm]] <- t1[[nm]]
    if (sx_disc_family == "gaussian") res$df2 <- t1$df_den
  }
  if (length(res$flags)) res$status <- "warning"
  res$flags <- paste(unique(res$flags), collapse = "; ")
  res
}
# Run a batch; per-candidate errors and warnings are recorded, never fatal.
sx_discover_batch <- function(batch) lapply(batch, function(s) {
  warns <- character()
  r <- tryCatch(withCallingHandlers(
      do.call(sx_discover_one, s[intersect(c("full", "tests", "vars", "focal_vars",
          "struct", "clustered", "i"), names(s))]),
      warning = function(w) { warns <<- c(warns, conditionMessage(w)); invokeRestart("muffleWarning") }),
    error = function(e) list(status = "failed", reason = conditionMessage(e), flags = ""))
  if (length(warns) && !identical(r$status, "failed") && !identical(r$status, "invalid")) {
    r$flags <- paste(c(if (nzchar(r$flags)) r$flags, unique(warns)), collapse = "; ")
    r$status <- "warning"
  }
  r$i <- s$i
  r
})

# ---- StatExplore: discovery setup ----
sx_disc_gstruct <- list(ri = c("ri", "independent", "lme4"), rs_uncorr = c("diag",
    "independent", "lme4"), rs = c("rs", "independent", "lme4"), nlme_ri = c("ri",
    "independent", "nlme"), nlme_diag = c("diag", "independent", "nlme"), nlme_rs = c("rs",
    "independent", "nlme"), ar1 = c("ri", "ar1", "nlme"), diag_ar1 = c("diag", "ar1",
    "nlme"), rs_ar1 = c("rs", "ar1", "nlme"), car1 = c("ri", "car1", "nlme"), diag_car1 = c("diag",
    "car1", "nlme"), rs_car1 = c("rs", "car1", "nlme"))  # structure key -> (random, residual, engine)
sx_disc_clustered <- FALSE  # participants nested in a higher-level cluster
sx_disc_has_cluster <- FALSE
sx_disc_vars <- c("v010", "v004", "v005", "v006", "v007", "v008", "v009", "v003", "v002")
sx_disc_family <- "lmm"
sx_disc_max_params <- 40
sx_disc_conf <- 0.95
sx_disc_min_obs <- 0
sx_disc_shared <- TRUE
sx_disc_fit_rules <- "fit-rules-4"  # part of every fit key
sx_cache_reset("search")
sx_dd <- sx_complete(dat, sx_disc_vars)  # shared complete-case sample
sx_disc_struct <- "ri"
sx_disc_reml <- FALSE  # REML only to compare covariance structures with a locked fixed part
sx_disc_gee_family <- "gaussian"
sx_disc_has_time <- TRUE
sx_dd$sx_gid <- factor(sx_dd$v002)  # participant (grouping, not a predictor)
sx_dd$sx_time <- as.numeric(sx_dd$v003)  # numeric time
sx_dd$sx_timef <- factor(sx_dd$sx_time)  # time as categories (categorical time, mmrm)
sx_dd$sx_occ <- as.integer(sx_dd$sx_timef)  # global observed-occasion index (AR(1), GEE waves)
sx_dd <- sx_dd[order(sx_dd$sx_gid, sx_dd$sx_time), , drop = FALSE]  # within-participant order
sx_dd$sx_y <- sx_dd$v010
sx_setup_info <- list(n = nrow(sx_dd), n_complete = sum(stats::complete.cases(sx_dd)))


# ---- StatExplore AMD validation (v1.3.3): one split / bootstrap chunk per call ----
# test rows whose category levels never occur in the training part cannot be predicted: counted and excluded (reported)
sx_val_seen <- function(train, test, vars) {
  ok <- rep(TRUE, nrow(test))
  for (v in vars) if (is.factor(test[[v]])) ok <- ok & as.character(test[[v]]) %in% unique(as.character(train[[v]]))
  ok
}
sx_val_with <- function(a, expr_fun) {
  if (!is.null(a$struct)) { o <- sx_disc_struct; sx_disc_struct <<- a$struct; on.exit(sx_disc_struct <<- o) }
  if (!is.null(a$clustered)) { oc <- sx_disc_clustered; sx_disc_clustered <<- a$clustered
    on.exit(sx_disc_clustered <<- oc, add = TRUE) }
  expr_fun()
}
sx_val_need <- function(a) c("sx_y", a$vars, if (sx_long()) c("sx_gid", if (sx_disc_has_cluster) "sx_cluster",
                                                                if (sx_disc_has_time) c("sx_time",
                                                                    "sx_timef", "sx_occ")))
sx_val_fit <- function(a, d) sx_val_with(a, function() {
  d <- sx_complete(d, sx_val_need(a))
  if (sx_long() && sx_disc_has_time) d$sx_occ <- as.integer(d$sx_timef)
  sx_fit_model(stats::reformulate(if (length(a$full)) a$full else "1", response = "sx_y"), d)
})
sx_val_score <- function(a) {
  # V134-002 / AUD134-01: the p rule ranks the natural-log p of the primary test (sx_primary_logp, shared with the legacy
  # workspace); a budget stop is never a failed candidate: it aborts the training part
  r <- tryCatch(sx_val_with(a, function() do.call(sx_discover_one, a)),
                error = function(e) if (inherits(e, "sx_budget")) stop(e) else NULL)
  if (is.null(r) || !(r$status %in% c("ok", "warning"))) return(list(score = NA_real_,
      log_p = NA_real_, rows = "",
    status = if (is.null(r)) "failed" else r$status, reason = if (is.null(r)) "fit error" else r$reason,
    loglik = NA_real_, statistic = NA_real_, df = NA_real_, ref_loglik = NA_real_, flags = "", ref_flags = "", aic = NA_real_))
  t1 <- if (length(r$tests)) r$tests[[1]] else list()
  g <- function(x) if (is.null(x) || !length(x)) NA_real_ else as.numeric(x)[1]
  lp <- sx_primary_logp(r)
  # comparability key: the analysed row identities and the response values (SHA-256 fingerprints of the fit)
  rk <- if (is.null(r$identity)) r$rows_sig else paste(r$identity$rows, r$identity$response)
  list(score = if (sx_val_rule == "aic") r$aic else lp, log_p = lp, rows = rk,
      status = r$status, reason = "",
       loglik = g(r$loglik), statistic = g(t1$statistic), df = g(t1$df1), ref_loglik = g(t1$reference_loglik),
       flags = paste(r$flags, collapse = "; "), ref_flags = if (is.null(t1$reference_flags)) "" else t1$reference_flags,
       aic = g(r$aic))
}
sx_val_trace <- list()   # every candidate evaluated in every training part / draw (audit, V134-015)
# AUD134-05: the fitted object's fixed terms must be the candidate's terms (fail closed otherwise)
sx_val_check_terms <- function(m, a) {
  f <- tryCatch(if (inherits(m, "merMod")) stats::formula(m, fixed.only = TRUE) else stats::formula(m),
                error = function(e) NULL)
  if (is.null(f)) stop("the fitted model's terms could not be read back")
  got <- attr(stats::terms(f), "term.labels"); got <- got[!grepl("|", got, fixed = TRUE)]
  if (!setequal(sx_canon_names(got), sx_canon_names(a$full)))
    stop(sprintf("the fitted terms (%s) differ from the candidate's terms (%s)",
        paste(sort(got), collapse = " + "),
                 paste(sort(a$full), collapse = " + ")))
  invisible(TRUE)
}
# AUD135-05: `at_cap` = the cap was consumed (not an error); `denied` = fits the cap REFUSED (work truncated)
sx_val_budget <- function() list(used = sx_fit_budget$used, retries = sx_fit_budget$retries,
    aux = sx_fit_budget$aux,
  cap = if (is.finite(sx_fit_budget$cap)) sx_fit_budget$cap else NA_real_, at_cap = sx_fit_budget$used >= sx_fit_budget$cap,
  denied = sx_fit_budget$denied, cache_hits = sx_disc_cache_log$hits, cache_misses = sx_disc_cache_log$misses)
# a part during which the cap refused any fit is a budget stop, never a scored / fitted part (even when a wrapper
# swallowed the refusal as a failed candidate: its selection would not have considered every candidate)
sx_val_denied_since <- function(d0) sx_fit_budget$denied > d0
sx_val_budget_reason <- "fit budget: a model fit was refused by the hard cap (part not scored; the selection could not consider every candidate)"
sx_val_predict <- function(m, newd) {
  if (inherits(m, "merMod")) {
    rf <- switch(sx_val_target, participant_in_cluster = ~ (1 | sx_cluster), NA)
    return(as.numeric(stats::predict(m, newdata = newd, re.form = rf, allow.new.levels = TRUE)))
  }
  if (inherits(m, "lme")) return(as.numeric(stats::predict(m, newdata = newd,
                                 level = if (sx_val_target == "participant_in_cluster") 1 else 0)))
  as.numeric(stats::predict(m, newdata = newd, type = "response"))
}
sx_val_coef <- function(m, a) {
  # V134-011: EVERY coefficient of the candidate's primary tested term(s), one record each (never the first column only)
  none <- data.frame(term = character(), coefficient = character(), estimate = numeric(),
      stringsAsFactors = FALSE)
  b <- tryCatch(if (inherits(m, "merMod")) lme4::fixef(m) else if (inherits(m,
      "lme")) nlme::fixef(m) else stats::coef(m),
                error = function(e) NULL)
  if (is.null(b) || !length(a$tests)) return(none)
  drop <- sx_canon_names(unlist(a$tests[[1]]$drop))
  f <- stats::reformulate(if (length(a$full)) a$full else "1", response = "sx_y")
  lab <- sx_canon_names(attr(stats::terms(f), "term.labels"))
  X <- tryCatch(stats::model.matrix(stats::delete.response(stats::terms(f)),
      sx_val_lastd), error = function(e) NULL)
  if (is.null(X)) return(none)
  asg <- attr(X, "assign")
  keep <- asg %in% which(lab %in% drop) & colnames(X) %in% names(b)
  if (!any(keep)) return(none)
  data.frame(term = lab[asg[keep]], coefficient = colnames(X)[keep], estimate = unname(b[colnames(X)[keep]]),
             stringsAsFactors = FALSE)
}
# Training-only selection (V134-004): every outcome-dependent step - fitting, eligibility, ranking and the search's own
# stopping rule (replayed in candidate order) - uses the training rows only; the candidate pool is the a-priori space.
sx_val_select <- function(train, ctx) {
  sx_dd <<- train
  sx_cache_reset(ctx)           # V134-001: a fresh fit cache for every independent sample
  n <- length(sx_val_cands)
  if (n == 1) return(list(j = 1L, score = NA_real_, scores = NA_real_, visited = 1L,
      n_sig = NA_integer_, scored = 1L))
  sc <- rep(NA_real_, n); rows <- rep("", n); n_sig <- 0L; visited <- 0L
  for (j in seq_len(n)) {
    s <- sx_val_score(sx_val_cands[[j]]); visited <- j
    sc[j] <- s$score; rows[j] <- s$rows
    sx_val_trace[[length(sx_val_trace) + 1]] <<- data.frame(part = ctx, candidate_index = sx_val_index[j],
      status = s$status, reason = s$reason, loglik = s$loglik, statistic = s$statistic, df = s$df, log_p = s$log_p,
      reference_loglik = s$ref_loglik, aic = s$aic, score = s$score, flags = s$flags, reference_flags = s$ref_flags,
      rows_sig = s$rows, stringsAsFactors = FALSE)
    if (is.finite(s$log_p) && s$log_p < log(sx_val_alpha)) n_sig <- n_sig + 1L
    if (!is.na(sx_val_stop) && n_sig >= sx_val_stop) break    # the search's stopping rule, on training data
  }
  ok <- which(!is.na(sc))
  if (!length(ok)) return(list(j = NA_integer_, score = NA_real_, scores = sc,
      visited = visited, n_sig = n_sig,
                               scored = 0L))
  if (sx_val_rule == "aic" && length(unique(rows[ok])) > 1)
    stop("AIC is not comparable here: the candidates were fitted to different training rows (per-model complete cases)")
  j <- sx_select_min(sc)         # exact ties: the lower candidate index (documented secondary key); NA never wins
  list(j = j, score = sc[j], scores = sc, visited = visited, n_sig = n_sig, scored = length(ok))
}
sx_val_fold_budget <- function(split_id, f, n_train, reason) list(split = split_id,
    fold = f, status = "budget",
  reason = reason, selected = "", selected_index = NA_integer_, selected_key = "", train_score = NA_real_,
  visited = NA_integer_, scored = NA_integer_, n_sig_train = NA_integer_, n_train = n_train, n_test = 0L,
  train_mean = NA_real_, train_groups = NA_real_, test_groups = NA_real_, train_clusters = NA_real_,
  test_clusters = NA_real_, excluded_incomplete = NA_real_, excluded_unseen_levels = NA_real_,
  excluded_unpredicted = NA_real_, test_events = NA_real_, diagnostics = "")
sx_val_split <- function(split_id, fold_of) {
  sx_val_trace <<- list()
  folds <- sort(unique(fold_of[!is.na(fold_of) & fold_of > 0]))
  preds <- list(); info <- list()
  for (f in folds) {
    tr <- sx_val_full[is.na(fold_of) | fold_of != f, , drop = FALSE]
    te <- sx_val_full[!is.na(fold_of) & fold_of == f, , drop = FALSE]
    d0 <- sx_fit_budget$denied; pf <- NULL
    res <- if (d0 > 0) sx_val_fold_budget(split_id, f, nrow(tr), "fit budget used up before this part started (not run)") else tryCatch({
      if (length(intersect(rownames(tr), rownames(te)))) stop("internal: a row is in both parts")
      if (sx_val_target != "rows" && length(intersect(as.character(tr$sx_gid),
          as.character(te$sx_gid))))
        stop("internal: a participant is in both parts")
      if (sx_val_target == "cluster" && length(intersect(as.character(tr$sx_cluster),
          as.character(te$sx_cluster))))
        stop("internal: a cluster is in both parts")
      if (sx_val_target == "participant_in_cluster" && !all(as.character(te$sx_cluster) %in% as.character(tr$sx_cluster)))
        stop("internal: a test cluster has no training rows")
      sel <- sx_val_select(tr, paste0(split_id, ":fold", f))
      if (is.na(sel$j)) stop("no candidate could be fitted on the training part")
      a <- sx_val_cands[[sel$j]]
      m <- sx_val_fit(a, tr)
      sx_val_check_terms(m, a)
      trc <- sx_complete(tr, sx_val_need(a))
      tec <- sx_complete(te, sx_val_need(a)); n_incomplete <- nrow(te) - nrow(tec)
      seen <- sx_val_seen(trc, tec, setdiff(a$vars, c("sx_timef", "sx_gid", "sx_cluster")))
      n_unseen <- sum(!seen); tec <- tec[seen, , drop = FALSE]
      if (sx_long() && sx_disc_has_time) tec$sx_occ <- as.integer(tec$sx_timef)
      p <- sx_val_predict(m, tec)
      ok <- is.finite(p)
      pf <- data.frame(split = split_id, fold = f, row_id = as.integer(rownames(tec))[ok],
        observed = tec$sx_y[ok], predicted = p[ok],
        participant = if (sx_long()) as.character(tec$sx_gid)[ok] else as.character(rownames(tec))[ok],
        cluster = if (sx_long() && sx_disc_has_cluster) as.character(tec$sx_cluster)[ok] else "", stringsAsFactors = FALSE)
      list(split = split_id, fold = f, status = "scored", reason = "",
          selected = sx_val_labels[sel$j],
           selected_index = sx_val_index[sel$j], selected_key = sx_val_keys[sel$j], train_score = sel$score,
           visited = sel$visited,
           scored = sel$scored, n_sig_train = sel$n_sig, n_train = nrow(trc), n_test = sum(ok),
           train_mean = mean(trc$sx_y), train_groups = if (sx_long()) nlevels(droplevels(trc$sx_gid)) else nrow(trc),
           test_groups = if (sx_long()) length(unique(as.character(tec$sx_gid[ok]))) else sum(ok),
           train_clusters = if (sx_long() && sx_disc_has_cluster) nlevels(droplevels(trc$sx_cluster)) else 0L,
           test_clusters = if (sx_long() && sx_disc_has_cluster) length(unique(as.character(tec$sx_cluster[ok]))) else 0L,
           excluded_incomplete = n_incomplete, excluded_unseen_levels = n_unseen, excluded_unpredicted = sum(!ok),
           test_events = if (sx_disc_family == "binomial" || identical(sx_disc_gee_family,
               "binomial")) sum(tec$sx_y[ok] == 1) else NA_real_,
           diagnostics = tryCatch(paste(sx_diag(m, sx_last_run)$flags,
               collapse = "; "), error = function(e) ""))
    }, error = function(e) list(split = split_id, fold = f, status = if (inherits(e,
        "sx_budget")) "budget" else "failed",
                                 reason = conditionMessage(e), selected = "", selected_index = NA_integer_,
                                 selected_key = "", train_score = NA_real_, visited = NA_integer_,
                                 scored = NA_integer_, n_sig_train = NA_integer_, n_train = nrow(tr),
                                 n_test = 0L, train_mean = NA_real_, train_groups = NA_real_, test_groups = NA_real_,
                                 train_clusters = NA_real_, test_clusters = NA_real_, excluded_incomplete = NA_real_,
                                 excluded_unseen_levels = NA_real_, excluded_unpredicted = NA_real_, test_events = NA_real_,
                                 diagnostics = ""))
    if (d0 == 0 && sx_val_denied_since(d0) && res$status != "budget") {
      res <- sx_val_fold_budget(split_id, f, nrow(tr), sx_val_budget_reason); pf <- NULL
    }
    if (!is.null(pf) && identical(res$status, "scored")) preds[[length(preds) + 1]] <- pf
    info[[length(info) + 1]] <- as.data.frame(res, stringsAsFactors = FALSE)
  }
  sx_dd <<- sx_val_full
  sx_cache_reset("search")
  list(folds = do.call(rbind, info), predictions = if (length(preds)) do.call(rbind,
      preds) else NULL,
       trace = if (length(sx_val_trace)) do.call(rbind, sx_val_trace) else NULL)
}
sx_val_boot_budget <- function(b, reason) list(b = b, status = "budget", reason = reason,
    selected = "",
  selected_index = NA_integer_, selected_key = "", train_score = NA_real_, visited = NA_integer_, scored = NA_integer_,
  n_sig_train = NA_integer_, coefficient = "", estimate = NA_real_, n_coef = 0L, diagnostics = "budget", flags = "",
  n = NA_real_, groups = NA_real_)
sx_val_boot <- function(draws) {
  out <- list(); coefs <- list(); sx_val_trace <<- list()
  for (b in sort(unique(draws$b))) {
    dr <- draws[draws$b == b, , drop = FALSE]
    d0 <- sx_fit_budget$denied; cfb <- NULL
    res <- if (d0 > 0) sx_val_boot_budget(b, "fit budget used up before this draw started (not run)") else tryCatch({
      d <- sx_val_full[match(as.character(dr$row_id), rownames(sx_val_full)), , drop = FALSE]
      keep <- !is.na(match(as.character(dr$row_id), rownames(sx_val_full)))
      d <- d[keep, , drop = FALSE]; dr <- dr[keep, , drop = FALSE]
      if (sx_long()) {
        d$sx_gid <- factor(dr$draw_gid)            # a unit drawn twice = two sampled units (new IDs)
        if (sx_disc_has_cluster) d$sx_cluster <- factor(ifelse(nzchar(dr$draw_cluster),
            dr$draw_cluster, as.character(d$sx_cluster)))
      }
      # deterministic, draw-specific row identities: draw b, position k in the draw (source row kept in the manifest)
      rownames(d) <- paste0("b", b, ".", seq_len(nrow(d)))
      if (sx_long() && sx_disc_has_time) d <- d[order(d$sx_gid, d$sx_time), , drop = FALSE]
      sel <- sx_val_select(d, paste0("boot", b))
      if (is.na(sel$j)) stop("no candidate could be fitted on this resample")
      a <- sx_val_cands[[sel$j]]
      m <- sx_val_fit(a, d)
      sx_val_check_terms(m, a)
      sx_val_lastd <<- sx_complete(d, sx_val_need(a))
      cf <- sx_val_coef(m, a)
      if (nrow(cf)) cfb <- data.frame(b = b, selected_index = sx_val_index[sel$j],
          selected_key = sx_val_keys[sel$j],
                                      cf, stringsAsFactors = FALSE)
      dg <- tryCatch(sx_diag(m, sx_last_run), error = function(e) list(status = "unknown",
          flags = character()))
      list(b = b, status = "fitted", reason = "", selected = sx_val_labels[sel$j],
          selected_index = sx_val_index[sel$j],
           selected_key = sx_val_keys[sel$j], train_score = sel$score, visited = sel$visited, scored = sel$scored, n_sig_train = sel$n_sig,
           coefficient = if (nrow(cf)) cf$coefficient[nrow(cf)] else "", estimate = if (nrow(cf)) cf$estimate[nrow(cf)] else NA_real_,
           n_coef = nrow(cf), diagnostics = paste(dg$status, collapse = ""),
           flags = paste(dg$flags, collapse = "; "), n = nrow(sx_val_lastd),
           groups = if (sx_long()) nlevels(droplevels(sx_val_lastd$sx_gid)) else nrow(sx_val_lastd))
    }, error = function(e) list(b = b, status = if (inherits(e, "sx_budget")) "budget" else "failed",
                                 reason = conditionMessage(e), selected = "", selected_index = NA_integer_,
                                 selected_key = "", train_score = NA_real_, visited = NA_integer_,
                                 scored = NA_integer_, n_sig_train = NA_integer_, coefficient = "", estimate = NA_real_,
                                 n_coef = 0L, diagnostics = "failed", flags = "", n = NA_real_, groups = NA_real_))
    if (d0 == 0 && sx_val_denied_since(d0) && res$status != "budget") { res <- sx_val_boot_budget(b,
        sx_val_budget_reason); cfb <- NULL }
    if (!is.null(cfb) && identical(res$status, "fitted")) coefs[[length(coefs) + 1]] <- cfb
    out[[length(out) + 1]] <- as.data.frame(res, stringsAsFactors = FALSE)
  }
  sx_dd <<- sx_val_full
  sx_cache_reset("search")
  list(draws = do.call(rbind, out), coefs = if (length(coefs)) do.call(rbind, coefs) else NULL,
       trace = if (length(sx_val_trace)) do.call(rbind, sx_val_trace) else NULL)
}

sx_val_cands <- list(list(full = c("v004", "v005", "v004:v005", "sx_time"), tests = list(list(id = 0L,
    type = "focal_interaction", reduced = c("v004", "v005", "sx_time"), drop = c("v004:v005"))),
    vars = c("v004", "v005", "sx_time"), focal_vars = c("v004", "v005")),
  list(full = c("v004", "v006", "v004:v006", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v004", "v006", "sx_time"), drop = c("v004:v006"))),
      vars = c("v004", "v006", "sx_time"), focal_vars = c("v004", "v006")),
  list(full = c("v004", "v007", "v004:v007", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v004", "v007", "sx_time"), drop = c("v004:v007"))),
      vars = c("v004", "v007", "sx_time"), focal_vars = c("v004", "v007")),
  list(full = c("v004", "v008", "v004:v008", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v004", "v008", "sx_time"), drop = c("v004:v008"))),
      vars = c("v004", "v008", "sx_time"), focal_vars = c("v004", "v008")),
  list(full = c("v004", "v009", "v004:v009", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v004", "v009", "sx_time"), drop = c("v004:v009"))),
      vars = c("v004", "v009", "sx_time"), focal_vars = c("v004", "v009")),
  list(full = c("v005", "v006", "v005:v006", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v005", "v006", "sx_time"), drop = c("v005:v006"))),
      vars = c("v005", "v006", "sx_time"), focal_vars = c("v005", "v006")),
  list(full = c("v005", "v007", "v005:v007", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v005", "v007", "sx_time"), drop = c("v005:v007"))),
      vars = c("v005", "v007", "sx_time"), focal_vars = c("v005", "v007")),
  list(full = c("v005", "v008", "v005:v008", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v005", "v008", "sx_time"), drop = c("v005:v008"))),
      vars = c("v005", "v008", "sx_time"), focal_vars = c("v005", "v008")),
  list(full = c("v005", "v009", "v005:v009", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v005", "v009", "sx_time"), drop = c("v005:v009"))),
      vars = c("v005", "v009", "sx_time"), focal_vars = c("v005", "v009")),
  list(full = c("v006", "v007", "v006:v007", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v006", "v007", "sx_time"), drop = c("v006:v007"))),
      vars = c("v006", "v007", "sx_time"), focal_vars = c("v006", "v007")),
  list(full = c("v006", "v008", "v006:v008", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v006", "v008", "sx_time"), drop = c("v006:v008"))),
      vars = c("v006", "v008", "sx_time"), focal_vars = c("v006", "v008")),
  list(full = c("v006", "v009", "v006:v009", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v006", "v009", "sx_time"), drop = c("v006:v009"))),
      vars = c("v006", "v009", "sx_time"), focal_vars = c("v006", "v009")),
  list(full = c("v007", "v008", "v007:v008", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v007", "v008", "sx_time"), drop = c("v007:v008"))),
      vars = c("v007", "v008", "sx_time"), focal_vars = c("v007", "v008")),
  list(full = c("v007", "v009", "v007:v009", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v007", "v009", "sx_time"), drop = c("v007:v009"))),
      vars = c("v007", "v009", "sx_time"), focal_vars = c("v007", "v009")),
  list(full = c("v008", "v009", "v008:v009", "sx_time"), tests = list(list(id = 0L,
      type = "focal_interaction", reduced = c("v008", "v009", "sx_time"), drop = c("v008:v009"))),
      vars = c("v008", "v009", "sx_time"), focal_vars = c("v008", "v009")))
sx_val_labels <- c("X01 \u00d7 X02 [#0]", "X01 \u00d7 X03 [#1]", "X01 \u00d7 X04 [#2]",
    "X01 \u00d7 X05 [#3]", "X01 \u00d7 X06 [#4]", "X02 \u00d7 X03 [#5]", "X02 \u00d7 X04 [#6]",
    "X02 \u00d7 X05 [#7]", "X02 \u00d7 X06 [#8]", "X03 \u00d7 X04 [#9]", "X03 \u00d7 X05 [#10]",
    "X03 \u00d7 X06 [#11]", "X04 \u00d7 X05 [#12]", "X04 \u00d7 X06 [#13]", "X05 \u00d7 X06 [#14]")
sx_val_keys <- c("X01:X02|Time+X01+X01:X02+X02", "X01:X03|Time+X01+X01:X03+X03",
    "X01:X04|Time+X01+X01:X04+X04", "X01:X05|Time+X01+X01:X05+X05", "X01:X06|Time+X01+X01:X06+X06",
    "X02:X03|Time+X02+X02:X03+X03", "X02:X04|Time+X02+X02:X04+X04", "X02:X05|Time+X02+X02:X05+X05",
    "X02:X06|Time+X02+X02:X06+X06", "X03:X04|Time+X03+X03:X04+X04", "X03:X05|Time+X03+X03:X05+X05",
    "X03:X06|Time+X03+X03:X06+X06", "X04:X05|Time+X04+X04:X05+X05", "X04:X06|Time+X04+X04:X06+X06",
    "X05:X06|Time+X05+X05:X06+X06")
sx_val_index <- c(0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0)
sx_val_rule <- "p"
sx_val_target <- "participant"
sx_val_alpha <- 0.05
sx_val_stop <- NA  # the search's stopping rule, replayed on training data (NA = none)
if (!exists("sx_disc_gee_family")) sx_disc_gee_family <- ""
sx_val_full <- sx_dd; sx_val_lastd <- sx_dd
sx_rep_pred <- list(); sx_rep_folds <- list(); sx_rep_boot <- list(); sx_rep_coef <- list()
sx_rep_trace <- list(); sx_rep_man <- list(); sx_rep_draws <- list()
# ---- committed chunk 1 ----
sx_vfold <- NULL; sx_vdraws <- NULL; sx_vr <- NULL
sx_budget_reset(20000)  # hard budget: model-fitting invocations left for this chunk
sx_disc_cache_log$hits <- 0L; sx_disc_cache_log$misses <- 0L
sx_vfold <- c(0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1,
    1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1,
    1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
    1, 1, 1)
names(sx_vfold) <- c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
    18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37,
    38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57,
    58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77,
    78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97,
    98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113,
    114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129,
    130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145,
    146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161,
    162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177,
    178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193,
    194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209,
    210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225,
    226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241,
    242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257,
    258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273,
    274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289,
    290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305,
    306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321,
    322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337,
    338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353,
    354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369,
    370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385,
    386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401,
    402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417,
    418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433,
    434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449,
    450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465,
    466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481,
    482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497,
    498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513,
    514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529,
    530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545,
    546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561,
    562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577,
    578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593,
    594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609,
    610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625,
    626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641,
    642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657,
    658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673,
    674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689,
    690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705,
    706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721,
    722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737,
    738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753,
    754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769,
    770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785,
    786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801,
    802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817,
    818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833,
    834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849,
    850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865,
    866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881,
    882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897,
    898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913,
    914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929,
    930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945,
    946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960)
sx_vf <- unname(sx_vfold[rownames(sx_val_full)])
sx_vr <- sx_val_split("holdout", sx_vf)
sx_result <- list(folds = sx_vr$folds, predictions = sx_vr$predictions, trace = sx_vr$trace)
if (!is.null(sx_vfold)) sx_rep_man[[length(sx_rep_man) + 1]] <- data.frame(split = sx_vr$folds$split[1],
  row_id = as.integer(names(sx_vfold)), fold = unname(sx_vfold), stringsAsFactors = FALSE)
if (!is.null(sx_vdraws)) sx_rep_draws[[length(sx_rep_draws) + 1]] <- data.frame(b = sx_vdraws$b,
  position = stats::ave(seq_along(sx_vdraws$b), sx_vdraws$b, FUN = seq_along), row_id = sx_vdraws$row_id,
  draw_participant = sx_vdraws$draw_gid, draw_cluster = sx_vdraws$draw_cluster, stringsAsFactors = FALSE)
if (!is.null(sx_result$predictions)) sx_rep_pred[[length(sx_rep_pred) + 1]] <- sx_result$predictions
if (!is.null(sx_result$folds)) sx_rep_folds[[length(sx_rep_folds) + 1]] <- sx_result$folds
if (!is.null(sx_result$trace)) sx_rep_trace[[length(sx_rep_trace) + 1]] <- sx_result$trace
if (!is.null(sx_result$boot)) { sx_rep_boot[[length(sx_rep_boot) + 1]] <- sx_result$boot$draws
  if (!is.null(sx_result$boot$trace)) sx_rep_trace[[length(sx_rep_trace) + 1]] <- sx_result$boot$trace
  if (!is.null(sx_result$boot$coefs)) sx_rep_coef[[length(sx_rep_coef) + 1]] <- sx_result$boot$coefs }
sx_bind <- function(x) if (length(x)) do.call(rbind, x) else NULL
sx_P <- sx_bind(sx_rep_pred); sx_F <- sx_bind(sx_rep_folds); sx_B <- sx_bind(sx_rep_boot)
sx_C <- sx_bind(sx_rep_coef); sx_T <- sx_bind(sx_rep_trace); sx_M <- sx_bind(sx_rep_man); sx_D <- sx_bind(sx_rep_draws)
if (!is.null(sx_P)) utils::write.csv(sx_P, "reproduced_predictions.csv", row.names = FALSE)
if (!is.null(sx_F)) utils::write.csv(sx_F, "reproduced_folds.csv", row.names = FALSE)
if (!is.null(sx_B)) utils::write.csv(sx_B, "reproduced_bootstrap.csv", row.names = FALSE)
if (!is.null(sx_C)) utils::write.csv(sx_C, "reproduced_coefficients.csv", row.names = FALSE)
if (!is.null(sx_T)) utils::write.csv(sx_T, "reproduced_trace.csv", row.names = FALSE)
# ---- declarations embedded by StatExplore (independent of the exported files under test) ----
sx_schema <- list(
  manifest = list(keys = c("split", "row_id"), status_ok = NULL, cols = data.frame(name = c("split",
      "mode", "repeat", "row_id", "participant", "cluster", "fold"), type = c("text",
      "text", "int", "int", "text", "text", "int"), flags = c("", "", "", "", "",
      "", ""), stringsAsFactors = FALSE)),
  draws = list(keys = c("b", "position"), status_ok = NULL, cols = data.frame(name = c("b",
      "position", "row_id", "draw_participant", "draw_cluster", "original_participant",
      "original_cluster"), type = c("int", "int", "int", "text", "text", "text",
      "text"), flags = c("", "", "", "", "", "", ""), stringsAsFactors = FALSE)),
  predictions = list(keys = c("split", "fold", "row_id"), status_ok = NULL,
      cols = data.frame(name = c("split", "fold", "row_id", "observed", "predicted",
      "participant", "cluster"), type = c("text", "int", "int", "num", "num", "text",
      "text"), flags = c("", "", "", "tol=tol", "tol=tol", "", ""), stringsAsFactors = FALSE)),
  folds = list(keys = c("split", "fold"), status_ok = "scored", cols = data.frame(name = c("split",
      "fold", "status", "reason", "selected", "selected_index", "selected_key", "train_score",
      "visited", "scored", "n_sig_train", "n_train", "n_test", "train_mean", "train_groups",
      "test_groups", "train_clusters", "test_clusters", "excluded_incomplete", "excluded_unseen_levels",
      "excluded_unpredicted", "test_events", "diagnostics", "mode", "repeat"), type = c("text",
      "int", "text", "text", "text", "int", "text", "num", "int", "int", "int", "int",
      "int", "num", "int", "int", "int", "int", "int", "int", "int", "int", "text",
      "text", "int"), flags = c("", "", "", "", "", "na need=scored", "", "na inf tol=fit",
      "na", "na", "na", "", "", "na need=scored tol=tol", "na", "na", "na", "na",
      "na", "na", "na", "na", "", "", ""), stringsAsFactors = FALSE)),
  performance = list(keys = c("split", "fold", "weighting"), status_ok = NULL,
      cols = data.frame(name = c("split", "fold", "weighting", "n"), type = c("text",
      "int", "text", "int"), flags = c("", "", "", ""), stringsAsFactors = FALSE)),
  bootstrap = list(keys = c("b"), status_ok = "fitted", cols = data.frame(name = c("b",
      "status", "reason", "selected", "selected_index", "selected_key", "train_score",
      "visited", "scored", "n_sig_train", "coefficient", "estimate", "n_coef", "diagnostics",
      "flags", "n", "groups", "coefficient_label"), type = c("int", "text", "text",
      "text", "int", "text", "num", "int", "int", "int", "text", "num", "int", "text",
      "text", "int", "int", "text"), flags = c("", "", "", "", "na need=fitted",
      "", "na inf tol=fit", "na", "na", "na", "", "na tol=fit", "", "", "", "na need=fitted",
      "na need=fitted", ""), stringsAsFactors = FALSE)),
  coefs = list(keys = c("b", "selected_index", "coefficient"), status_ok = NULL,
      cols = data.frame(name = c("b", "selected_index", "selected_key", "term", "coefficient",
      "estimate"), type = c("int", "int", "text", "text", "text", "num"), flags = c("",
      "", "", "", "", "tol=fit"), stringsAsFactors = FALSE)),
  stability = list(keys = c("candidate_index"), status_ok = NULL, cols = data.frame(name = c("candidate_index",
      "candidate_key", "candidate", "selected", "attempted", "successful", "freq_of_attempted",
      "freq_of_successful", "flagged_fits", "coefficient", "positive_sign", "estimate_p2.5",
      "estimate_median", "estimate_p97.5"), type = c("int", "text", "text", "int",
      "int", "int", "num", "num", "int", "text", "num", "num", "num", "num"), flags = c("",
      "", "", "", "", "", "na tol=tight", "na tol=tight", "", "", "na tol=tight",
      "na tol=fit", "na tol=fit", "na tol=fit"), stringsAsFactors = FALSE)),
  estimands = list(keys = c("candidate_index", "coefficient"), status_ok = NULL,
      cols = data.frame(name = c("candidate_index", "candidate", "term", "coefficient",
      "coefficient_label", "draws_selected", "draws_with_estimate", "positive_sign",
      "estimate_p2.5", "estimate_median", "estimate_p97.5"), type = c("int", "text",
      "text", "text", "text", "int", "int", "num", "num", "num", "num"), flags = c("",
      "", "", "", "", "", "", "na tol=tight", "na tol=fit", "na tol=fit", "na tol=fit"),
      stringsAsFactors = FALSE)),
  trace = list(keys = c("part", "candidate_index"), status_ok = NULL, cols = data.frame(name = c("part",
      "candidate_index", "status", "reason", "loglik", "statistic", "df", "log_p",
      "reference_loglik", "aic", "score", "flags", "reference_flags", "rows_sig"),
      type = c("text", "int", "text", "text", "num", "num", "num", "num", "num",
      "num", "num", "text", "text", "text"), flags = c("", "", "", "", "na tol=fit",
      "na inf tol=fit", "na tol=fit", "na inf tol=fit", "na tol=fit", "na tol=fit",
      "na inf tol=fit", "", "", ""), stringsAsFactors = FALSE)),
  realized = list(keys = c("split", "fold"), status_ok = NULL, cols = data.frame(name = c("split",
      "mode", "fold", "requested_fraction", "test_units", "units", "realized_unit_fraction",
      "test_rows", "rows", "realized_row_fraction", "rule"), type = c("text", "text",
      "int", "num", "int", "int", "num", "int", "int", "num", "text"), flags = c("",
      "", "", "tol=tight", "", "", "na tol=tight", "", "", "na tol=tight", ""), stringsAsFactors = FALSE)),
  ledger = list(keys = c("part"), status_ok = NULL, cols = data.frame(name = c("part",
      "mode", "split", "fold", "b", "chunk", "status", "committed"), type = c("text",
      "text", "text", "int", "int", "int", "text", "bool"), flags = c("", "", "",
      "na", "na", "", "", ""), stringsAsFactors = FALSE)))
sx_expect <- data.frame(file = c("split_manifest.csv", "bootstrap_draws.csv",
    "predictions.csv", "folds.csv", "performance.csv", "stability.csv", "bootstrap_results.csv",
    "bootstrap_estimands.csv", "bootstrap_coefficients.csv", "candidate_trace.csv",
    "realized_sizes.csv", "execution_ledger.csv"), required = c(TRUE, FALSE, TRUE,
    TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, TRUE, TRUE, TRUE), rows = c(960, 0, 192,
    1, 3, 0, 0, 0, 0, 15, 1, 1), applicable = c(TRUE, FALSE, TRUE, TRUE, TRUE, FALSE,
    FALSE, FALSE, FALSE, TRUE, TRUE, TRUE), stringsAsFactors = FALSE)
sx_ledger <- data.frame(`part` = c("holdout:fold1"), `mode` = c("holdout"), `split` = c("holdout"),
    `fold` = c(1), `b` = c(NA), `chunk` = c(1), `status` = c("scored"), `committed` = c(TRUE),
    stringsAsFactors = FALSE, check.names = FALSE)
sx_pend_M <- NULL   # planned, not committed (not replayed)
sx_pend_D <- NULL   # planned, not committed
sx_plan_splits <- data.frame(`split` = c("holdout"), `mode` = c("holdout"), `repeat` = c(1),
    `rule` = c("ceil(fraction x units) test units"), stringsAsFactors = FALSE, check.names = FALSE)
sx_val_cfg <- list(holdout_fraction = 0.2, k = 5)
sx_alias <- c(v001 = "School", v002 = "StudentID", v003 = "Time", v004 = "X01",
    v005 = "X02", v006 = "X03", v007 = "X04", v008 = "X05", v009 = "X06", v010 = "Y")
sx_app_status <- "complete"
sx_binary <- FALSE
sx_target <- "participant"
if (sx_binary) sx_schema$performance$cols <- rbind(sx_schema$performance$cols,
    data.frame(name = c("log_loss", "Brier", "AUC"), type = "num", flags = "na tol=tol",
    stringsAsFactors = FALSE)) else sx_schema$performance$cols <- rbind(sx_schema$performance$cols,
    data.frame(name = c("RMSE", "MAE", "R2_out_of_sample"), type = "num", flags = "na tol=tol",
    stringsAsFactors = FALSE))

# ---- verification against the app's exported evidence (AUD134-11; typed and complete since v1.3.6, AUD135-01/02/04) ----
# Every check is listed in validation_check_results.csv (PASS / FAIL / NOT APPLICABLE); the script exits with status 1
# when any check fails. A check is NOT APPLICABLE only when the embedded declaration says so - an indeterminate or
# malformed comparison is a FAIL. Every evidence file is read as TEXT (no type guessing: "001" stays "001", the literal
# "NA" is text, "" is the declared missing value) and parsed by the declared field type embedded below (never inferred
# from the file under test). Numbers: finite / +Inf / -Inf / missing / malformed are distinct; signed infinities match
# only the same sign; malformed text never matches anything. Keys are length-prefixed UTF-8 (no delimiter collisions)
# and must be unique on both sides; missing / extra / duplicate rows fail.
# Values are recomputed from the reproduced fits - predictions, folds, draws, coefficients and trace by replaying the
# committed chunks; performance, stability (selection frequencies over the DECLARED candidate pool, sign stability,
# type-7 percentiles), estimands and realized sizes by independent R code from those reproduced values. The planned
# split / draw manifests and the execution ledger are metadata: verified against the plan embedded in this script.
# Tolerances: predictions / observed / metrics abs 1e-6 + rel 1e-6; log p, statistics, log-likelihoods, AIC and
# coefficient estimates abs 1e-6 + rel 1e-6 (optimizer-sensitive mixed-model fits: rel 1e-5); fractions abs 1e-12 +
# rel 1e-12; counts, statuses, indices, keys and text exact.
sx_chk <- data.frame(check = character(), status = character(), detail = character(),
    stringsAsFactors = FALSE)
sx_add_chk <- function(check, ok, detail = "", applicable = TRUE) {
  st <- if (identical(applicable, FALSE)) "NOT APPLICABLE" else if (length(ok) == 1L && isTRUE(ok)) "PASS" else "FAIL"
  sx_chk[nrow(sx_chk) + 1L, ] <<- list(check, st, as.character(detail)[1])
  invisible(st == "PASS")
}
sx_read <- function(f) if (file.exists(f)) utils::read.csv(f, colClasses = "character",
    na.strings = character(0),
  check.names = FALSE, encoding = "UTF-8", strip.white = FALSE, stringsAsFactors = FALSE) else NULL
sx_num_re <- "^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][+-]?[0-9]+)?$"
# state of each value: "num" (finite), "inf", "-inf", "na" (declared missing) or "bad" (malformed / NaN)
sx_parse_num <- function(x) {
  n <- length(x)
  if (is.numeric(x) || is.logical(x)) {
    x <- as.numeric(x)
    st <- ifelse(is.nan(x), "bad", ifelse(is.na(x), "na", ifelse(is.infinite(x),
        ifelse(x > 0, "inf", "-inf"), "num")))
    return(list(value = x, state = st))
  }
  x <- as.character(x); st <- rep("bad", n); val <- rep(NA_real_, n)
  st[is.na(x) | x == ""] <- "na"
  pinf <- !is.na(x) & x %in% c("Inf", "+Inf"); ninf <- !is.na(x) & x == "-Inf"
  st[pinf] <- "inf"; val[pinf] <- Inf; st[ninf] <- "-inf"; val[ninf] <- -Inf
  fin <- which(!is.na(x) & grepl(sx_num_re, x))
  if (length(fin)) {
    v <- suppressWarnings(as.numeric(x[fin])); nz <- grepl("[1-9]", sub("[eE].*$", "", x[fin]))
    good <- is.finite(v) & !(v == 0 & nz)            # decimal overflow / silent underflow to 0 are malformed
    st[fin[good]] <- "num"; val[fin[good]] <- v[good]
  }
  list(value = val, state = st)
}
# typed numeric equality: total (never NA); missing equals missing only if `missing`, infinities only same-sign if `inf`
sx_num_ok <- function(a, b, abs_tol, rel_tol, missing = TRUE, inf = TRUE) {
  p <- sx_parse_num(a); q <- sx_parse_num(b)
  if (length(p$state) != length(q$state)) return(FALSE)
  ok <- rep(FALSE, length(p$state))
  ok[p$state == "na" & q$state == "na"] <- isTRUE(missing)
  i <- p$state %in% c("inf", "-inf") & q$state %in% c("inf", "-inf")
  ok[i] <- isTRUE(inf) & p$state[i] == q$state[i]
  f <- p$state == "num" & q$state == "num"
  x <- p$value[f]; y <- q$value[f]; sc <- pmax(abs(x), abs(y), 1)
  ok[f] <- abs(x / sc - y / sc) <= abs_tol / sc + rel_tol * pmax(abs(x), abs(y)) / sc
  ok
}
sx_parse_int <- function(x) {
  if (is.numeric(x) || is.logical(x)) {
    x <- as.numeric(x)
    st <- ifelse(is.na(x) & !is.nan(x), "na", ifelse(!is.na(x) & is.finite(x) & x == round(x) & abs(x) <= 2^53,
        "int", "bad"))
    v <- rep(NA_character_, length(x)); v[st == "int"] <- sprintf("%.0f", x[st == "int"] + 0)
    return(list(value = v, state = st))
  }
  x <- as.character(x)
  st <- ifelse(is.na(x) | x == "", "na", ifelse(grepl("^-?(0|[1-9][0-9]{0,15})$", x), "int", "bad"))
  v <- rep(NA_character_, length(x)); v[st == "int"] <- x[st == "int"]
  list(value = v, state = st)
}
sx_int_ok <- function(a, b, missing = FALSE) {
  p <- sx_parse_int(a); q <- sx_parse_int(b)
  if (length(p$state) != length(q$state)) return(FALSE)
  ok <- p$state == "int" & q$state == "int" & p$value == q$value
  ok[is.na(ok)] <- FALSE
  ok | (p$state == "na" & q$state == "na" & isTRUE(missing))
}
sx_text_ok <- function(a, b) {     # exact UTF-8 text; a missing text value is "" (declared convention)
  a <- as.character(a); b <- as.character(b); if (length(a) != length(b)) return(FALSE)
  a[is.na(a)] <- ""; b[is.na(b)] <- ""
  enc2utf8(a) == enc2utf8(b)
}
sx_bool_ok <- function(a, b) {
  tx <- function(x) if (is.logical(x)) ifelse(is.na(x), "bad", ifelse(x, "TRUE", "FALSE")) else
    ifelse(as.character(x) %in% c("TRUE", "FALSE"), as.character(x), "bad")
  x <- tx(a); y <- tx(b); if (length(x) != length(y)) return(FALSE)
  x != "bad" & x == y
}
# length-prefixed composite key (no delimiter collision); integer keys canonical; missing / malformed keys stop
sx_key <- function(d, cols, types) {
  if (!nrow(d)) return(character())
  parts <- lapply(seq_along(cols), function(i) {
    x <- d[[cols[i]]]
    if (is.null(x)) stop("key column ", cols[i], " missing")
    if (types[i] == "int") { p <- sx_parse_int(x); if (any(p$state != "int")) stop("invalid integer key ",
        cols[i]); x <- p$value }
    else { x <- as.character(x); if (anyNA(x)) stop("missing key ", cols[i]); x <- enc2utf8(x) }
    paste0(nchar(x, type = "bytes"), ":", x, ";")
  })
  do.call(paste0, parts)
}
sx_empty <- function(cols) as.data.frame(stats::setNames(lapply(cols, function(i) character()),
    cols),
                                         stringsAsFactors = FALSE, check.names = FALSE)
sx_tol <- c(1e-6, 1e-6)
sx_tol_fit <- c(1e-6, if (sx_long()) 1e-5 else 1e-6)
sx_tol_tight <- c(1e-12, 1e-12)
# compare one exported evidence file with its reproduced / recomputed table, field by declared field
sx_compare <- function(name, file, rep, spec, skip = character()) {
  app <- sx_read(file)
  if (is.null(app)) return(invisible(sx_add_chk(paste0(name, ": file"), FALSE,
      paste("required file missing:", file))))
  cols <- spec$cols$name; types <- spec$cols$type; flags <- spec$cols$flags
  okc <- identical(names(app), cols)
  sx_add_chk(paste0(name, ": columns"), okc, if (okc) "the declared columns, in order" else
             paste("expected", paste(cols, collapse = ","), "got",
                 paste(names(app), collapse = ",")))
  if (!okc) return(invisible(FALSE))
  if (is.null(rep)) rep <- sx_empty(cols)
  lack <- setdiff(setdiff(cols, skip), names(rep))
  if (length(lack)) return(invisible(sx_add_chk(paste0(name, ": reproduced columns"), FALSE,
                                                paste("not reproduced:",
                                                    paste(lack, collapse = ", ")))))
  kt <- types[match(spec$keys, cols)]
  ka <- tryCatch(sx_key(app, spec$keys, kt), error = function(e) e)
  kr <- tryCatch(sx_key(rep, spec$keys, kt), error = function(e) e)
  if (inherits(ka, "error") || inherits(kr, "error"))
    return(invisible(sx_add_chk(paste0(name, ": keys"), FALSE, conditionMessage(if (inherits(ka,
        "error")) ka else kr))))
  sx_add_chk(paste0(name, ": unique keys (app)"), !anyDuplicated(ka), paste(sum(duplicated(ka)),
      "duplicate key(s)"))
  sx_add_chk(paste0(name, ": unique keys (reproduced)"), !anyDuplicated(kr),
      paste(sum(duplicated(kr)), "duplicate key(s)"))
  sx_add_chk(paste0(name, ": same rows"), length(ka) == length(kr) && setequal(ka, kr),
             sprintf("app %d, reproduced %d, only in app %d, only reproduced %d",
                 length(ka), length(kr),
                     length(setdiff(ka, kr)), length(setdiff(kr, ka))))
  i <- match(kr, ka); k <- !is.na(i)
  A <- app[i[k], , drop = FALSE]; R <- rep[k, , drop = FALSE]
  st <- if (!is.null(spec$status_ok) && "status" %in% names(R)) as.character(R$status) else NULL
  for (j in seq_along(cols)) {
    col <- cols[j]
    if (col %in% c(spec$keys, skip)) next
    fl <- strsplit(flags[j], " ", fixed = TRUE)[[1]]
    na_ok <- "na" %in% fl; inf_ok <- "inf" %in% fl
    need <- sub("^need=", "", fl[startsWith(fl, "need=")]); tc <- sub("^tol=",
        "", fl[startsWith(fl, "tol=")])
    a <- A[[col]]; r <- R[[col]]
    res <- tryCatch(switch(types[j],
      text = sx_text_ok(a, r), int = sx_int_ok(a, r, na_ok), bool = sx_bool_ok(a, r),
      num = { tl <- if (identical(tc, "tight")) sx_tol_tight else if (identical(tc,
          "fit")) sx_tol_fit else sx_tol
              sx_num_ok(a, r, tl[1], tl[2], na_ok, inf_ok) },
      stop("unknown declared type ", types[j])), error = function(e) FALSE)
    if (length(need) && !is.null(st) && length(res) == length(st)) {
      present <- !(sx_parse_num(a)$state %in% c("na", "bad")) & !(sx_parse_num(r)$state %in% c("na",
          "bad"))
      res[st %in% need & !present] <- FALSE
    }
    d <- if (types[j] == "num") { x <- sx_parse_num(a)$value; y <- sx_parse_num(r)$value; dd <- abs(x - y)
           if (any(is.finite(dd))) sprintf("; max |difference| %.3g",
               max(dd[is.finite(dd)])) else "" } else ""
    sx_add_chk(paste0(name, ": ", col), length(res) == nrow(A) && all(res),
               paste0(sum(!res), " of ", length(res), " row(s) differ or are invalid", d))
  }
  invisible(TRUE)
}
# same label <=> same R group (identity mapping of the app's unit keys onto the analysed data's grouping)
sx_partition_ok <- function(labels, groups) {
  a <- as.character(labels); g <- as.character(groups)
  if (anyNA(a) || anyNA(g)) return(FALSE)
  pa <- paste0(nchar(a, type = "bytes"), ":", a, ";", g)
  length(unique(pa)) == length(unique(a)) && length(unique(a)) == length(unique(g))
}
sx_pos <- function(row_id) match(as.character(row_id), rownames(sx_val_full))
sx_unit_part <- function(row_id) { p <- sx_pos(row_id)
  if (sx_long()) as.character(sx_val_full$sx_gid)[p] else ifelse(is.na(p),
      NA_character_, as.character(row_id)) }
sx_unit_clus <- function(row_id) { p <- sx_pos(row_id)
  if (sx_long() && sx_disc_has_cluster) as.character(sx_val_full$sx_cluster)[p] else ifelse(is.na(p),
      NA_character_, "") }
sx_coef_display <- function(x) vapply(as.character(x), function(nm) {
  if (is.na(nm) || !nzchar(nm)) return("")
  out <- vapply(strsplit(nm, ":", fixed = TRUE)[[1]], function(p) {
    if (p %in% c("sx_time", "sx_timef")) return("Time")
    m <- regmatches(p, regexec("^(v[0-9]{3,})(.*)$", p))[[1]]
    if (length(m) == 3 && m[2] %in% names(sx_alias)) return(paste0(sx_alias[[m[2]]],
        if (nzchar(m[3])) paste0(" [", m[3], "]") else ""))
    p }, "", USE.NAMES = FALSE)
  paste(out, collapse = " × ")
}, "", USE.NAMES = FALSE)
sx_auc2 <- function(y, p) { n1 <- sum(y == 1); n0 <- sum(y == 0); if (n1 == 0 || n0 == 0) return(NA_real_)
  r <- rank(p); (sum(r[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0) }
sx_met <- function(y, p, b, binary) {
  if (binary) { q <- pmin(pmax(p, 1e-12), 1 - 1e-12)
    return(c(log_loss = -mean(y * log(q) + (1 - y) * log(1 - q)), Brier = mean((y - p)^2),
        AUC = sx_auc2(y, p))) }
  e <- y - p; den <- sum((y - b)^2)
  c(RMSE = sqrt(mean(e^2)), MAE = mean(abs(e)), R2_out_of_sample = if (den > 0) 1 - sum(e^2) / den else NA_real_)
}
# an independent R implementation of the app's aggregation (per fold; pooled observation-weighted; group-weighted)
sx_perf <- function(P, F, binary, target) {
  if (is.null(P) || !nrow(P)) return(NULL)
  F <- F[F$status == "scored", , drop = FALSE]
  P$base <- F$train_mean[match(paste(P$split, P$fold), paste(F$split, F$fold))]
  out <- list()
  for (k in unique(paste(P$split, P$fold))) {
    g <- P[paste(P$split, P$fold) == k, , drop = FALSE]
    out[[length(out) + 1]] <- data.frame(split = g$split[1], fold = g$fold[1],
        weighting = "fold", n = nrow(g),
                                         t(sx_met(g$observed,
                                             g$predicted, g$base, binary)), check.names = FALSE)
  }
  mode <- sub("[0-9]+$", "", P$split); unit <- if (target == "cluster") "cluster" else "participant"
  for (m in unique(mode)) {
    g <- P[mode == m, , drop = FALSE]
    out[[length(out) + 1]] <- data.frame(split = m, fold = 0, weighting = "observation-weighted (pooled rows)",
                                         n = nrow(g), t(sx_met(g$observed,
                                             g$predicted, g$base, binary)), check.names = FALSE)
    if (!binary && target != "rows") {
      u <- paste(g$split, g[[unit]]); se <- tapply((g$observed - g$predicted)^2, u, mean)
      ae <- tapply(abs(g$observed - g$predicted), u, mean)
      out[[length(out) + 1]] <- data.frame(split = m, fold = 0, weighting = paste0(unit,
          "-weighted (each ", unit, " once)"),
                                           n = length(se), RMSE = sqrt(mean(se)), MAE = mean(ae), R2_out_of_sample = NA_real_,
                                           check.names = FALSE)
    }
  }
  do.call(rbind, out)
}
# AUD135-02: selection frequencies over the DECLARED pool (index / key / label from the search setup, never from
# stability.csv), denominators = committed draws / successful draws, sign stability and type-7 percentiles of the
# estimates of the draws that selected the candidate; failed draws are never zeros
sx_pool <- data.frame(index = as.numeric(sx_val_index), key = as.character(sx_val_keys),
                      label = as.character(sx_val_labels), stringsAsFactors = FALSE)
sx_q <- function(e, p) if (length(e)) stats::quantile(e, p, type = 7, names = FALSE) else NA_real_
sx_stability <- function(B) {
  if (is.null(B) || !nrow(B)) return(NULL)
  ok <- B[B$status == "fitted", , drop = FALSE]; att <- nrow(B); nok <- nrow(ok)
  do.call(rbind, lapply(seq_len(nrow(sx_pool)), function(j) {
    sel <- ok[!is.na(ok$selected_index) & as.numeric(ok$selected_index) == sx_pool$index[j],
        , drop = FALSE]
    est <- suppressWarnings(as.numeric(sel$estimate)); est <- est[!is.na(est)]
    data.frame(candidate_index = sx_pool$index[j], candidate_key = sx_pool$key[j],
        candidate = sx_pool$label[j],
               selected = nrow(sel), attempted = att, successful = nok,
               freq_of_attempted = if (att) nrow(sel) / att else NA_real_,
               freq_of_successful = if (nok) nrow(sel) / nok else NA_real_,
               flagged_fits = sum(as.character(sel$diagnostics) != "clean"),
               coefficient = if (nrow(sel)) sx_coef_display(sel$coefficient[1]) else "",
               positive_sign = if (length(est)) mean(est > 0) else NA_real_, `estimate_p2.5` = sx_q(est,
                   0.025),
               estimate_median = if (length(est)) stats::median(est) else NA_real_, `estimate_p97.5` = sx_q(est,
                   0.975),
               check.names = FALSE, stringsAsFactors = FALSE)
  }))
}
sx_estimands <- function(B, C) {
  if (is.null(C) || !nrow(C)) return(NULL)
  ok <- B[B$status == "fitted", , drop = FALSE]
  g <- unique(C[, c("selected_index", "coefficient")])
  do.call(rbind, lapply(seq_len(nrow(g)), function(j) {
    ix <- as.numeric(g$selected_index[j]); cf <- g$coefficient[j]
    r <- C[as.numeric(C$selected_index) == ix & C$coefficient == cf, , drop = FALSE]
    est <- suppressWarnings(as.numeric(r$estimate)); est <- est[!is.na(est)]
    data.frame(candidate_index = ix, candidate = sx_pool$label[match(ix,
        sx_pool$index)], term = r$term[1],
               coefficient = cf, coefficient_label = sx_coef_display(cf),
               draws_selected = sum(!is.na(ok$selected_index) & as.numeric(ok$selected_index) == ix),
               draws_with_estimate = length(est), positive_sign = if (length(est)) mean(est > 0) else NA_real_,
               `estimate_p2.5` = sx_q(est, 0.025), estimate_median = if (length(est)) stats::median(est) else NA_real_,
               `estimate_p97.5` = sx_q(est, 0.975), check.names = FALSE, stringsAsFactors = FALSE)
  }))
}
# coefficient identity: every coefficient row belongs to a fitted draw of the same selected candidate, with the
# declared key, one term per (candidate, coefficient), and n_coef rows per draw
sx_coef_identity <- function(B, C) {
  if (is.null(C) || !nrow(C)) return(is.null(B) || !nrow(B) || all(as.numeric(B$n_coef[B$status == "fitted"]) == 0))
  ok <- B[B$status == "fitted", , drop = FALSE]; i <- match(C$b, ok$b)
  if (anyNA(i) || any(as.numeric(C$selected_index) != as.numeric(ok$selected_index[i]))) return(FALSE)
  if (any(C$selected_key != sx_pool$key[match(as.numeric(C$selected_index),
      sx_pool$index)])) return(FALSE)
  terms <- tapply(C$term, paste(C$selected_index, C$coefficient), function(t) length(unique(t)))
  n <- table(factor(C$b, levels = ok$b))
  all(terms == 1) && all(as.numeric(n) == as.numeric(ok$n_coef))
}
sx_realized <- function(M) {
  if (is.null(M) || !nrow(M)) return(NULL)
  unit <- if (sx_target == "rows") as.character(M$row_id) else if (sx_target == "cluster") sx_unit_clus(M$row_id) else
    sx_unit_part(M$row_id)
  out <- list()
  for (s in sx_plan_splits$split) {
    w <- M$split == s; f <- as.numeric(M$fold[w]); u <- unit[w]; md <- sx_plan_splits$mode[sx_plan_splits$split == s]
    n_all <- if (sx_target == "rows") length(u) else length(unique(u))
    for (k in sort(unique(f[f > 0]))) {
      te <- f == k; nu <- if (sx_target == "rows") sum(te) else length(unique(u[te]))
      out[[length(out) + 1]] <- data.frame(split = s, mode = md, fold = k,
        requested_fraction = if (md == "holdout") sx_val_cfg$holdout_fraction else 1 / sx_val_cfg$k,
        test_units = nu, units = n_all, realized_unit_fraction = if (n_all) nu / n_all else NA_real_,
        test_rows = sum(te), rows = length(f), realized_row_fraction = if (length(f)) sum(te) / length(f) else NA_real_,
        rule = sx_plan_splits$rule[sx_plan_splits$split == s], stringsAsFactors = FALSE)
    }
  }
  do.call(rbind, out)
}
# ---- required files (declared by the app from the validation's modes, embedded above) ----
for (i in seq_len(nrow(sx_expect))) {
  f <- sx_expect$file[i]
  if (!sx_expect$required[i]) { sx_add_chk(paste0("file ", f), TRUE, "not applicable to this validation",
      applicable = FALSE); next }
  ok <- file.exists(f)
  sx_add_chk(paste0("file ", f), ok, if (ok) "present" else "REQUIRED reference file missing")
  if (ok) { n <- nrow(sx_read(f)); sx_add_chk(paste0("file ", f, ": rows"), n == sx_expect$rows[i],
                                               sprintf("%d rows, expected %d",
                                                   n, sx_expect$rows[i])) }
}
sx_has <- function(f) any(sx_expect$file == f & sx_expect$required)
# ---- execution scope (AUD135-04): the ledger, and replayed = committed ----
sx_compare("execution ledger", "execution_ledger.csv", sx_ledger, sx_schema$ledger)
sx_rep_parts <- c(if (!is.null(sx_F)) paste0(sx_F$split, ":fold", sx_F$fold),
    if (!is.null(sx_B)) paste0("boot", sx_B$b))
sx_rep_status <- c(if (!is.null(sx_F)) as.character(sx_F$status), if (!is.null(sx_B)) as.character(sx_B$status))
sx_com <- sx_ledger[sx_ledger$committed, , drop = FALSE]
sx_add_chk("replay scope: the replayed parts are exactly the committed parts",
    setequal(sx_rep_parts, sx_com$part) &&
           length(sx_rep_parts) == nrow(sx_com), sprintf("replayed %d, committed %d",
               length(sx_rep_parts), nrow(sx_com)))
sx_add_chk("replay scope: replayed statuses equal the committed statuses",
           identical(unname(sx_rep_status[match(sx_com$part, sx_rep_parts)]),
               as.character(sx_com$status)),
           "status of every committed part")
# ---- planned manifests: committed parts from the replayed chunk code, pending parts from the embedded plan ----
if (sx_has("split_manifest.csv")) {
  M <- rbind(if (!is.null(sx_M)) sx_M[, c("split", "row_id", "fold")], sx_pend_M)
  if (!is.null(M) && nrow(M)) {
    M$mode <- sx_plan_splits$mode[match(M$split, sx_plan_splits$split)]
    M$`repeat` <- sx_plan_splits$`repeat`[match(M$split, sx_plan_splits$split)]
  }
  sx_compare("split manifest", "split_manifest.csv", M, sx_schema$manifest,
      skip = c("participant", "cluster"))
  app <- sx_read("split_manifest.csv")
  if (!is.null(app) && nrow(app)) {
    sx_add_chk("split manifest: every row is an analysed row", !anyNA(sx_pos(app$row_id)),
        "row_id in the analysed data")
    sx_add_chk("split manifest: participant keys identify the analysed participants",
               sx_partition_ok(app$participant, sx_unit_part(app$row_id)), "same key <=> same participant in R")
    sx_add_chk("split manifest: cluster keys identify the analysed clusters",
               sx_partition_ok(app$cluster, sx_unit_clus(app$row_id)), "same key <=> same cluster in R")
    sx_M_all <- M
  } else sx_M_all <- NULL
} else sx_M_all <- NULL
if (sx_has("bootstrap_draws.csv")) {
  D <- rbind(if (!is.null(sx_D)) sx_D, sx_pend_D)
  sx_compare("bootstrap draw manifest", "bootstrap_draws.csv", D, sx_schema$draws,
             skip = c("original_participant", "original_cluster"))
  app <- sx_read("bootstrap_draws.csv")
  if (!is.null(app) && nrow(app)) {
    sx_add_chk("bootstrap draw manifest: every row is an analysed row", !anyNA(sx_pos(app$row_id)),
        "row_id")
    sx_add_chk("bootstrap draw manifest: original participant keys identify the analysed participants",
               sx_partition_ok(app$original_participant, sx_unit_part(app$row_id)), "same key <=> same participant")
    sx_add_chk("bootstrap draw manifest: original cluster keys identify the analysed clusters",
               sx_partition_ok(app$original_cluster, sx_unit_clus(app$row_id)), "same key <=> same cluster")
    man <- sx_read("split_manifest.csv")
    if (!is.null(man) && nrow(man)) {
      j <- match(app$row_id, man$row_id)
      sx_add_chk("bootstrap draw manifest: original keys equal the split manifest's keys of the same rows",
                 !anyNA(j) && identical(app$original_participant, man$participant[j]) &&
                   identical(app$original_cluster, man$cluster[j]), "cross-file identity")
    }
  }
}
# ---- reproduced results ----
if (sx_has("predictions.csv")) sx_compare("predictions", "predictions.csv", sx_P,
    sx_schema$predictions)
if (sx_has("folds.csv")) {
  Fr <- sx_F
  if (!is.null(Fr) && nrow(Fr)) { Fr$mode <- sx_plan_splits$mode[match(Fr$split,
      sx_plan_splits$split)]
    Fr$`repeat` <- sx_plan_splits$`repeat`[match(Fr$split, sx_plan_splits$split)] }
  sx_compare("folds", "folds.csv", Fr, sx_schema$folds)
}
if (sx_has("performance.csv"))
  sx_compare("performance (recomputed in R from the reproduced predictions)", "performance.csv",
             sx_perf(sx_P, sx_F, sx_binary, sx_target), sx_schema$performance)
if (sx_has("realized_sizes.csv"))
  sx_compare("realized sizes (recomputed from the verified plan and the analysed units)",
      "realized_sizes.csv",
             sx_realized(sx_M_all), sx_schema$realized)
if (sx_has("bootstrap_results.csv")) {
  Br <- sx_B
  if (!is.null(Br) && nrow(Br)) Br$coefficient_label <- sx_coef_display(Br$coefficient)
  sx_compare("bootstrap draws", "bootstrap_results.csv", Br, sx_schema$bootstrap)
}
if (sx_has("bootstrap_coefficients.csv")) {
  sx_compare("bootstrap coefficients", "bootstrap_coefficients.csv", sx_C, sx_schema$coefs)
  sx_add_chk("bootstrap coefficients: identity (draw, selected candidate, declared key, term, n_coef)",
             isTRUE(tryCatch(sx_coef_identity(sx_B, sx_C), error = function(e) FALSE)), "reproduced coefficients")
}
if (sx_has("stability.csv"))
  sx_compare("stability (recomputed from the reproduced draws and the declared pool)",
      "stability.csv",
             sx_stability(sx_B), sx_schema$stability)
if (sx_has("bootstrap_estimands.csv"))
  sx_compare("bootstrap estimands (recomputed from the reproduced coefficients)",
      "bootstrap_estimands.csv",
             sx_estimands(sx_B, sx_C), sx_schema$estimands)
if (sx_has("candidate_trace.csv")) sx_compare("candidate trace", "candidate_trace.csv",
    sx_T, sx_schema$trace)
utils::write.csv(sx_chk, "validation_check_results.csv", row.names = FALSE)
sx_fail <- sx_chk$status == "FAIL"
print(sx_chk[sx_chk$status != "PASS", , drop = FALSE], row.names = FALSE)
sx_n_plan <- nrow(sx_ledger); sx_n_com <- sum(sx_ledger$committed)
cat(sprintf("Execution coverage: %d of %d planned parts committed and replayed; %d not run; %d dispatched without a validated response (not reproducible).\n",
            sx_n_com, sx_n_plan, sum(sx_ledger$status == "not_run"), sum(sx_ledger$status == "uncommitted")))
if (any(sx_fail)) {
  msg <- paste0("VERIFICATION FAILED: ", sum(sx_fail), " of ", nrow(sx_chk),
      " checks (see validation_check_results.csv): ",
                paste(utils::head(sx_chk$check[sx_fail], 5), collapse = "; "))
  if (interactive()) stop(msg, call. = FALSE) else { message(msg); quit(save = "no", status = 1) }
}
if (!is.null(sx_P)) cat("Predictions reproduced:", nrow(sx_P), "held-out rows.\n")
if (!is.null(sx_B)) cat("Bootstrap selections reproduced:", nrow(sx_B), "draws.\n")
cat(sprintf("All %d checks passed (%d not applicable).\n", sum(sx_chk$status == "PASS"),
    sum(sx_chk$status == "NOT APPLICABLE")))
cat(if (identical(sx_app_status, "complete") && sx_n_com == sx_n_plan) "The complete validation was reproduced.\n" else
    paste0("The export is ", toupper(sx_app_status), ": only its ", sx_n_com,
        " committed part(s) of ", sx_n_plan,
           " planned were reproduced; this is not a reproduction of a complete validation.\n"))

