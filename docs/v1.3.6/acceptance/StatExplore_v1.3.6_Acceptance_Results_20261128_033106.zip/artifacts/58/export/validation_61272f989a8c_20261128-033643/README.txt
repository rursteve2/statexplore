Validation status: COMPLETE
Target: New participants — all rows of a participant are in the same part; predictions use fixed effects only (the new participant's random effects are unknown, i.e. zero).
Procedure: Whole selection pipeline (search repeated inside each training part); selection rule: Smallest training p-value (natural-log tail) of the candidate's primary test (the search's discovery ranking); exact ties: lower candidate index.
Candidate pool: CUMULATIVE declared model budgets: the first 15 of 15 candidates (5 + 10) — ADAPTIVE: continuation budgets were chosen after earlier results were seen, so validating this frozen prefix is a conditional validation, not an unbiased validation of the adaptive procedure.
Search: b488e51652f2 (fit identity d74fe0946e0a7873…); validation run 61272f989a8c.
Modes: Holdout; holdout 20%, K = 5, repeats = 1, B = 200, seed = 58.
Execution: 1 of 1 planned parts committed (1 of 1 chunks).
This is a predictive check of the stated target, separate from the discovery p-values; it is not a confirmatory test, and bootstrap selection frequencies are not probabilities that a hypothesis is true.

Files: validation_reproduce.R (complete reproduction with self-checks, only with verified data), execution_ledger.csv (planned / committed / not run parts), candidate_trace.csv (every candidate in every training part / draw), bootstrap_estimands.csv, realized_sizes.csv, split_manifest.csv (the PLANNED fold of every analysed row per split; fold 0 = training only), bootstrap_draws.csv (planned draws: draw IDs and original IDs), predictions.csv (held-out rows), folds.csv, performance.csv, stability.csv, validation_code.R, bundle_inventory.json.
