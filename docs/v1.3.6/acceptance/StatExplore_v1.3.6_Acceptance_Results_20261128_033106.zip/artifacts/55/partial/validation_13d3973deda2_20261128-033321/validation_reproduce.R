# ---- required R packages (checked before anything runs) ----
sx_needed <- c("Matrix", "detectseparation", "geepack", "lme4", "mmrm", "nlme", "nnet", "ordinal")
sx_missing <- sx_needed[!vapply(sx_needed, requireNamespace, logical(1), quietly = TRUE)]
if (length(sx_missing)) stop("Missing R packages: ", paste(sx_missing, collapse = ", "), ". Install them ",
  "(offline: install.packages('<file>.zip', repos = NULL)) and run this script again.", call. = FALSE)
dir.create("plots", showWarnings = FALSE)  # output folder for any plots
# ==== StatExplore AMD validation: complete reproduction ====
# Run from the exported folder (Rscript validation_reproduce.R). It needs the data file named in the data-load
# section and verifies its results against the CSV files StatExplore exported (same folder).
# ---- StatExplore helper functions ----
sx_item_mean <- function(d, min_valid) {
  n <- rowSums(!is.na(d)); out <- rowMeans(d, na.rm = TRUE); out[n < min_valid] <- NA_real_; out
}
sx_item_sum <- function(d) rowSums(d)  # NA when any item is missing
sx_log <- function(x) { out <- rep(NA_real_, length(x)); ok <- !is.na(x) & x > 0; out[ok] <- log(x[ok]); out }
sx_sqrt <- function(x) { out <- rep(NA_real_, length(x)); ok <- !is.na(x) & x >= 0; out[ok] <- sqrt(x[ok]); out }
sx_z <- function(x) (x - mean(x, na.rm = TRUE)) / stats::sd(x, na.rm = TRUE)
sx_center <- function(x) x - mean(x, na.rm = TRUE)
sx_binarize <- function(x, cutoff, strict) as.numeric(if (strict) x > cutoff else x >= cutoff)
sx_recode <- function(x, from, to, keep_other) {
  m <- match(x, from)
  out <- if (keep_other) as.numeric(x) else rep(NA_real_, length(x))
  out[!is.na(m)] <- to[m[!is.na(m)]]
  out
}
# Complete cases on the analysis variables, unused factor levels dropped.
sx_complete <- function(data, vars) {
  droplevels(data[stats::complete.cases(data[, vars, drop = FALSE]), vars, drop = FALSE])
}
# Shapiro-Wilk is defined for 3 <= n <= 5000; otherwise not reported.
sx_shapiro <- function(x) {
  x <- x[!is.na(x)]
  if (length(x) < 3 || length(x) > 5000 || stats::var(x) == 0) return(c(W = NA_real_, p = NA_real_))
  t <- stats::shapiro.test(x); c(W = unname(t$statistic), p = t$p.value)
}
# Proportional-odds check for an ordinal::clm fit: the tests of ordinal::nominal_test() (each term in turn made
# category-specific, likelihood-ratio test against the fitted model) plus a global test (all terms at once).
# nominal_test() refits through update(), which cannot see local data and turns every failure into a silent NA;
# here each refit is explicit and a term that cannot be tested carries the specific reason.
sx_po_check <- function(fit, form, data, link = "logit") {
  y <- data[[all.vars(form)[1]]]
  ll0 <- as.numeric(stats::logLik(fit))
  one <- function(label, nom, cells_check = TRUE) {
    w <- character()
    m <- withCallingHandlers(
      tryCatch(ordinal::clm(form, nominal = nom, data = data, link = link), error = function(e) e),
      warning = function(x) { w <<- c(w, conditionMessage(x)); invokeRestart("muffleWarning") })
    out <- data.frame(term = label, df = NA_real_, LRT = NA_real_, p = NA_real_,
        status = "not tested",
                      reason = "", stringsAsFactors = FALSE)
    vars <- intersect(all.vars(nom), names(data))
    fac <- vars[vapply(data[vars], is.factor, logical(1))]
    notes <- character()
    if (cells_check && length(fac)) {
      cells <- table(interaction(data[fac], drop = TRUE), y)
      if (any(cells == 0)) notes <- c(notes, sprintf(
        "sparse: %d of %d outcome-by-category cells are empty", sum(cells == 0), length(cells)))
    }
    if (inherits(m, "error")) {
      out$reason <- paste(c(paste("the category-specific model could not be fitted:",
          conditionMessage(m)), notes),
                          collapse = "; ")
      return(out)
    }
    code <- as.integer(m$convergence$code)
    msgs <- unique(gsub("\\s+", " ", trimws(c(m$convergence$messages, m$convergence$alg.message))))
    # the location coefficients a nominal term replaces are aliased by design; only threshold-side aliasing counts
    al <- sum(m$aliased$alpha)
    if (al) notes <- c(notes, sprintf("%d category-specific coefficient(s) not identifiable (aliased) and dropped",
        al))
    w <- unique(gsub("\\s+", " ", trimws(sub("^\\(\\d+\\)\\s*", "", w))))
    w <- w[!vapply(w, function(x) any(startsWith(x, msgs) | startsWith(msgs, x)), logical(1))]
    if (length(w)) notes <- c(notes, paste("warning:", w))
    df <- m$edf - fit$edf
    lr <- 2 * (as.numeric(stats::logLik(m)) - ll0)
    if (is.na(code) || code < 0L) {
      out$reason <- paste(c(paste("the category-specific model did not converge:",
          paste(msgs, collapse = "; ")), notes),
                          collapse = "; ")
    } else if (df <= 0) {
      out$reason <- paste(c("no estimable category-specific parameters beyond the fitted model (rank deficient)",
                            notes), collapse = "; ")
    } else if (!is.finite(lr) || lr < -1e-6) {
      out$reason <- paste(c(sprintf("the category-specific fit has a lower likelihood (LR = %.4g): optimizer failure",
          lr),
                            notes), collapse = "; ")
    } else {
      out$df <- df; out$LRT <- max(lr, 0); out$p <- stats::pchisq(max(lr,
          0), df, lower.tail = FALSE)
      if (code == 0L) {
        out$status <- "tested"
      } else {
        # code 1: the likelihood reached its maximum but some parameters are not uniquely determined, so the
        # parameter count (df) is uncertain; ordinal::nominal_test reports these values without comment
        out$status <- "approximate"
        notes <- c(paste0("df uncertain: ", paste(msgs, collapse = "; ")), notes)
      }
      out$reason <- paste(notes, collapse = "; ")
    }
    out
  }
  terms <- attr(stats::terms(form), "term.labels")
  if (!length(terms)) return(data.frame(term = "(none)", df = NA_real_, LRT = NA_real_,
      p = NA_real_,
    status = "not tested", reason = "intercept-only model: there is no effect to make category-specific"))
  rows <- lapply(terms, function(tm) one(tm, stats::as.formula(paste("~", tm))))
  if (length(terms) > 1) rows[[length(rows) + 1]] <- one("All terms (global test)",
    stats::as.formula(paste("~", paste(terms, collapse = " + "))), cells_check = FALSE)
  out <- do.call(rbind, rows)
  # STAT-26: an interaction term made category-specific frees every cell of its design; when that uses as many
  # parameters as the global test it IS the global alternative, not a separate test of the interaction
  if (length(terms) > 1) {
    g <- out$df[nrow(out)]
    span <- seq_len(nrow(out) - 1)[grepl(":", out$term[-nrow(out)]) & is.finite(out$df[-nrow(out)]) &
                                   out$df[-nrow(out)] == g]
    for (i in span) out$reason[i] <- paste(c(if (nzchar(out$reason[i])) out$reason[i],
      "same df as the global test: this interaction test spans the global alternative (cell-based parameterization), not an independent test of the interaction"), collapse = "; ")
  }
  out
}
# Information criteria. Native AIC()/BIC() for every engine except mmrm: its own criteria count only covariance
# parameters under REML and use n = subjects, so it is put on nlme's convention (k = fixed + covariance parameters,
# n = observations, n - p under REML) and structures fitted by different packages share one penalty.
sx_ic <- function(m) {
  ll <- stats::logLik(m)
  if (inherits(m, "mmrm")) {
    p <- length(m$beta_est); k <- p + length(m$theta_est); n <- length(stats::residuals(m))
    nb <- if (isTRUE(m$reml)) n - p else n
    return(list(aic = -2 * as.numeric(ll) + 2 * k, bic = -2 * as.numeric(ll) + log(nb) * k,
        k = k, n_bic = nb,
                basis = "nlme convention (mmrm's own BIC differs)"))
  }
  nb <- attr(ll, "nobs")
  if (is.null(nb)) nb <- tryCatch(stats::nobs(m), error = function(e) NA_real_)
  list(aic = stats::AIC(m), bic = stats::BIC(m), k = attr(ll, "df"), n_bic = as.numeric(nb),
      basis = "native")
}
# Package a data frame as a result table.
sx_table <- function(name, df, notes = "", row_names = NULL) {
  df <- as.data.frame(df, stringsAsFactors = FALSE, check.names = FALSE)
  list(name = name, columns = I(names(df)),
       data = lapply(df, function(col) if (is.factor(col)) I(as.character(col)) else I(col)),
       row_names = I(as.character(row_names)), notes = notes)
}
# ---- StatExplore: model identity fingerprints (schema 2, SHA-256) ----
# Canonical rows = analysed source rows sorted by row number; every fingerprint is computed in that order, so the
# fitting order does not change it. Values are hashed as exact IEEE doubles; text with length prefixes.
sx_sha_raw <- function(writer) { tf <- tempfile(); con <- file(tf, "wb"); on.exit(unlink(tf))
  tryCatch(writer(con), finally = close(con)); unname(tools::sha256sum(tf)) }
sx_put_txt <- function(con, x) { x <- enc2utf8(as.character(x)); writeBin(as.integer(length(x)),
    con, size = 4)
  # vectorised: every string as <byte length>:<bytes>, one write (length prefixes keep it unambiguous)
  writeBin(charToRaw(paste0(nchar(x, type = "bytes"), ":", x, collapse = "")), con) }
sx_put_num <- function(con, x) { x <- as.double(x); writeBin(as.integer(length(x)), con, size = 4)
  writeBin(is.na(x), con, size = 1); writeBin(ifelse(is.na(x), 0, x), con,
      size = 8, endian = "little") }
sx_canon_names <- function(nm) vapply(strsplit(gsub("sx_timef", "sx_time", nm,
    fixed = TRUE), ":", fixed = TRUE),
  function(p) paste(sort(p), collapse = ":"), "")
sx_ident_cache <- new.env()   # row / response / grouping fingerprints of the last sample (recomputed when it changes)
sx_identity <- function(d, fixed, response, groups = character()) {
  rn <- rownames(d); y0 <- d[[response]]; g0 <- lapply(groups, function(g) d[[g]])
  rid <- suppressWarnings(as.numeric(rn))
  o <- if (anyNA(rid)) order(rn) else order(rid)
  X <- stats::model.matrix(stats::delete.response(stats::terms(fixed)), d[seq_len(min(nrow(d),
      2L)), , drop = FALSE])
  # (only the column names are needed: they encode the terms, coding and reference levels; values are hashed per
  # variable below)
  cn <- sx_canon_names(colnames(X)); ix <- order(cn)
  k <- sx_ident_cache
  if (!(identical(k$rn, rn) && identical(k$y, y0) && identical(k$g, g0))) {
    dc <- d[o, c(response, groups), drop = FALSE]
    y <- dc[[response]]
    k$rows <- sx_sha_raw(function(con) sx_put_txt(con, rn[o]))
    k$rows_ordered <- sx_sha_raw(function(con) sx_put_txt(con, rn))
    k$response <- sx_sha_raw(function(con) { if (is.factor(y)) { sx_put_txt(con,
        levels(y)); sx_put_num(con, as.integer(y)) }
                                             else sx_put_num(con, y) })
    k$groups <- sx_sha_raw(function(con) for (g in groups) { f <- dc[[g]]   # partitions only: names and labels never enter
      sx_put_num(con, match(as.character(f), unique(as.character(f)))) })
    k$rn <- rn; k$y <- y0; k$g <- g0
  }
  # design: the canonical design-column names (terms, coding, reference levels) + the SHA-256 of every variable the
  # design uses (values in canonical row order; factors as level labels + codes). X is an exact function of these,
  # so this equals a hash of the realized matrix while hashing only a few bytes per model (variables are cached).
  vars <- intersect(all.vars(stats::delete.response(stats::terms(fixed))), names(d))
  vh <- vapply(vars, function(v) {
    col <- d[[v]]; e <- k$vars[[v]]
    if (!is.null(e) && identical(e$rn, rn) && identical(e$col, col)) return(e$sha)
    co <- col[o]
    sha <- sx_sha_raw(function(con) { if (is.factor(co)) { sx_put_txt(con,
        levels(co)); sx_put_num(con, as.integer(co)) }
                                       else sx_put_num(con, co) })
    if (is.null(k$vars)) k$vars <- list()
    k$vars[[v]] <- list(rn = rn, col = col, sha = sha)
    sha
  }, "")
  vn <- sx_canon_names(names(vh)); vo <- order(vn)
  list(schema = 2L, algorithm = "sha256", n = nrow(d), rows = k$rows, rows_ordered = k$rows_ordered,
    response = k$response,
    design = sx_sha_raw(function(con) { sx_put_txt(con, cn[ix]); sx_put_txt(con,
        vn[vo]); sx_put_txt(con, unname(vh)[vo]) }),
    groups = k$groups, design_columns = I(cn[ix]))
}

# ---- StatExplore: data preparation ----
# Source file: "StatExplore_Test55L_LegacyUnderflow.csv"
# Values declared as user-missing in the source were exported as NA.
sx_data_file <- "validation_reproduce_data.csv"  # exported with this script (analysis columns only); edit if you move it
if (!file.exists(sx_data_file)) {  # source("analysis.R") from another folder: look next to the script
  sx_here <- tryCatch(dirname(normalizePath(sys.frame(1)$ofile)), error = function(e) NA_character_)
  if (!is.na(sx_here) && file.exists(file.path(sx_here, sx_data_file))) sx_data_file <- file.path(sx_here,
      sx_data_file)
}
if (!file.exists(sx_data_file)) stop("Data file not found: put ", sx_data_file,
    " next to this script or set sx_data_file.")
sx_data_sha256 <- "8feea00dc4d8b5f9c17864ca0f06d89ce63eb22efb5fa6f57a5325287e6debe9"  # SHA-256 of validation_reproduce_data.csv as exported (see validation_reproduce_manifest.json)
if (!isTRUE(get0("sx_skip_checksum")) && !identical(unname(tools::sha256sum(sx_data_file)),
    sx_data_sha256))
  stop("The data file ", sx_data_file, " is not the file exported with this script (SHA-256 differs). ",
       "Use the exported file, or set sx_skip_checksum <- TRUE before source() to run anyway (the run is then ",
       "UNVERIFIED and is not a reproduction).", call. = FALSE)
if (isTRUE(get0("sx_skip_checksum"))) message("WARNING: the data checksum was skipped - this run is UNVERIFIED.")
sx_raw <- utils::read.csv(
  sx_data_file, na.strings = "", fileEncoding = "UTF-8", check.names = FALSE,
  colClasses = c(
    v001 = "numeric",
    v002 = "numeric",
    v003 = "numeric",
    v004 = "numeric",
    v005 = "numeric"
  )
)
sx_result <- list(n_raw = nrow(sx_raw))
# Internal names (v001, ...) -> variable names
sx_names <- c(
    v001 = "ID",
    v002 = "x1",
    v003 = "x3",
    v004 = "x2",
    v005 = "y"
)
dat <- sx_raw
sx_result <- list(n_rows = nrow(dat), n_cols = ncol(dat))

# ---- StatExplore: shared longitudinal model helpers (v1.3.2) ----
# One builder for every Gaussian longitudinal fit (Mixed workspace, comparisons, Discovery, exports).
# random: "ri" | "diag" | "rs"; residual: "independent" | "ar1" | "car1"; clustered: participants (composite
# cluster+ID key in `id`) nested in `cluster`. Correlation objects are created fresh for every fit.
sx_re_lme4 <- function(random, clustered = FALSE, slope = "sx_time", id = "sx_id",
    cluster = "sx_cluster") {
  r <- switch(random, ri = paste0("(1 | ", id, ")"), diag = paste0("(1 + ", slope, " || ", id, ")"),
              rs = paste0("(1 + ", slope, " | ", id, ")"), stop("Unsupported random-effects structure: ",
                  random))
  if (clustered) paste0("(1 | ", cluster, ") + ", r) else r
}
sx_re_nlme <- function(random, clustered = FALSE, slope = "sx_time", id = "sx_id",
    cluster = "sx_cluster") {
  fs <- stats::as.formula(paste("~ 1 +", slope))
  if (!clustered) return(switch(random,
    ri = stats::as.formula(paste("~ 1 |", id)),
    diag = stats::setNames(list(nlme::pdDiag(fs)), id),
    rs = stats::as.formula(paste("~ 1 +", slope, "|", id)),
    stop("Unsupported random-effects structure: ", random)))
  switch(random,
    ri = stats::as.formula(paste("~ 1 |", cluster, "/", id)),
    diag = stats::setNames(list(nlme::pdDiag(~ 1), nlme::pdDiag(fs)), c(cluster, id)),
    rs = stats::setNames(list(nlme::pdDiag(~ 1), nlme::pdSymm(fs)), c(cluster, id)),
    stop("Unsupported random-effects structure: ", random))
}
sx_cor_nlme <- function(residual, clustered = FALSE, occ = "sx_tidx", tnum = "sx_tnum",
    id = "sx_id",
                        cluster = "sx_cluster") {
  g <- if (clustered) paste0(cluster, "/", id) else id
  switch(residual, independent = NULL,
    ar1 = nlme::corAR1(form = stats::as.formula(paste("~", occ, "|", g))),
    car1 = nlme::corCAR1(form = stats::as.formula(paste("~", tnum, "|", g))),
    stop("Unsupported residual covariance structure: ", residual))
}
# Composite participant key for nested designs: length-prefixed (cluster, ID) labels, ordered by cluster then ID, so
# locally reused IDs never merge and no concatenation is ambiguous.
sx_nested_id <- function(cluster, id) {
  cl <- as.character(cluster); pid <- as.character(id)
  key <- paste0(nchar(cl, type = "chars"), ":", cl, "|", pid)
  o <- order(as.integer(factor(cluster)), as.integer(factor(id)))
  factor(key, levels = unique(key[o]))
}
# Optimizer errors that justify retrying the SAME model with another optimizer; any other error is structural.
sx_optimizer_error <- function(msg) grepl("convergence|iteration limit|evaluation limit|nlminb problem|false convergence|singular convergence|optim problem",
    msg, ignore.case = TRUE)
# Run fit(opt) for each optimizer in turn until one succeeds; record every attempt, its warnings and errors. Only an
# optimizer failure moves on to the next optimizer; the requested model is never changed.
sx_fit_attempts <- function(fit, optimizers) {
  attempts <- list(); warns <- character(); m <- NULL; err <- NULL
  for (opt in optimizers) {
    w <- character()
    # AUD134-10: every optimizer attempt is a fitting invocation (outside the tryCatch: a budget stop is not a fit error)
    if (exists("sx_budget_take", mode = "function")) sx_budget_take(if (length(attempts)) "retry" else "fit")
    m <- withCallingHandlers(tryCatch(fit(opt), error = function(e) e),
      warning = function(x) { w <<- c(w, conditionMessage(x)); invokeRestart("muffleWarning") },
      message = function(x) invokeRestart("muffleMessage"))
    bad <- inherits(m, "error")
    attempts[[length(attempts) + 1]] <- data.frame(optimizer = opt, status = if (bad) "failed" else "fitted",
      error = if (bad) conditionMessage(m) else "", warnings = paste(unique(w),
          collapse = "; "), stringsAsFactors = FALSE)
    if (!bad) { warns <- unique(w); break }
    err <- conditionMessage(m)
    if (!sx_optimizer_error(err)) break
  }
  list(fit = if (inherits(m, "error")) NULL else m, attempts = do.call(rbind,
      attempts), warnings = warns, error = err)
}
# Diagnostics of a fitted Gaussian mixed model (STAT-18 / STAT-32). Flags may coexist; `clean` only when none.
#   lme4: optimizer code, lme4 check code and messages, warnings, isSingular (lme4 tolerance 1e-4 on theta)
#   nlme: every random-effects block G / sigma^2: non positive definite -> singular; smallest eigenvalue < 1e-6, eigenvalue
#         ratio < 1e-6 or |correlation| > 0.999 -> near-boundary (positive definite but at the edge); apVar (approximate
#         covariance of the variance parameters) reported separately; optimizer fallback reported as a warning.
sx_diag <- function(m, run = NULL) {
  out <- list(engine = if (inherits(m, "merMod")) "lme4" else if (inherits(m,
      "lme")) "nlme" else class(m)[1],
              optimizer = NA_character_, opt_code = NA_real_, check_code = NA_real_, singular = NA,
              near_boundary = NA, boundary = character(), apvar = "not applicable", messages = character(),
              flags = character())
  att <- if (is.null(run)) NULL else run$attempts
  w <- if (is.null(run)) character() else run$warnings
  if (!is.null(att) && nrow(att)) {
    out$optimizer <- utils::tail(att$optimizer, 1)
    if (nrow(att) > 1) out$flags <- c(out$flags, paste0("optimizer fallback: ",
        paste(sprintf("%s failed (%s)",
      att$optimizer[att$status == "failed"], att$error[att$status == "failed"]), collapse = "; "), "; estimated with ",
      out$optimizer))
  }
  if (inherits(m, "merMod")) {
    oi <- m@optinfo
    out$optimizer <- oi$optimizer
    out$opt_code <- if (is.null(oi$conv$opt)) NA_real_ else as.numeric(oi$conv$opt)
    cc <- oi$conv$lme4$code; out$check_code <- if (is.null(cc) || !length(cc)) 0 else as.numeric(cc[1])
    msgs <- unique(c(unlist(oi$conv$lme4$messages), unlist(oi$warnings)))
    out$singular <- lme4::isSingular(m)
    if (isTRUE(out$singular)) out$flags <- c(out$flags, "Singular fit: a random-effect variance is ~0 or a correlation is +/-1 (lme4 tolerance 1e-4); simplify the random-effects structure")
    msgs <- msgs[!grepl("singular", msgs, ignore.case = TRUE) | !isTRUE(out$singular)]
    out$messages <- msgs
    if (isTRUE(out$opt_code != 0)) out$flags <- c(out$flags, sprintf("optimizer returned code %g",
        out$opt_code))
    if (isTRUE(out$check_code != 0) && !length(msgs)) out$flags <- c(out$flags,
        sprintf("lme4 convergence check code %g", out$check_code))
    if (length(msgs)) out$flags <- c(out$flags, paste("convergence:", msgs))
  } else if (inherits(m, "lme")) {
    s2 <- m$sigma^2; nb <- FALSE; sing <- FALSE
    for (g in names(m$modelStruct$reStruct)) {
      G <- tryCatch(nlme::pdMatrix(m$modelStruct$reStruct[[g]]), error = function(e) NULL)
      if (is.null(G)) { out$boundary <- c(out$boundary, paste0(g, ": covariance unavailable")); next }
      ev <- eigen(G, symmetric = TRUE, only.values = TRUE)$values
      r <- if (nrow(G) > 1) stats::cov2cor(G) else matrix(1)
      rmax <- if (nrow(G) > 1) max(abs(r[upper.tri(r)])) else 0
      if (!all(is.finite(ev)) || min(ev) <= 0) { sing <- TRUE
        out$boundary <- c(out$boundary, sprintf("%s: covariance not positive definite (smallest eigenvalue %.3g)",
            g, min(ev)))
      } else if (min(ev) < 1e-6 || min(ev) / max(ev) < 1e-6 || rmax > 0.999) { nb <- TRUE
        out$boundary <- c(out$boundary, sprintf("%s: near-boundary (smallest variance/sigma^2 eigenvalue %.3g, ratio %.3g, max |r| %.4f)",
                                                g, min(ev), min(ev) / max(ev), rmax)) }
    }
    out$singular <- sing; out$near_boundary <- nb
    if (sing) out$flags <- c(out$flags, paste("singular random-effects covariance:",
        paste(out$boundary, collapse = "; ")))
    if (nb) out$flags <- c(out$flags, paste("near-boundary random-effects covariance (positive definite; scaled eigenvalue / eigenvalue-ratio tolerance 1e-6, |r| > 0.999):",
        paste(out$boundary, collapse = "; ")))
    out$apvar <- if (is.matrix(m$apVar)) "positive definite" else as.character(m$apVar)[1]
    if (!is.matrix(m$apVar)) out$flags <- c(out$flags, paste0("approximate covariance of the variance parameters (apVar) unavailable: ",
        out$apvar,
                                                             " (variance-component standard errors and intervals are not available; this is not by itself singularity)"))
  } else if (inherits(m, "clmm")) {
    out$optimizer <- "ucminf (ordinal default)"
    code <- m$optRes$convergence; out$opt_code <- if (is.null(code)) NA_real_ else as.numeric(code)
    if (!isTRUE(out$opt_code == 0)) out$flags <- c(out$flags, sprintf("optimizer convergence code %s",
        format(out$opt_code)))
    ch <- tryCatch(summary(m)$condHess, error = function(e) NA_real_)
    if (isTRUE(ch > 1e4)) out$flags <- c(out$flags, sprintf("ill-conditioned Hessian (condition number %.3g)",
        ch))
    vc <- tryCatch(getExportedValue("ordinal", "VarCorr")(m), error = function(e) NULL); sing <- FALSE
    for (g in names(vc)) { ev <- eigen(as.matrix(vc[[g]]), symmetric = TRUE,
        only.values = TRUE)$values
      if (min(ev) < 1e-6) { sing <- TRUE; out$boundary <- c(out$boundary,
          sprintf("%s: smallest variance eigenvalue %.3g", g, min(ev))) } }
    out$singular <- sing
    if (sing) out$flags <- c(out$flags, paste("random-effect variance at or near zero:",
        paste(out$boundary, collapse = "; ")))
  } else if (inherits(m, "geeglm")) {
    out$optimizer <- "geese (Fisher scoring)"
    if (!identical(as.integer(m$geese$error), 0L)) out$flags <- c(out$flags,
        "GEE estimating equations did not converge")
  } else if (inherits(m, "mmrm")) {
    out$optimizer <- "mmrm default"
    if (!isTRUE(attr(m, "converged"))) out$flags <- c(out$flags, "mmrm did not report convergence")
  } else if (inherits(m, "mblogit")) {
    out$optimizer <- "PQL"
    if (!isTRUE(m$converged)) out$flags <- c(out$flags, "the PQL algorithm did not converge")
  } else {
    out$flags <- c(out$flags, "diagnostics unknown for this engine")
  }
  w <- unique(w[!vapply(w, function(x) any(grepl(x, out$messages, fixed = TRUE)), logical(1))])
  if (length(w)) out$flags <- c(out$flags, paste("warning:", w))
  out$flags <- unique(out$flags)
  out$clean <- !length(out$flags)
  out$status <- if (isTRUE(out$singular)) "singular" else if (isTRUE(out$near_boundary)) "near_boundary" else
    if (out$clean) "clean" else "warned"
  out
}
# Marginal / conditional R2 by direct variance decomposition (STAT-45): var(X beta) / (var(X beta) + sum over every
# grouping level of mean diag(Z G Z') + sigma^2). Never the package fallback that silently drops random variance.
sx_r2_direct <- function(m, d) {
  na <- function(why) list(m = NA_real_, c = NA_real_, fixed = NA_real_, random = NA_real_,
      residual = NA_real_, reason = why)
  tryCatch({
    if (inherits(m, "merMod")) {
      s2 <- stats::sigma(m)^2
      fv <- stats::var(as.vector(lme4::getME(m, "X") %*% lme4::fixef(m)))
      rv <- mean(Matrix::rowSums((lme4::getME(m, "Z") %*% lme4::getME(m, "Lambda"))^2)) * s2
    } else if (inherits(m, "lme")) {
      s2 <- m$sigma^2
      fv <- stats::var(as.numeric(stats::predict(m, level = 0)))
      rv <- 0
      for (g in names(m$modelStruct$reStruct)) {
        G <- nlme::pdMatrix(m$modelStruct$reStruct[[g]]) * s2
        Z <- stats::model.matrix(stats::formula(m$modelStruct$reStruct[[g]]), d)
        rv <- rv + mean(rowSums((Z %*% G) * Z))
      }
    } else return(na("not a random-effects model"))
    tot <- fv + rv + s2
    if (!is.finite(tot) || tot <= 0) return(na("variance components unavailable"))
    list(m = fv / tot, c = (fv + rv) / tot, fixed = fv, random = rv, residual = s2, reason = "")
  }, error = function(e) na(paste("variance decomposition failed:", conditionMessage(e))))
}
# Random-effects covariance of an nlme fit, every grouping level (STAT-43): variance, SD, covariance and correlation
# from the scaled pdMatrix; DIAG covariances are constrained to 0, not estimated.
sx_vc_nlme <- function(m) {
  s2 <- m$sigma^2; rows <- list()
  for (g in rev(names(m$modelStruct$reStruct))) {
    pd <- m$modelStruct$reStruct[[g]]; G <- nlme::pdMatrix(pd) * s2; nm <- colnames(G)
    diag_only <- inherits(pd, "pdDiag")
    for (i in seq_len(nrow(G))) rows[[length(rows) + 1]] <- data.frame(group = g,
        term = nm[i], with = "",
      variance_or_cov = G[i, i], sd_or_corr = sqrt(G[i, i]), estimated = "estimated", stringsAsFactors = FALSE)
    if (nrow(G) > 1) for (i in 1:(nrow(G) - 1)) for (j in (i + 1):nrow(G)) rows[[length(rows) + 1]] <- data.frame(
      group = g, term = nm[i], with = nm[j], variance_or_cov = G[i, j],
      sd_or_corr = if (diag_only) 0 else G[i, j] / sqrt(G[i, i] * G[j, j]),
      estimated = if (diag_only) "constrained to 0 (uncorrelated structure)" else "estimated", stringsAsFactors = FALSE)
  }
  rows[[length(rows) + 1]] <- data.frame(group = "Residual", term = "(residual)",
      with = "", variance_or_cov = s2,
    sd_or_corr = sqrt(s2), estimated = "estimated", stringsAsFactors = FALSE)
  do.call(rbind, rows)
}
# Grouping counts at every level of the fitted object (UI-57 / STAT-46): groups, smallest and largest group size.
sx_group_counts <- function(m) {
  fl <- if (inherits(m, "merMod")) lme4::getME(m, "flist") else if (inherits(m,
      "lme")) as.list(m$groups) else list()
  if (!length(fl)) return(NULL)
  do.call(rbind, lapply(names(fl), function(g) { k <- table(droplevels(as.factor(fl[[g]])))
    data.frame(level = g, groups = length(k), min_size = min(k), max_size = max(k)) }))
}
# What was ACTUALLY fitted (v1.3.3, J4), read back from the fitted object, never from the request: class, fixed-effect
# term labels, grouping factors, random-effect blocks (columns, correlated or diagonal), residual correlation class,
# estimation method, GEE working correlation, number of observations.
sx_effective <- function(m) {
  # optional helpers looked up only when needed (a Gaussian script does not depend on reformulas / ordinal)
  nobars <- function(x) getExportedValue(if (requireNamespace("reformulas",
      quietly = TRUE)) "reformulas" else "lme4",
                                         "nobars")(x)
  f <- tryCatch(if (inherits(m, "merMod")) stats::formula(m, fixed.only = TRUE)
                else if (inherits(m, "clmm")) nobars(m$formula) else stats::formula(m), error = function(e) NULL)
  blocks <- list(); groups <- character()
  if (inherits(m, "merMod") || inherits(m, "clmm")) {
    vc <- tryCatch(if (inherits(m, "clmm")) getExportedValue("ordinal", "VarCorr")(m) else lme4::VarCorr(m),
                   error = function(e) list())
    groups <- names(vc)
    blocks <- lapply(names(vc), function(g) { v <- as.matrix(vc[[g]])
      list(group = g, columns = I(colnames(v)), structure = if (ncol(v) > 1) "correlated" else "single") })
  } else if (inherits(m, "lme")) {
    groups <- names(m$groups)
    blocks <- lapply(names(m$modelStruct$reStruct), function(g) { p <- m$modelStruct$reStruct[[g]]
      list(group = g, columns = I(colnames(as.matrix(p))),
           structure = if (inherits(p, "pdDiag")) "diagonal" else if (ncol(as.matrix(p)) > 1) "correlated" else "single") })
  }
  list(class = class(m)[1], fixed = I(if (is.null(f)) character() else attr(stats::terms(f),
      "term.labels")),
       groups = I(groups), blocks = blocks,
       correlation = if (inherits(m, "lme") && !is.null(m$modelStruct$corStruct)) class(m$modelStruct$corStruct)[1] else "none",
       # nlme turns corAR1 into the equivalent corARMA(p = 1, q = 0) when the occasion index has gaps: keep the order
       cor_pq = I(if (inherits(m, "lme") && inherits(m$modelStruct$corStruct, "corARMA"))
                    c(attr(m$modelStruct$corStruct, "p"),
                        attr(m$modelStruct$corStruct, "q")) else integer()),
       method = if (inherits(m, "merMod") && !inherits(m, "glmerMod")) (if (lme4::isREML(m)) "REML" else "ML")
                else if (inherits(m, "lme")) m$method else "",
       corstr = if (inherits(m, "geeglm")) m$corstr else "",
       nobs = tryCatch(stats::nobs(m), error = function(e) NA_real_))
}
# Likelihood-ratio test with the reference distribution of the hypothesis (STAT-17 / 23 / 41): |LR| <= tol below 0 is
# numerical noise (LR = 0, raw value kept); a materially negative, non-finite LR or df <= 0 gives no p-value.
# reference "chisq" = chi-square(df); "mixture" = 50:50 chi-square(df - 1) : chi-square(df) (chi-square(0) = point mass 0).
sx_lr_test <- function(ll0, ll1, df, reference = "chisq", tol = 1e-6) {
  raw <- 2 * (ll1 - ll0)
  out <- list(LR_raw = raw, LR = NA_real_, df = df, p = NA_real_, log_p = NA_real_,
      reference = reference,
              status = "tested", reason = "")
  if (!is.finite(raw)) { out$status <- "withheld"; out$reason <- "non-finite likelihood-ratio statistic"; return(out) }
  if (!is.finite(df) || df <= 0) { out$status <- "withheld"; out$reason <- "no extra parameters (df <= 0)"; return(out) }
  if (raw < -tol) { out$status <- "withheld"; out$reason <- sprintf(paste0("the larger model has a lower likelihood ",
    "(LR = %.6g): at least one optimization is unreliable; no p-value"), raw); return(out) }
  lr <- max(raw, 0); out$LR <- lr
  if (raw < 0) out$reason <- sprintf("negligible negative LR %.3g set to 0 (tolerance %g)",
      raw, tol)
  lp <- function(k) if (k == 0) (if (lr > 0) -Inf else 0) else stats::pchisq(lr,
      k, lower.tail = FALSE, log.p = TRUE)
  out$log_p <- if (reference == "mixture") { a <- log(0.5) + lp(df - 1); b <- log(0.5) + lp(df)
    mx <- max(a, b); if (!is.finite(mx)) mx else mx + log(exp(a - mx) + exp(b - mx)) } else lp(df)
  out$p <- exp(out$log_p)
  out
}
# Upper-tail F probability from full-precision statistics (STAT-42); log10 kept when the probability underflows.
sx_pf <- function(F, df1, df2) {
  p <- stats::pf(F, df1, df2, lower.tail = FALSE)
  lp <- stats::pf(F, df1, df2, lower.tail = FALSE, log.p = TRUE) / log(10)
  data.frame(p = p, log10_p = lp)
}

# ---- StatExplore: discovery helpers ----
# Fit one candidate's full model once, then evaluate each planned hypothesis as a nested
# comparison with a reduced model (tests[[1]] is the candidate's declared focal test).
# v1.3.4 (V134-001 / V134-012): fit statistics are cached only under a FIT KEY that proves what was fitted - the
# content of every column the model uses (response, design variables, grouping, time, occasion) in the exact row order
# with the row identities, plus the estimation context (family, structure, cluster, REML/ML, GEE family and working
# correlation, optimizer rules) and the sample context set by the caller. Row names, counts or formulas alone never
# justify reuse; validation resets the cache for every training part and bootstrap draw (sx_cache_reset).
# AUD134-01: the primary-test score shared by EVERY selection path (AMD validation and the legacy stability / procedure
# CV): the natural-log upper tail of tests[[1]], taken from the test distribution itself (log.p = TRUE). NA when the fit
# is not ok / warning, the test was withheld or has no p: never log(0) and never a substituted value.
sx_primary_logp <- function(r) {
  if (is.null(r) || !(r$status %in% c("ok", "warning")) || !length(r$tests)) return(NA_real_)
  t1 <- r$tests[[1]]
  if (!is.null(t1$withheld) || is.null(t1$log_p) || !length(t1$log_p)) return(NA_real_)
  as.numeric(t1$log_p)[1]
}
# argmin with the declared tie rule: the smallest score wins; exact ties -> the lower candidate position; NA never wins
sx_select_min <- function(score) {
  ok <- which(!is.na(score))
  if (!length(ok)) NA_integer_ else ok[which.min(score[ok])]
}
# AUD134-10: hard budget of model-fitting invocations (validation sets a finite cap per chunk). Every call of a model
# fitter counts - full, reduced, null and selected refits - each optimizer retry counts as one more, and so do the
# auxiliary fits (binary separation check, GEE QIC independence refit). Cache hits are counted apart and cost nothing.
sx_fit_budget <- new.env()
sx_budget_reset <- function(cap = Inf) {
  sx_fit_budget$cap <- cap; sx_fit_budget$used <- 0; sx_fit_budget$retries <- 0; sx_fit_budget$aux <- 0
  sx_fit_budget$denied <- 0   # AUD135-05: fits REFUSED by the cap (work truncated), distinct from reaching the cap
}
sx_budget_reset()
sx_budget_take <- function(kind = "fit") {
  if (sx_fit_budget$used >= sx_fit_budget$cap) {
    sx_fit_budget$denied <- sx_fit_budget$denied + 1
    stop(structure(class = c("sx_budget", "error", "condition"), list(call = NULL,
        message = sprintf(
      "fit budget reached: %d model-fitting invocations of the %s allowed", as.integer(sx_fit_budget$used),
      format(sx_fit_budget$cap)))))
  }
  sx_fit_budget$used <- sx_fit_budget$used + 1
  if (kind == "retry") sx_fit_budget$retries <- sx_fit_budget$retries + 1
  if (kind == "aux") sx_fit_budget$aux <- sx_fit_budget$aux + 1
  invisible(TRUE)
}
sx_disc_cache <- new.env()            # fit key -> fit statistics (with the producing fit's own diagnostics)
sx_disc_ctx <- "search"               # sample context: "search", or a validation split / bootstrap draw id
sx_disc_cache_log <- new.env()        # hits / misses (audit)
sx_disc_cache_log$hits <- 0L; sx_disc_cache_log$misses <- 0L
sx_disc_current <- NA_integer_        # candidate being evaluated (cache provenance)
sx_cache_reset <- function(ctx = "search") {
  rm(list = ls(sx_disc_cache, all.names = TRUE), envir = sx_disc_cache)
  rm(list = ls(sx_col_hashes, all.names = TRUE), envir = sx_col_hashes)
  sx_disc_ctx <<- ctx
}
sx_col_hashes <- new.env()            # column name -> (row names, column, MD5): each column hashed once per sample
sx_col_hash <- function(d, v) {
  rn <- rownames(d); col <- d[[v]]; e <- sx_col_hashes[[v]]
  if (!is.null(e) && identical(e$rn, rn) && identical(e$col, col)) return(e$h)
  h <- unname(tools::md5sum(bytes = serialize(list(v, rn, if (is.factor(col)) levels(col),
      unclass(col)), NULL, xdr = TRUE)))
  assign(v, list(rn = rn, col = col, h = h), envir = sx_col_hashes)
  h
}
sx_fit_key <- function(f, d) {
  cols <- intersect(c("sx_y", all.vars(f), "sx_gid", "sx_cluster", "sx_time",
      "sx_timef", "sx_occ"), names(d))
  terms <- sort(sx_canon_names(attr(stats::terms(f), "term.labels")))
  paste(c(sx_disc_ctx, sx_disc_family, sx_disc_struct, sx_disc_clustered, sx_disc_reml,
          if (sx_disc_family == "gee") c(sx_disc_gee_family, sx_gee_corstr(sx_disc_struct)), sx_disc_fit_rules,
          paste(terms, collapse = "+"), nrow(d), vapply(cols, function(v) paste0(v,
              "=", sx_col_hash(d, v)), "")),
        collapse = "|")
}
sx_gee_corstr <- function(st) switch(st, gee_exch = "exchangeable", gee_ar1 = "ar1",
    gee_ind = "independence",
                                      stop("not a GEE structure: ", st))
# Analysis-row signature: MD5 of the row identities in fitting order plus the levels of every factor model column
# (participant codes excluded: only their grouping matters). Equal signatures = same rows, order and coding.
sx_rows_sig <- function(d) {
  fac <- setdiff(names(d)[vapply(d, is.factor, logical(1))], "sx_gid")
  txt <- c(rownames(d), vapply(fac, function(v) paste0(v, ":", paste(levels(d[[v]]),
      collapse = "|")), ""))
  tf <- tempfile(); on.exit(unlink(tf)); writeLines(txt, tf, useBytes = TRUE)
  unname(tools::md5sum(tf))
}
sx_add <- function(f, extra) stats::update(f, stats::as.formula(paste(". ~ . +", extra)))
sx_last_run <- NULL                   # optimizer attempts of the most recent Gaussian longitudinal fit
sx_fit_lmm <- function(f, d, st, reml, clustered = sx_disc_clustered) {
  if (startsWith(st, "mmrm")) {
    cs <- switch(st, mmrm_us = "us", mmrm_cs = "cs", mmrm_ar1 = "ar1")
    sx_last_run <<- NULL
    return(mmrm::mmrm(sx_add(f, paste0(cs, "(sx_timef | sx_gid)")), data = d, reml = reml))
  }
  g <- sx_disc_gstruct[[st]]
  if (is.null(g)) stop("Unknown covariance structure: ", st)
  # one structure builder for every module (random part, residual correlation, nested cluster)
  run <- if (g[3] == "lme4")
    sx_fit_attempts(function(opt) lme4::lmer(sx_add(f, sx_re_lme4(g[1], clustered,
        "sx_time", "sx_gid")), data = d,
                                             REML = reml), "default") else
    sx_fit_attempts(function(opt) nlme::lme(f, random = sx_re_nlme(g[1],
        clustered, "sx_time", "sx_gid"),
      correlation = sx_cor_nlme(g[2], clustered, "sx_occ", "sx_time", "sx_gid"), data = d,
      method = if (reml) "REML" else "ML", control = nlme::lmeControl(opt = opt, msMaxIter = 200)),
      c("nlminb", "optim"))
  sx_last_run <<- run
  if (is.null(run$fit)) stop(run$error)
  run$fit
}
sx_fit_model <- function(f, d) {
  st <- sx_disc_struct
  if (sx_disc_family != "lmm" || startsWith(st, "mmrm")) sx_budget_take()     # nlme / lme4 attempts count themselves
  switch(sx_disc_family,
    lmm = sx_fit_lmm(f, d, st, sx_disc_reml, sx_disc_clustered),
    glmm = lme4::glmer(sx_add(f, if (st == "glmer_rs") "(1 + sx_time | sx_gid)" else "(1 | sx_gid)"),
        data = d,
                       family = stats::binomial()),
    clmm = ordinal::clmm(sx_add(f, if (st == "clmm_rs") "(1 + sx_time | sx_gid)" else "(1 | sx_gid)"),
        data = d,
                         link = "logit"),
    gee = sx_fit_gee(f, d, st),
    gaussian = stats::lm(f, d),
    ordinal = ordinal::clm(f, data = d, link = "logit"),
    multinomial = nnet::multinom(f, data = d, trace = FALSE, maxit = 1000, model = FALSE),
    stats::glm(f, data = d, family = stats::binomial()))
}
# GEE (V134-005): the working correlation of THIS candidate's structure, passed explicitly and read back from the
# fitted object; a mismatch fails closed.
sx_fit_gee <- function(f, d, st) {
  cs <- sx_gee_corstr(st)
  m <- geepack::geeglm(f, data = d, id = sx_gid, waves = sx_occ, corstr = cs,
                       family = if (sx_disc_gee_family == "binomial") stats::binomial() else stats::gaussian())
  if (!identical(as.character(m$corstr), cs))
    stop(sprintf("the fitted working correlation (%s) differs from the requested one (%s)",
        m$corstr, cs))
  m
}
sx_gee_readback <- function(m) {
  # what geepack actually estimated (never the request): working correlation, its parameter(s), scale, clusters
  list(corstr = as.character(m$corstr), alpha = I(as.numeric(m$geese$alpha)),
      scale = as.numeric(m$geese$gamma),
       clusters = length(unique(m$id)), nobs = length(m$y), family = m$family$family, link = m$family$link,
       robust_se = I(as.numeric(sqrt(diag(as.matrix(m$geese$vbeta))))))
}
# Fit a model and its statistics, capturing the warnings of THIS fit (V134-010): they belong to the fit that produced
# them and travel with it into the cache, so a reused reduced model keeps its diagnostics and an unrelated fit's warning
# never flags another test.
sx_fit_capture <- function(f, d) {
  w <- character()
  st <- withCallingHandlers({ m <- sx_fit_model(f, d); s <- sx_fit_stats(m,
      d); list(m = m, s = s) },
    warning = function(x) { w <<- c(w, conditionMessage(x)); invokeRestart("muffleWarning") })
  w <- unique(w)
  if (length(w)) {
    known <- if (is.null(st$s$diag)) character() else st$s$diag$flags
    extra <- w[!vapply(w, function(x) any(grepl(x, known, fixed = TRUE)), logical(1))]
    if (length(extra)) st$s$conv <- paste(c(if (nzchar(st$s$conv)) st$s$conv,
        paste("warning:", extra)), collapse = "; ")
  }
  st$s$warnings <- w
  st
}
sx_fit_stats <- function(m, d) {
  if (sx_disc_family == "gee") return(list(ll = NA_real_, k = length(stats::coef(m)), conv = ""))
  ll <- stats::logLik(m)
  out <- list(ll = as.numeric(ll), k = attr(ll, "df"), conv = "")
  if (sx_disc_family == "gaussian") { out$rss <- stats::deviance(m); out$dfres <- m$df.residual }
  if (sx_disc_family == "binomial") { out$dev <- m$deviance; out$dfres <- m$df.residual
    if (!m$converged) out$conv <- "did not converge" }
  if (sx_disc_family == "multinomial") { out$dev <- m$deviance; out$k <- m$edf
    if (m$convergence != 0) out$conv <- "did not converge (iteration limit)" }
  if (sx_disc_family == "ordinal" && !identical(as.integer(m$convergence$code), 0L))
    out$conv <- paste("did not converge:", paste(m$convergence$messages, collapse = " "))
  if (sx_disc_family == "glmm" && inherits(m, "merMod")) {
    conv <- unlist(m@optinfo$conv$lme4$messages)
    if (length(conv)) out$conv <- paste("convergence:", conv[1])
  }
  out$r2m <- NA_real_
  if (sx_disc_family == "lmm") {
    # every diagnostic of the fit (convergence, singular / near-boundary, apVar, optimizer fallback): STAT-18 / 32
    out$diag <- sx_diag(m, if (inherits(m, c("merMod", "lme"))) sx_last_run else NULL)
    out$conv <- paste(out$diag$flags, collapse = "; ")
    if (inherits(m, c("merMod", "lme"))) out$r2m <- sx_r2_direct(m, d)$m     # direct decomposition (STAT-45)
  }
  out
}
sx_reduced_stats <- function(reduced, d) {
  f0 <- stats::reformulate(if (length(reduced)) reduced else "1", response = "sx_y")
  key <- sx_fit_key(f0, d)
  hit <- sx_disc_cache[[key]]
  if (!is.null(hit)) {
    sx_disc_cache_log$hits <- sx_disc_cache_log$hits + 1L
    hit$source <- "cache"; return(hit)
  }
  sx_disc_cache_log$misses <- sx_disc_cache_log$misses + 1L
  st <- sx_fit_capture(f0, d)$s
  st$m <- NULL
  st$source <- "fitted"; st$fitted_for <- sx_disc_current; st$key_md5 <- unname(tools::md5sum(bytes = charToRaw(key)))
  assign(key, st, envir = sx_disc_cache)
  st
}
sx_null_scale <- function(d) {
  # denominators of the pseudo-R2 effects: -2 log L (ordinal) or deviance (logistic, multinomial) of y ~ 1, fitted to
  # exactly these rows (same fit key as any other model)
  st <- sx_reduced_stats(character(), d)
  if (sx_disc_family == "ordinal") -2 * st$ll else st$dev
}
# columns of the design matrix X that belong to model term `term` ("a:b" matches "b:a")
sx_term_cols <- function(X, f, term) {
  labs <- attr(stats::terms(f), "term.labels")
  norm <- function(x) vapply(strsplit(x, ":", fixed = TRUE), function(p) paste(sort(p),
      collapse = ":"), "")
  j <- match(norm(term), norm(labs))
  if (is.na(j)) character() else colnames(X)[attr(X, "assign") == j]
}
sx_wald <- function(m, X, f, drop) {
  # robust (sandwich) Wald test of all coefficients of the dropped terms (GEE)
  cols <- unlist(lapply(drop, function(t) sx_term_cols(X, f, t)))
  b <- stats::coef(m)[cols]; V <- as.matrix(stats::vcov(m))[cols, cols, drop = FALSE]
  w <- as.numeric(t(b) %*% solve(V, b))
  list(statistic = w, df1 = length(cols), df_den = NA_real_, p = stats::pchisq(w,
      length(cols), lower.tail = FALSE),
       log_p = stats::pchisq(w, length(cols), lower.tail = FALSE, log.p = TRUE), effect = NA_real_, partial_eta2 = NA_real_)
}
sx_compare <- function(s1, s0, d) {
  # V134-002: the natural log of the upper tail comes from the distribution itself (log.p = TRUE), never log(p)
  r <- list(statistic = NA_real_, df1 = NA_real_, df_den = NA_real_, p = NA_real_,
      log_p = NA_real_, effect = NA_real_,
            partial_eta2 = NA_real_)
  if (sx_disc_family == "gaussian") {
    ss <- s0$rss - s1$rss; r$df1 <- s0$dfres - s1$dfres; r$df_den <- s1$dfres
    r$statistic <- (ss / r$df1) / (s1$rss / s1$dfres)
    if (!is.finite(r$statistic) || r$df1 <= 0) {
      r$statistic <- NA_real_; r$withheld <- "no extra parameters or non-finite F statistic"
    } else if (r$statistic < 0) {
      # residual SS of the larger model above the smaller one's: only rounding noise can do this for nested OLS
      if (ss < -1e-8 * max(1, s0$rss)) r$withheld <- sprintf("the larger model has a larger residual SS (%.6g): no p-value",
          ss)
      else { r$statistic <- 0; r$p <- 1; r$log_p <- 0 }
    } else {
      r$p <- stats::pf(r$statistic, r$df1, r$df_den, lower.tail = FALSE)
      r$log_p <- stats::pf(r$statistic, r$df1, r$df_den, lower.tail = FALSE, log.p = TRUE)
    }
    r$effect <- ss / sum((d$sx_y - mean(d$sx_y))^2)                # delta R-squared
    r$partial_eta2 <- ss / (ss + s1$rss)
    return(r)
  }
  if (sx_disc_family %in% c("binomial", "multinomial")) {
    lr <- s0$dev - s1$dev
    r$df1 <- if (sx_disc_family == "binomial") s0$dfres - s1$dfres else s1$k - s0$k
  } else {
    lr <- 2 * (s1$ll - s0$ll); r$df1 <- s1$k - s0$k
  }
  r$statistic <- lr
  # STAT-41: a materially negative LR (larger model fits worse) means an unreliable optimization: no p-value
  t <- sx_lr_test(0, lr / 2, r$df1, "chisq")
  r$p <- t$p; r$log_p <- t$log_p; r$LR_raw <- t$LR_raw
  if (!identical(t$status, "tested")) r$withheld <- t$reason
  r$effect <- switch(sx_disc_family, lmm = s1$r2m - s0$r2m,             # delta marginal R-squared (lme4 RI)
                     glmm = NA_real_, clmm = NA_real_,
                     lr / sx_null_scale(d))                             # delta McFadden pseudo-R-squared
  r
}
sx_long <- function() sx_disc_family %in% c("lmm", "glmm", "clmm", "gee")
sx_discover_one <- function(full, tests, vars, focal_vars, struct = NULL, clustered = NULL,
    i = NA_integer_) {
  sx_disc_current <<- i
  if (!is.null(struct)) {      # workflow B: this candidate's structure
    old_struct <- sx_disc_struct; sx_disc_struct <<- struct; on.exit(sx_disc_struct <<- old_struct)
  }
  if (!is.null(clustered)) {   # workflow B exploratory: this candidate with or without the cluster variance
    old_cl <- sx_disc_clustered; sx_disc_clustered <<- clustered; on.exit(sx_disc_clustered <<- old_cl,
        add = TRUE)
  }
  res <- list(status = "ok", reason = "", flags = character(), n = NA_real_, n_params = NA_real_,
              n_groups = NA_real_, statistic = NA_real_, df1 = NA_real_, df2 = NA_real_, p = NA_real_,
              effect = NA_real_, partial_eta2 = NA_real_, estimate = NA_real_, se = NA_real_,
              ci_low = NA_real_, ci_high = NA_real_, r2 = NA_real_, adj_r2 = NA_real_, aic = NA_real_,
              bic = NA_real_, loglik = NA_real_, tests = list())
  invalid <- function(why) { res$status <- "invalid"; res$reason <- why; res$flags <- ""; res$tests <- NULL; res }
  d <- sx_complete(sx_dd, c("sx_y", vars, if (sx_long()) c("sx_gid", if (sx_disc_has_cluster) "sx_cluster",
                                                            if (sx_disc_has_time) c("sx_time",
                                                                "sx_timef", "sx_occ"))))
  # occasion index over the model's own rows (sx_timef levels were dropped above): a time value no analysed row has
  # is compressed exactly as in Full Analysis; a participant's skipped occasion still leaves an index gap
  if (sx_long() && sx_disc_has_time) d$sx_occ <- as.integer(d$sx_timef)
  n <- nrow(d); res$n <- n; res$rows_sig <- sx_rows_sig(d)
  if (n < sx_disc_min_obs) return(invalid(sprintf("%d complete rows; the minimum is %d",
      n, sx_disc_min_obs)))
  for (v in vars) if (is.factor(d[[v]]) && nlevels(d[[v]]) < 2)
    return(invalid(paste0(sx_names[[v]], " has fewer than 2 levels in the analysed rows")))
  if (sx_disc_family == "binomial" && length(unique(d$sx_y)) < 2) return(invalid("outcome has one value"))
  K <- if (is.factor(d$sx_y)) nlevels(d$sx_y) else NA_integer_
  if (sx_disc_family %in% c("glmm") || (sx_disc_family == "gee" && sx_disc_gee_family == "binomial"))
    if (length(unique(d$sx_y)) < 2) return(invalid("outcome has one value"))
  if (sx_disc_family %in% c("ordinal", "multinomial", "clmm") && K < 3)
    return(invalid(sprintf("only %d outcome categories observed in the analysed rows", K)))
  if (sx_disc_family == "multinomial" && !(sx_disc_ref %in% levels(d$sx_y)))
    return(invalid("the reference outcome category is not observed in the analysed rows"))
  f1 <- stats::reformulate(if (length(full)) full else "1", response = "sx_y")
  X <- stats::model.matrix(f1, d)
  # parameters: lm/glm = columns of X; ordinal = slopes + (K - 1) thresholds; multinomial = (K - 1) x columns
  k <- switch(sx_disc_family, ordinal = , clmm = ncol(X) - 1 + (K - 1), multinomial = (K - 1) * ncol(X),
      ncol(X))
  res$n_params <- k
  if (k > sx_disc_max_params) return(invalid(sprintf("%d parameters exceed the limit of %d",
      k, sx_disc_max_params)))
  if (n - k < 1) return(invalid("no residual degrees of freedom"))
  # focal_vars: one set of variables (focal interaction) or a list of sets (each interaction term)
  for (fs in if (is.list(focal_vars)) focal_vars else list(focal_vars)) {
    fv <- fs[vapply(d[fs], is.factor, logical(1))]
    if (length(fv)) {
      cells <- table(d[fv])
      if (length(fv) >= 2 && any(cells == 0)) return(invalid("empty cell among the focal factors"))
      if (min(cells) < 5) res$flags <- c(res$flags, sprintf("sparse focal cells (min n = %d)",
          min(cells)))
    }
  }
  # (checked after empty cells, which are the more specific explanation)
  if (qr(X)$rank < ncol(X)) return(invalid("design matrix is rank-deficient (not identifiable)"))
  cv <- vars[vapply(d[vars], is.numeric, logical(1))]
  if (length(cv) >= 2) {
    r <- abs(stats::cor(d[cv])); diag(r) <- 0
    if (max(r) > 0.9) res$flags <- c(res$flags, sprintf("|r| = %.2f between continuous predictors",
        max(r)))
  }
  if (sx_long() && (sx_disc_struct %in% c("glmer_rs", "clmm_rs") ||
                    (!is.null(sx_disc_gstruct[[sx_disc_struct]]) && sx_disc_gstruct[[sx_disc_struct]][1] != "ri"))) {
    k2 <- sum(tapply(d$sx_time, droplevels(d$sx_gid), function(x) length(unique(x))) >= 2)
    if (k2 < 10) return(invalid(sprintf("only %d participants have 2+ time points: a random slope is not estimable",
        k2)))
  }
  fc <- sx_fit_capture(f1, d); m1 <- fc$m; s1 <- fc$s
  if (sx_disc_family == "gee") res$gee <- sx_gee_readback(m1)
  if (!is.null(s1$diag)) {
    res$flags <- c(res$flags, if (nzchar(s1$conv)) strsplit(s1$conv, "; ", fixed = TRUE)[[1]])
    res$diagnostics <- s1$diag[c("status", "optimizer", "apvar")]
    res$diagnostics$attempts <- if (is.null(sx_last_run)) "" else paste(sprintf("%s: %s%s",
        sx_last_run$attempts$optimizer,
      sx_last_run$attempts$status, ifelse(nzchar(sx_last_run$attempts$error),
          paste0(" (", sx_last_run$attempts$error, ")"), "")),
      collapse = "; ")
  } else if (nzchar(s1$conv)) res$flags <- c(res$flags, s1$conv)
  # identity fingerprints of exactly what was fitted (rows, outcome, design, grouping): STAT-22
  res$identity <- sx_identity(d, f1, "sx_y", if (sx_long()) c("sx_gid", if (sx_disc_clustered) "sx_cluster") else character())
  if (sx_long()) {
    res$n_groups <- nlevels(droplevels(d$sx_gid))
    res$clustered <- sx_disc_clustered
    if (sx_disc_has_cluster) res$observed_clusters <- nlevels(droplevels(d$sx_cluster))
    res$modeled_clusters <- if (sx_disc_clustered) nlevels(droplevels(d$sx_cluster)) else 0
    if (sx_disc_family != "lmm" && inherits(m1, "merMod") && lme4::isSingular(m1))
      res$flags <- c(res$flags, "singular fit (a random-effect variance is ~ 0 or a correlation is +/-1)")
    if (sx_disc_family == "gee" && !identical(as.integer(m1$geese$error), 0L))
      res$flags <- c(res$flags, "GEE did not converge")
    if (sx_disc_family == "clmm" && !is.null(m1$condHess) && is.finite(m1$condHess) && m1$condHess > 1e4)
      res$flags <- c(res$flags, sprintf("ill-conditioned Hessian (condition number %.0f)",
          m1$condHess))
    if (sx_disc_family %in% c("glmm") || (sx_disc_family == "gee" && sx_disc_gee_family == "binomial")) {
      epp <- min(sum(d$sx_y), n - sum(d$sx_y)) / max(1, k - 1)
      if (epp < 10) res$flags <- c(res$flags, sprintf("%.1f events per parameter", epp))
    }
    res$r2 <- s1$r2m
    ctab <- switch(sx_disc_family,
      lmm = if (inherits(m1, "merMod")) cbind(lme4::fixef(m1), sqrt(diag(as.matrix(stats::vcov(m1))))) else
        if (inherits(m1, "lme")) summary(m1)$tTable[, 1:2, drop = FALSE] else
        cbind(stats::coef(m1), sqrt(diag(as.matrix(stats::vcov(m1))))),
      glmm = stats::coef(summary(m1))[, 1:2, drop = FALSE],
      clmm = stats::coef(summary(m1))[, 1:2, drop = FALSE],
      gee = stats::coef(summary(m1))[, 1:2, drop = FALSE])
    crit <- stats::qnorm(1 - (1 - sx_disc_conf) / 2)
  } else if (sx_disc_family == "gaussian") {
    sm <- summary(m1); res$r2 <- sm$r.squared; res$adj_r2 <- sm$adj.r.squared
    ctab <- stats::coef(sm)
    crit <- stats::qt(1 - (1 - sx_disc_conf) / 2, m1$df.residual)
  } else if (sx_disc_family == "binomial") {
    sx_budget_take("aux")
    sep <- stats::glm(f1, data = d, family = stats::binomial(), method = detectseparation::detect_separation)
    if (isTRUE(sep$outcome)) res$flags <- c(res$flags, "separation (infinite estimates)")
    ph <- stats::fitted(m1); res$r2 <- mean(ph[d$sx_y == 1]) - mean(ph[d$sx_y == 0])  # Tjur
    epp <- min(sum(d$sx_y), n - sum(d$sx_y)) / max(1, k - 1)
    if (epp < 10) res$flags <- c(res$flags, sprintf("%.1f events per parameter", epp))
    ctab <- stats::coef(summary(m1))
    crit <- stats::qnorm(1 - (1 - sx_disc_conf) / 2)
  } else {
    res$r2 <- if (sx_disc_family == "ordinal") 1 + s1$ll / (sx_null_scale(d) / 2) else 1 - s1$dev / sx_null_scale(d)
    small <- min(table(d$sx_y))
    if (small < 10) res$flags <- c(res$flags, sprintf("smallest outcome category has %d rows",
        small))
    ctab <- if (sx_disc_family == "ordinal") stats::coef(summary(m1)) else NULL
    crit <- stats::qnorm(1 - (1 - sx_disc_conf) / 2)
  }
  if (sx_disc_family != "gee") { ic <- sx_ic(m1); res$aic <- ic$aic; res$bic <- ic$bic; res$loglik <- s1$ll
    res$bic_n <- ic$n_bic; res$ic_basis <- ic$basis
    res$n_lik_params <- ic$k }   # every parameter of the likelihood (fixed + thresholds + covariance)
  for (t in tests) {
    if (sx_disc_family == "gee") {
      tr <- sx_wald(m1, X, f1, t$drop)
    } else {
      s0 <- sx_reduced_stats(t$reduced, d)
      tr <- sx_compare(s1, s0, d)
      # V134-010: the reference (reduced) fit's own diagnostics belong to THIS test only, with their provenance: a
      # flagged reference makes the test provisional; it does not flag the model or its other tests
      tr$reference_flags <- s0$conv
      tr$reference_source <- s0$source
      tr$reference_fitted_for <- if (is.null(s0$fitted_for)) NA_integer_ else s0$fitted_for
      tr$reference_key <- if (is.null(s0$key_md5)) "" else s0$key_md5
      tr$reference_loglik <- if (is.null(s0$ll)) NA_real_ else s0$ll
      tr$reference_k <- if (is.null(s0$k)) NA_real_ else s0$k
    }
    if (sx_disc_family == "multinomial" && isTRUE(tr$statistic < -1e-6))
      tr$reference_flags <- paste(c(if (nzchar(tr$reference_flags)) tr$reference_flags,
                                    "optimizer: the reduced model fitted better than the full model"), collapse = "; ")
    tr$id <- t$id; tr$estimate <- NA_real_; tr$se <- NA_real_; tr$ci_low <- NA_real_; tr$ci_high <- NA_real_
    if (length(t$drop) == 1 && isTRUE(tr$df1 == 1) && !is.null(ctab)) {
      col <- sx_term_cols(X, f1, t$drop)
      if (length(col) == 1 && col %in% rownames(ctab)) {
        co <- ctab[col, ]
        tr$estimate <- co[[1]]; tr$se <- co[[2]]
        tr$ci_low <- co[[1]] - crit * co[[2]]; tr$ci_high <- co[[1]] + crit * co[[2]]
      }
    }
    res$tests[[length(res$tests) + 1]] <- tr
  }
  if (sx_disc_family == "gee") {
    # QIC refits the independence model from the stored call (formula `f`, data `d`): give it both (P1-07)
    # V134-005: QIC, QICu and CIC of the ACTUAL fit (native geepack definitions), kept in their own fields
    qic_env <- list2env(list(f = f1, d = d), parent = environment())
    sx_budget_take("aux")        # QIC refits the independence model (outside the tryCatch: a budget stop is not a flag)
    q <- tryCatch(geepack::QIC(m1, env = qic_env),
                  error = function(e) { res$flags <<- c(res$flags,
                      paste("QIC unavailable:", conditionMessage(e))); NULL })
    pick <- function(nm) if (!is.null(q) && nm %in% names(q)) as.numeric(q[[nm]]) else NA_real_
    res$qic <- pick("QIC"); res$qicu <- pick("QICu"); res$cic <- pick("CIC"); res$quasi_lik <- pick("Quasi Lik")
    res$aic <- NA_real_; res$bic <- NA_real_; res$loglik <- NA_real_
  }
  # the declared focal test, also at the top level (v1.1 row layout)
  if (length(res$tests)) {
    t1 <- res$tests[[1]]
    for (nm in c("statistic", "df1", "p", "log_p", "effect", "partial_eta2",
        "estimate", "se", "ci_low", "ci_high"))
      res[[nm]] <- t1[[nm]]
    if (sx_disc_family == "gaussian") res$df2 <- t1$df_den
  }
  if (length(res$flags)) res$status <- "warning"
  res$flags <- paste(unique(res$flags), collapse = "; ")
  res
}
# Run a batch; per-candidate errors and warnings are recorded, never fatal.
sx_discover_batch <- function(batch) lapply(batch, function(s) {
  warns <- character()
  r <- tryCatch(withCallingHandlers(
      do.call(sx_discover_one, s[intersect(c("full", "tests", "vars", "focal_vars",
          "struct", "clustered", "i"), names(s))]),
      warning = function(w) { warns <<- c(warns, conditionMessage(w)); invokeRestart("muffleWarning") }),
    error = function(e) list(status = "failed", reason = conditionMessage(e), flags = ""))
  if (length(warns) && !identical(r$status, "failed") && !identical(r$status, "invalid")) {
    r$flags <- paste(c(if (nzchar(r$flags)) r$flags, unique(warns)), collapse = "; ")
    r$status <- "warning"
  }
  r$i <- s$i
  r
})

# ---- StatExplore: discovery setup ----
sx_disc_gstruct <- list(ri = c("ri", "independent", "lme4"), rs_uncorr = c("diag",
    "independent", "lme4"), rs = c("rs", "independent", "lme4"), nlme_ri = c("ri",
    "independent", "nlme"), nlme_diag = c("diag", "independent", "nlme"), nlme_rs = c("rs",
    "independent", "nlme"), ar1 = c("ri", "ar1", "nlme"), diag_ar1 = c("diag", "ar1",
    "nlme"), rs_ar1 = c("rs", "ar1", "nlme"), car1 = c("ri", "car1", "nlme"), diag_car1 = c("diag",
    "car1", "nlme"), rs_car1 = c("rs", "car1", "nlme"))  # structure key -> (random, residual, engine)
sx_disc_clustered <- FALSE  # participants nested in a higher-level cluster
sx_disc_has_cluster <- FALSE
sx_disc_vars <- c("v005", "v002", "v003", "v004")
sx_disc_family <- "gaussian"
sx_disc_max_params <- 40
sx_disc_conf <- 0.95
sx_disc_min_obs <- 0
sx_disc_shared <- TRUE
sx_disc_fit_rules <- "fit-rules-4"  # part of every fit key
sx_cache_reset("search")
sx_dd <- sx_complete(dat, sx_disc_vars)  # shared complete-case sample
sx_disc_struct <- "ri"
sx_disc_reml <- FALSE  # REML only to compare covariance structures with a locked fixed part
sx_disc_gee_family <- "gaussian"
sx_disc_has_time <- FALSE
sx_dd$sx_y <- sx_dd$v005
sx_setup_info <- list(n = nrow(sx_dd), n_complete = sum(stats::complete.cases(sx_dd)))


# ---- StatExplore AMD validation (v1.3.3): one split / bootstrap chunk per call ----
# test rows whose category levels never occur in the training part cannot be predicted: counted and excluded (reported)
sx_val_seen <- function(train, test, vars) {
  ok <- rep(TRUE, nrow(test))
  for (v in vars) if (is.factor(test[[v]])) ok <- ok & as.character(test[[v]]) %in% unique(as.character(train[[v]]))
  ok
}
sx_val_with <- function(a, expr_fun) {
  if (!is.null(a$struct)) { o <- sx_disc_struct; sx_disc_struct <<- a$struct; on.exit(sx_disc_struct <<- o) }
  if (!is.null(a$clustered)) { oc <- sx_disc_clustered; sx_disc_clustered <<- a$clustered
    on.exit(sx_disc_clustered <<- oc, add = TRUE) }
  expr_fun()
}
sx_val_need <- function(a) c("sx_y", a$vars, if (sx_long()) c("sx_gid", if (sx_disc_has_cluster) "sx_cluster",
                                                                if (sx_disc_has_time) c("sx_time",
                                                                    "sx_timef", "sx_occ")))
sx_val_fit <- function(a, d) sx_val_with(a, function() {
  d <- sx_complete(d, sx_val_need(a))
  if (sx_long() && sx_disc_has_time) d$sx_occ <- as.integer(d$sx_timef)
  sx_fit_model(stats::reformulate(if (length(a$full)) a$full else "1", response = "sx_y"), d)
})
sx_val_score <- function(a) {
  # V134-002 / AUD134-01: the p rule ranks the natural-log p of the primary test (sx_primary_logp, shared with the legacy
  # workspace); a budget stop is never a failed candidate: it aborts the training part
  r <- tryCatch(sx_val_with(a, function() do.call(sx_discover_one, a)),
                error = function(e) if (inherits(e, "sx_budget")) stop(e) else NULL)
  if (is.null(r) || !(r$status %in% c("ok", "warning"))) return(list(score = NA_real_,
      log_p = NA_real_, rows = "",
    status = if (is.null(r)) "failed" else r$status, reason = if (is.null(r)) "fit error" else r$reason,
    loglik = NA_real_, statistic = NA_real_, df = NA_real_, ref_loglik = NA_real_, flags = "", ref_flags = "", aic = NA_real_))
  t1 <- if (length(r$tests)) r$tests[[1]] else list()
  g <- function(x) if (is.null(x) || !length(x)) NA_real_ else as.numeric(x)[1]
  lp <- sx_primary_logp(r)
  # comparability key: the analysed row identities and the response values (SHA-256 fingerprints of the fit)
  rk <- if (is.null(r$identity)) r$rows_sig else paste(r$identity$rows, r$identity$response)
  list(score = if (sx_val_rule == "aic") r$aic else lp, log_p = lp, rows = rk,
      status = r$status, reason = "",
       loglik = g(r$loglik), statistic = g(t1$statistic), df = g(t1$df1), ref_loglik = g(t1$reference_loglik),
       flags = paste(r$flags, collapse = "; "), ref_flags = if (is.null(t1$reference_flags)) "" else t1$reference_flags,
       aic = g(r$aic))
}
sx_val_trace <- list()   # every candidate evaluated in every training part / draw (audit, V134-015)
# AUD134-05: the fitted object's fixed terms must be the candidate's terms (fail closed otherwise)
sx_val_check_terms <- function(m, a) {
  f <- tryCatch(if (inherits(m, "merMod")) stats::formula(m, fixed.only = TRUE) else stats::formula(m),
                error = function(e) NULL)
  if (is.null(f)) stop("the fitted model's terms could not be read back")
  got <- attr(stats::terms(f), "term.labels"); got <- got[!grepl("|", got, fixed = TRUE)]
  if (!setequal(sx_canon_names(got), sx_canon_names(a$full)))
    stop(sprintf("the fitted terms (%s) differ from the candidate's terms (%s)",
        paste(sort(got), collapse = " + "),
                 paste(sort(a$full), collapse = " + ")))
  invisible(TRUE)
}
# AUD135-05: `at_cap` = the cap was consumed (not an error); `denied` = fits the cap REFUSED (work truncated)
sx_val_budget <- function() list(used = sx_fit_budget$used, retries = sx_fit_budget$retries,
    aux = sx_fit_budget$aux,
  cap = if (is.finite(sx_fit_budget$cap)) sx_fit_budget$cap else NA_real_, at_cap = sx_fit_budget$used >= sx_fit_budget$cap,
  denied = sx_fit_budget$denied, cache_hits = sx_disc_cache_log$hits, cache_misses = sx_disc_cache_log$misses)
# a part during which the cap refused any fit is a budget stop, never a scored / fitted part (even when a wrapper
# swallowed the refusal as a failed candidate: its selection would not have considered every candidate)
sx_val_denied_since <- function(d0) sx_fit_budget$denied > d0
sx_val_budget_reason <- "fit budget: a model fit was refused by the hard cap (part not scored; the selection could not consider every candidate)"
sx_val_predict <- function(m, newd) {
  if (inherits(m, "merMod")) {
    rf <- switch(sx_val_target, participant_in_cluster = ~ (1 | sx_cluster), NA)
    return(as.numeric(stats::predict(m, newdata = newd, re.form = rf, allow.new.levels = TRUE)))
  }
  if (inherits(m, "lme")) return(as.numeric(stats::predict(m, newdata = newd,
                                 level = if (sx_val_target == "participant_in_cluster") 1 else 0)))
  as.numeric(stats::predict(m, newdata = newd, type = "response"))
}
sx_val_coef <- function(m, a) {
  # V134-011: EVERY coefficient of the candidate's primary tested term(s), one record each (never the first column only)
  none <- data.frame(term = character(), coefficient = character(), estimate = numeric(),
      stringsAsFactors = FALSE)
  b <- tryCatch(if (inherits(m, "merMod")) lme4::fixef(m) else if (inherits(m,
      "lme")) nlme::fixef(m) else stats::coef(m),
                error = function(e) NULL)
  if (is.null(b) || !length(a$tests)) return(none)
  drop <- sx_canon_names(unlist(a$tests[[1]]$drop))
  f <- stats::reformulate(if (length(a$full)) a$full else "1", response = "sx_y")
  lab <- sx_canon_names(attr(stats::terms(f), "term.labels"))
  X <- tryCatch(stats::model.matrix(stats::delete.response(stats::terms(f)),
      sx_val_lastd), error = function(e) NULL)
  if (is.null(X)) return(none)
  asg <- attr(X, "assign")
  keep <- asg %in% which(lab %in% drop) & colnames(X) %in% names(b)
  if (!any(keep)) return(none)
  data.frame(term = lab[asg[keep]], coefficient = colnames(X)[keep], estimate = unname(b[colnames(X)[keep]]),
             stringsAsFactors = FALSE)
}
# Training-only selection (V134-004): every outcome-dependent step - fitting, eligibility, ranking and the search's own
# stopping rule (replayed in candidate order) - uses the training rows only; the candidate pool is the a-priori space.
sx_val_select <- function(train, ctx) {
  sx_dd <<- train
  sx_cache_reset(ctx)           # V134-001: a fresh fit cache for every independent sample
  n <- length(sx_val_cands)
  if (n == 1) return(list(j = 1L, score = NA_real_, scores = NA_real_, visited = 1L,
      n_sig = NA_integer_, scored = 1L))
  sc <- rep(NA_real_, n); rows <- rep("", n); n_sig <- 0L; visited <- 0L
  for (j in seq_len(n)) {
    s <- sx_val_score(sx_val_cands[[j]]); visited <- j
    sc[j] <- s$score; rows[j] <- s$rows
    sx_val_trace[[length(sx_val_trace) + 1]] <<- data.frame(part = ctx, candidate_index = sx_val_index[j],
      status = s$status, reason = s$reason, loglik = s$loglik, statistic = s$statistic, df = s$df, log_p = s$log_p,
      reference_loglik = s$ref_loglik, aic = s$aic, score = s$score, flags = s$flags, reference_flags = s$ref_flags,
      rows_sig = s$rows, stringsAsFactors = FALSE)
    if (is.finite(s$log_p) && s$log_p < log(sx_val_alpha)) n_sig <- n_sig + 1L
    if (!is.na(sx_val_stop) && n_sig >= sx_val_stop) break    # the search's stopping rule, on training data
  }
  ok <- which(!is.na(sc))
  if (!length(ok)) return(list(j = NA_integer_, score = NA_real_, scores = sc,
      visited = visited, n_sig = n_sig,
                               scored = 0L))
  if (sx_val_rule == "aic" && length(unique(rows[ok])) > 1)
    stop("AIC is not comparable here: the candidates were fitted to different training rows (per-model complete cases)")
  j <- sx_select_min(sc)         # exact ties: the lower candidate index (documented secondary key); NA never wins
  list(j = j, score = sc[j], scores = sc, visited = visited, n_sig = n_sig, scored = length(ok))
}
sx_val_fold_budget <- function(split_id, f, n_train, reason) list(split = split_id,
    fold = f, status = "budget",
  reason = reason, selected = "", selected_index = NA_integer_, selected_key = "", train_score = NA_real_,
  visited = NA_integer_, scored = NA_integer_, n_sig_train = NA_integer_, n_train = n_train, n_test = 0L,
  train_mean = NA_real_, train_groups = NA_real_, test_groups = NA_real_, train_clusters = NA_real_,
  test_clusters = NA_real_, excluded_incomplete = NA_real_, excluded_unseen_levels = NA_real_,
  excluded_unpredicted = NA_real_, test_events = NA_real_, diagnostics = "")
sx_val_split <- function(split_id, fold_of) {
  sx_val_trace <<- list()
  folds <- sort(unique(fold_of[!is.na(fold_of) & fold_of > 0]))
  preds <- list(); info <- list()
  for (f in folds) {
    tr <- sx_val_full[is.na(fold_of) | fold_of != f, , drop = FALSE]
    te <- sx_val_full[!is.na(fold_of) & fold_of == f, , drop = FALSE]
    d0 <- sx_fit_budget$denied; pf <- NULL
    res <- if (d0 > 0) sx_val_fold_budget(split_id, f, nrow(tr), "fit budget used up before this part started (not run)") else tryCatch({
      if (length(intersect(rownames(tr), rownames(te)))) stop("internal: a row is in both parts")
      if (sx_val_target != "rows" && length(intersect(as.character(tr$sx_gid),
          as.character(te$sx_gid))))
        stop("internal: a participant is in both parts")
      if (sx_val_target == "cluster" && length(intersect(as.character(tr$sx_cluster),
          as.character(te$sx_cluster))))
        stop("internal: a cluster is in both parts")
      if (sx_val_target == "participant_in_cluster" && !all(as.character(te$sx_cluster) %in% as.character(tr$sx_cluster)))
        stop("internal: a test cluster has no training rows")
      sel <- sx_val_select(tr, paste0(split_id, ":fold", f))
      if (is.na(sel$j)) stop("no candidate could be fitted on the training part")
      a <- sx_val_cands[[sel$j]]
      m <- sx_val_fit(a, tr)
      sx_val_check_terms(m, a)
      trc <- sx_complete(tr, sx_val_need(a))
      tec <- sx_complete(te, sx_val_need(a)); n_incomplete <- nrow(te) - nrow(tec)
      seen <- sx_val_seen(trc, tec, setdiff(a$vars, c("sx_timef", "sx_gid", "sx_cluster")))
      n_unseen <- sum(!seen); tec <- tec[seen, , drop = FALSE]
      if (sx_long() && sx_disc_has_time) tec$sx_occ <- as.integer(tec$sx_timef)
      p <- sx_val_predict(m, tec)
      ok <- is.finite(p)
      pf <- data.frame(split = split_id, fold = f, row_id = as.integer(rownames(tec))[ok],
        observed = tec$sx_y[ok], predicted = p[ok],
        participant = if (sx_long()) as.character(tec$sx_gid)[ok] else as.character(rownames(tec))[ok],
        cluster = if (sx_long() && sx_disc_has_cluster) as.character(tec$sx_cluster)[ok] else "", stringsAsFactors = FALSE)
      list(split = split_id, fold = f, status = "scored", reason = "",
          selected = sx_val_labels[sel$j],
           selected_index = sx_val_index[sel$j], selected_key = sx_val_keys[sel$j], train_score = sel$score,
           visited = sel$visited,
           scored = sel$scored, n_sig_train = sel$n_sig, n_train = nrow(trc), n_test = sum(ok),
           train_mean = mean(trc$sx_y), train_groups = if (sx_long()) nlevels(droplevels(trc$sx_gid)) else nrow(trc),
           test_groups = if (sx_long()) length(unique(as.character(tec$sx_gid[ok]))) else sum(ok),
           train_clusters = if (sx_long() && sx_disc_has_cluster) nlevels(droplevels(trc$sx_cluster)) else 0L,
           test_clusters = if (sx_long() && sx_disc_has_cluster) length(unique(as.character(tec$sx_cluster[ok]))) else 0L,
           excluded_incomplete = n_incomplete, excluded_unseen_levels = n_unseen, excluded_unpredicted = sum(!ok),
           test_events = if (sx_disc_family == "binomial" || identical(sx_disc_gee_family,
               "binomial")) sum(tec$sx_y[ok] == 1) else NA_real_,
           diagnostics = tryCatch(paste(sx_diag(m, sx_last_run)$flags,
               collapse = "; "), error = function(e) ""))
    }, error = function(e) list(split = split_id, fold = f, status = if (inherits(e,
        "sx_budget")) "budget" else "failed",
                                 reason = conditionMessage(e), selected = "", selected_index = NA_integer_,
                                 selected_key = "", train_score = NA_real_, visited = NA_integer_,
                                 scored = NA_integer_, n_sig_train = NA_integer_, n_train = nrow(tr),
                                 n_test = 0L, train_mean = NA_real_, train_groups = NA_real_, test_groups = NA_real_,
                                 train_clusters = NA_real_, test_clusters = NA_real_, excluded_incomplete = NA_real_,
                                 excluded_unseen_levels = NA_real_, excluded_unpredicted = NA_real_, test_events = NA_real_,
                                 diagnostics = ""))
    if (d0 == 0 && sx_val_denied_since(d0) && res$status != "budget") {
      res <- sx_val_fold_budget(split_id, f, nrow(tr), sx_val_budget_reason); pf <- NULL
    }
    if (!is.null(pf) && identical(res$status, "scored")) preds[[length(preds) + 1]] <- pf
    info[[length(info) + 1]] <- as.data.frame(res, stringsAsFactors = FALSE)
  }
  sx_dd <<- sx_val_full
  sx_cache_reset("search")
  list(folds = do.call(rbind, info), predictions = if (length(preds)) do.call(rbind,
      preds) else NULL,
       trace = if (length(sx_val_trace)) do.call(rbind, sx_val_trace) else NULL)
}
sx_val_boot_budget <- function(b, reason) list(b = b, status = "budget", reason = reason,
    selected = "",
  selected_index = NA_integer_, selected_key = "", train_score = NA_real_, visited = NA_integer_, scored = NA_integer_,
  n_sig_train = NA_integer_, coefficient = "", estimate = NA_real_, n_coef = 0L, diagnostics = "budget", flags = "",
  n = NA_real_, groups = NA_real_)
sx_val_boot <- function(draws) {
  out <- list(); coefs <- list(); sx_val_trace <<- list()
  for (b in sort(unique(draws$b))) {
    dr <- draws[draws$b == b, , drop = FALSE]
    d0 <- sx_fit_budget$denied; cfb <- NULL
    res <- if (d0 > 0) sx_val_boot_budget(b, "fit budget used up before this draw started (not run)") else tryCatch({
      d <- sx_val_full[match(as.character(dr$row_id), rownames(sx_val_full)), , drop = FALSE]
      keep <- !is.na(match(as.character(dr$row_id), rownames(sx_val_full)))
      d <- d[keep, , drop = FALSE]; dr <- dr[keep, , drop = FALSE]
      if (sx_long()) {
        d$sx_gid <- factor(dr$draw_gid)            # a unit drawn twice = two sampled units (new IDs)
        if (sx_disc_has_cluster) d$sx_cluster <- factor(ifelse(nzchar(dr$draw_cluster),
            dr$draw_cluster, as.character(d$sx_cluster)))
      }
      # deterministic, draw-specific row identities: draw b, position k in the draw (source row kept in the manifest)
      rownames(d) <- paste0("b", b, ".", seq_len(nrow(d)))
      if (sx_long() && sx_disc_has_time) d <- d[order(d$sx_gid, d$sx_time), , drop = FALSE]
      sel <- sx_val_select(d, paste0("boot", b))
      if (is.na(sel$j)) stop("no candidate could be fitted on this resample")
      a <- sx_val_cands[[sel$j]]
      m <- sx_val_fit(a, d)
      sx_val_check_terms(m, a)
      sx_val_lastd <<- sx_complete(d, sx_val_need(a))
      cf <- sx_val_coef(m, a)
      if (nrow(cf)) cfb <- data.frame(b = b, selected_index = sx_val_index[sel$j],
          selected_key = sx_val_keys[sel$j],
                                      cf, stringsAsFactors = FALSE)
      dg <- tryCatch(sx_diag(m, sx_last_run), error = function(e) list(status = "unknown",
          flags = character()))
      list(b = b, status = "fitted", reason = "", selected = sx_val_labels[sel$j],
          selected_index = sx_val_index[sel$j],
           selected_key = sx_val_keys[sel$j], train_score = sel$score, visited = sel$visited, scored = sel$scored, n_sig_train = sel$n_sig,
           coefficient = if (nrow(cf)) cf$coefficient[nrow(cf)] else "", estimate = if (nrow(cf)) cf$estimate[nrow(cf)] else NA_real_,
           n_coef = nrow(cf), diagnostics = paste(dg$status, collapse = ""),
           flags = paste(dg$flags, collapse = "; "), n = nrow(sx_val_lastd),
           groups = if (sx_long()) nlevels(droplevels(sx_val_lastd$sx_gid)) else nrow(sx_val_lastd))
    }, error = function(e) list(b = b, status = if (inherits(e, "sx_budget")) "budget" else "failed",
                                 reason = conditionMessage(e), selected = "", selected_index = NA_integer_,
                                 selected_key = "", train_score = NA_real_, visited = NA_integer_,
                                 scored = NA_integer_, n_sig_train = NA_integer_, coefficient = "", estimate = NA_real_,
                                 n_coef = 0L, diagnostics = "failed", flags = "", n = NA_real_, groups = NA_real_))
    if (d0 == 0 && sx_val_denied_since(d0) && res$status != "budget") { res <- sx_val_boot_budget(b,
        sx_val_budget_reason); cfb <- NULL }
    if (!is.null(cfb) && identical(res$status, "fitted")) coefs[[length(coefs) + 1]] <- cfb
    out[[length(out) + 1]] <- as.data.frame(res, stringsAsFactors = FALSE)
  }
  sx_dd <<- sx_val_full
  sx_cache_reset("search")
  list(draws = do.call(rbind, out), coefs = if (length(coefs)) do.call(rbind, coefs) else NULL,
       trace = if (length(sx_val_trace)) do.call(rbind, sx_val_trace) else NULL)
}

sx_val_cands <- list(list(full = c("v002", "v003", "v002:v003"), tests = list(list(id = 0L,
    type = "focal_interaction", reduced = c("v002", "v003"), drop = c("v002:v003"))),
    vars = c("v002", "v003"), focal_vars = c("v002", "v003")),
  list(full = c("v002", "v004", "v002:v004"), tests = list(list(id = 0L, type = "focal_interaction",
      reduced = c("v002", "v004"), drop = c("v002:v004"))), vars = c("v002", "v004"),
      focal_vars = c("v002", "v004")),
  list(full = c("v003", "v004", "v003:v004"), tests = list(list(id = 0L, type = "focal_interaction",
      reduced = c("v003", "v004"), drop = c("v003:v004"))), vars = c("v003", "v004"),
      focal_vars = c("v003", "v004")))
sx_val_labels <- c("x1 \u00d7 x3 [#0]", "x1 \u00d7 x2 [#1]", "x3 \u00d7 x2 [#2]")
sx_val_keys <- c("x1:x3|x1+x1:x3+x3", "x1:x2|x1+x1:x2+x2", "x2:x3|x2+x2:x3+x3")
sx_val_index <- c(0.0, 1.0, 2.0)
sx_val_rule <- "p"
sx_val_target <- "rows"
sx_val_alpha <- 0.05
sx_val_stop <- NA  # the search's stopping rule, replayed on training data (NA = none)
if (!exists("sx_disc_gee_family")) sx_disc_gee_family <- ""
sx_val_full <- sx_dd; sx_val_lastd <- sx_dd
sx_rep_pred <- list(); sx_rep_folds <- list(); sx_rep_boot <- list(); sx_rep_coef <- list()
sx_rep_trace <- list(); sx_rep_man <- list(); sx_rep_draws <- list()
# ---- committed chunk 1 ----
sx_vfold <- NULL; sx_vdraws <- NULL; sx_vr <- NULL
sx_budget_reset(100000)  # hard budget: model-fitting invocations left for this chunk
sx_disc_cache_log$hits <- 0L; sx_disc_cache_log$misses <- 0L
sx_vfold <- c(0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0,
    1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0,
    1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0,
    1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0,
    1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0,
    0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
    0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0,
    0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1,
    1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1,
    0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0,
    0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0,
    0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0,
    1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0,
    0, 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1,
    1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1,
    1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1,
    0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1,
    1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0,
    1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0,
    1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0,
    1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1,
    1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0,
    0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1,
    1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1,
    1, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0,
    1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1,
    0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1,
    0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 0,
    1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0,
    1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 1,
    0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0,
    0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0,
    1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1,
    1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
    1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0,
    0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0,
    1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0,
    0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0,
    1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0,
    0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1,
    1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0,
    0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0,
    1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0,
    0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0,
    1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0,
    0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0,
    1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1,
    1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0,
    0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1,
    0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1,
    0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0,
    1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0,
    0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1)
names(sx_vfold) <- c(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
    18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37,
    38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57,
    58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77,
    78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97,
    98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113,
    114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129,
    130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145,
    146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161,
    162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177,
    178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193,
    194, 195, 196, 197, 198, 199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209,
    210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225,
    226, 227, 228, 229, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241,
    242, 243, 244, 245, 246, 247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257,
    258, 259, 260, 261, 262, 263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273,
    274, 275, 276, 277, 278, 279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289,
    290, 291, 292, 293, 294, 295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305,
    306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321,
    322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337,
    338, 339, 340, 341, 342, 343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353,
    354, 355, 356, 357, 358, 359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369,
    370, 371, 372, 373, 374, 375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385,
    386, 387, 388, 389, 390, 391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401,
    402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417,
    418, 419, 420, 421, 422, 423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433,
    434, 435, 436, 437, 438, 439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449,
    450, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465,
    466, 467, 468, 469, 470, 471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481,
    482, 483, 484, 485, 486, 487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497,
    498, 499, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513,
    514, 515, 516, 517, 518, 519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529,
    530, 531, 532, 533, 534, 535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545,
    546, 547, 548, 549, 550, 551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561,
    562, 563, 564, 565, 566, 567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577,
    578, 579, 580, 581, 582, 583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593,
    594, 595, 596, 597, 598, 599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609,
    610, 611, 612, 613, 614, 615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625,
    626, 627, 628, 629, 630, 631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641,
    642, 643, 644, 645, 646, 647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657,
    658, 659, 660, 661, 662, 663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673,
    674, 675, 676, 677, 678, 679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689,
    690, 691, 692, 693, 694, 695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705,
    706, 707, 708, 709, 710, 711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721,
    722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737,
    738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753,
    754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769,
    770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785,
    786, 787, 788, 789, 790, 791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801,
    802, 803, 804, 805, 806, 807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817,
    818, 819, 820, 821, 822, 823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833,
    834, 835, 836, 837, 838, 839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849,
    850, 851, 852, 853, 854, 855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865,
    866, 867, 868, 869, 870, 871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881,
    882, 883, 884, 885, 886, 887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897,
    898, 899, 900, 901, 902, 903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913,
    914, 915, 916, 917, 918, 919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929,
    930, 931, 932, 933, 934, 935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945,
    946, 947, 948, 949, 950, 951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961,
    962, 963, 964, 965, 966, 967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977,
    978, 979, 980, 981, 982, 983, 984, 985, 986, 987, 988, 989, 990, 991, 992, 993,
    994, 995, 996, 997, 998, 999, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007,
    1008, 1009, 1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020,
    1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033,
    1034, 1035, 1036, 1037, 1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046,
    1047, 1048, 1049, 1050, 1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059,
    1060, 1061, 1062, 1063, 1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072,
    1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 1085,
    1086, 1087, 1088, 1089, 1090, 1091, 1092, 1093, 1094, 1095, 1096, 1097, 1098,
    1099, 1100, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111,
    1112, 1113, 1114, 1115, 1116, 1117, 1118, 1119, 1120, 1121, 1122, 1123, 1124,
    1125, 1126, 1127, 1128, 1129, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137,
    1138, 1139, 1140, 1141, 1142, 1143, 1144, 1145, 1146, 1147, 1148, 1149, 1150,
    1151, 1152, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1160, 1161, 1162, 1163,
    1164, 1165, 1166, 1167, 1168, 1169, 1170, 1171, 1172, 1173, 1174, 1175, 1176,
    1177, 1178, 1179, 1180, 1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189,
    1190, 1191, 1192, 1193, 1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202,
    1203, 1204, 1205, 1206, 1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215,
    1216, 1217, 1218, 1219, 1220, 1221, 1222, 1223, 1224, 1225, 1226, 1227, 1228,
    1229, 1230, 1231, 1232, 1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241,
    1242, 1243, 1244, 1245, 1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1254,
    1255, 1256, 1257, 1258, 1259, 1260, 1261, 1262, 1263, 1264, 1265, 1266, 1267,
    1268, 1269, 1270, 1271, 1272, 1273, 1274, 1275, 1276, 1277, 1278, 1279, 1280,
    1281, 1282, 1283, 1284, 1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1293,
    1294, 1295, 1296, 1297, 1298, 1299, 1300, 1301, 1302, 1303, 1304, 1305, 1306,
    1307, 1308, 1309, 1310, 1311, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319,
    1320, 1321, 1322, 1323, 1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332,
    1333, 1334, 1335, 1336, 1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345,
    1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358,
    1359, 1360, 1361, 1362, 1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1371,
    1372, 1373, 1374, 1375, 1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384,
    1385, 1386, 1387, 1388, 1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1397,
    1398, 1399, 1400, 1401, 1402, 1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410,
    1411, 1412, 1413, 1414, 1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423,
    1424, 1425, 1426, 1427, 1428, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1436,
    1437, 1438, 1439, 1440, 1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449,
    1450, 1451, 1452, 1453, 1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1462,
    1463, 1464, 1465, 1466, 1467, 1468, 1469, 1470, 1471, 1472, 1473, 1474, 1475,
    1476, 1477, 1478, 1479, 1480, 1481, 1482, 1483, 1484, 1485, 1486, 1487, 1488,
    1489, 1490, 1491, 1492, 1493, 1494, 1495, 1496, 1497, 1498, 1499, 1500, 1501,
    1502, 1503, 1504, 1505, 1506, 1507, 1508, 1509, 1510, 1511, 1512, 1513, 1514,
    1515, 1516, 1517, 1518, 1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527,
    1528, 1529, 1530, 1531, 1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540,
    1541, 1542, 1543, 1544, 1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553,
    1554, 1555, 1556, 1557, 1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566,
    1567, 1568, 1569, 1570, 1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579,
    1580, 1581, 1582, 1583, 1584, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592,
    1593, 1594, 1595, 1596, 1597, 1598, 1599, 1600, 1601, 1602, 1603, 1604, 1605,
    1606, 1607, 1608, 1609, 1610, 1611, 1612, 1613, 1614, 1615, 1616, 1617, 1618,
    1619, 1620, 1621, 1622, 1623, 1624, 1625, 1626, 1627, 1628, 1629, 1630, 1631,
    1632, 1633, 1634, 1635, 1636, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1644,
    1645, 1646, 1647, 1648, 1649, 1650, 1651, 1652, 1653, 1654, 1655, 1656, 1657,
    1658, 1659, 1660, 1661, 1662, 1663, 1664, 1665, 1666, 1667, 1668, 1669, 1670,
    1671, 1672, 1673, 1674, 1675, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683,
    1684, 1685, 1686, 1687, 1688, 1689, 1690, 1691, 1692, 1693, 1694, 1695, 1696,
    1697, 1698, 1699, 1700, 1701, 1702, 1703, 1704, 1705, 1706, 1707, 1708, 1709,
    1710, 1711, 1712, 1713, 1714, 1715, 1716, 1717, 1718, 1719, 1720, 1721, 1722,
    1723, 1724, 1725, 1726, 1727, 1728, 1729, 1730, 1731, 1732, 1733, 1734, 1735,
    1736, 1737, 1738, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748,
    1749, 1750, 1751, 1752, 1753, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1761,
    1762, 1763, 1764, 1765, 1766, 1767, 1768, 1769, 1770, 1771, 1772, 1773, 1774,
    1775, 1776, 1777, 1778, 1779, 1780, 1781, 1782, 1783, 1784, 1785, 1786, 1787,
    1788, 1789, 1790, 1791, 1792, 1793, 1794, 1795, 1796, 1797, 1798, 1799, 1800,
    1801, 1802, 1803, 1804, 1805, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1813,
    1814, 1815, 1816, 1817, 1818, 1819, 1820, 1821, 1822, 1823, 1824, 1825, 1826,
    1827, 1828, 1829, 1830, 1831, 1832, 1833, 1834, 1835, 1836, 1837, 1838, 1839,
    1840, 1841, 1842, 1843, 1844, 1845, 1846, 1847, 1848, 1849, 1850, 1851, 1852,
    1853, 1854, 1855, 1856, 1857, 1858, 1859, 1860, 1861, 1862, 1863, 1864, 1865,
    1866, 1867, 1868, 1869, 1870, 1871, 1872, 1873, 1874, 1875, 1876, 1877, 1878,
    1879, 1880, 1881, 1882, 1883, 1884, 1885, 1886, 1887, 1888, 1889, 1890, 1891,
    1892, 1893, 1894, 1895, 1896, 1897, 1898, 1899, 1900, 1901, 1902, 1903, 1904,
    1905, 1906, 1907, 1908, 1909, 1910, 1911, 1912, 1913, 1914, 1915, 1916, 1917,
    1918, 1919, 1920, 1921, 1922, 1923, 1924, 1925, 1926, 1927, 1928, 1929, 1930,
    1931, 1932, 1933, 1934, 1935, 1936, 1937, 1938, 1939, 1940, 1941, 1942, 1943,
    1944, 1945, 1946, 1947, 1948, 1949, 1950, 1951, 1952, 1953, 1954, 1955, 1956,
    1957, 1958, 1959, 1960, 1961, 1962, 1963, 1964, 1965, 1966, 1967, 1968, 1969,
    1970, 1971, 1972, 1973, 1974, 1975, 1976, 1977, 1978, 1979, 1980, 1981, 1982,
    1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995,
    1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008,
    2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021,
    2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034,
    2035, 2036, 2037, 2038, 2039, 2040, 2041, 2042, 2043, 2044, 2045, 2046, 2047,
    2048, 2049, 2050, 2051, 2052, 2053, 2054, 2055, 2056, 2057, 2058, 2059, 2060,
    2061, 2062, 2063, 2064, 2065, 2066, 2067, 2068, 2069, 2070, 2071, 2072, 2073,
    2074, 2075, 2076, 2077, 2078, 2079, 2080, 2081, 2082, 2083, 2084, 2085, 2086,
    2087, 2088, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2098, 2099,
    2100, 2101, 2102, 2103, 2104, 2105, 2106, 2107, 2108, 2109, 2110, 2111, 2112,
    2113, 2114, 2115, 2116, 2117, 2118, 2119, 2120, 2121, 2122, 2123, 2124, 2125,
    2126, 2127, 2128, 2129, 2130, 2131, 2132, 2133, 2134, 2135, 2136, 2137, 2138,
    2139, 2140, 2141, 2142, 2143, 2144, 2145, 2146, 2147, 2148, 2149, 2150, 2151,
    2152, 2153, 2154, 2155, 2156, 2157, 2158, 2159, 2160, 2161, 2162, 2163, 2164,
    2165, 2166, 2167, 2168, 2169, 2170, 2171, 2172, 2173, 2174, 2175, 2176, 2177,
    2178, 2179, 2180, 2181, 2182, 2183, 2184, 2185, 2186, 2187, 2188, 2189, 2190,
    2191, 2192, 2193, 2194, 2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203,
    2204, 2205, 2206, 2207, 2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216,
    2217, 2218, 2219, 2220, 2221, 2222, 2223, 2224, 2225, 2226, 2227, 2228, 2229,
    2230, 2231, 2232, 2233, 2234, 2235, 2236, 2237, 2238, 2239, 2240, 2241, 2242,
    2243, 2244, 2245, 2246, 2247, 2248, 2249, 2250, 2251, 2252, 2253, 2254, 2255,
    2256, 2257, 2258, 2259, 2260, 2261, 2262, 2263, 2264, 2265, 2266, 2267, 2268,
    2269, 2270, 2271, 2272, 2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2281,
    2282, 2283, 2284, 2285, 2286, 2287, 2288, 2289, 2290, 2291, 2292, 2293, 2294,
    2295, 2296, 2297, 2298, 2299, 2300, 2301, 2302, 2303, 2304, 2305, 2306, 2307,
    2308, 2309, 2310, 2311, 2312, 2313, 2314, 2315, 2316, 2317, 2318, 2319, 2320,
    2321, 2322, 2323, 2324, 2325, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333,
    2334, 2335, 2336, 2337, 2338, 2339, 2340, 2341, 2342, 2343, 2344, 2345, 2346,
    2347, 2348, 2349, 2350, 2351, 2352, 2353, 2354, 2355, 2356, 2357, 2358, 2359,
    2360, 2361, 2362, 2363, 2364, 2365, 2366, 2367, 2368, 2369, 2370, 2371, 2372,
    2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2383, 2384, 2385,
    2386, 2387, 2388, 2389, 2390, 2391, 2392, 2393, 2394, 2395, 2396, 2397, 2398,
    2399, 2400, 2401, 2402, 2403, 2404, 2405, 2406, 2407, 2408, 2409, 2410, 2411,
    2412, 2413, 2414, 2415, 2416, 2417, 2418, 2419, 2420, 2421, 2422, 2423, 2424,
    2425, 2426, 2427, 2428, 2429, 2430, 2431, 2432, 2433, 2434, 2435, 2436, 2437,
    2438, 2439, 2440, 2441, 2442, 2443, 2444, 2445, 2446, 2447, 2448, 2449, 2450,
    2451, 2452, 2453, 2454, 2455, 2456, 2457, 2458, 2459, 2460, 2461, 2462, 2463,
    2464, 2465, 2466, 2467, 2468, 2469, 2470, 2471, 2472, 2473, 2474, 2475, 2476,
    2477, 2478, 2479, 2480, 2481, 2482, 2483, 2484, 2485, 2486, 2487, 2488, 2489,
    2490, 2491, 2492, 2493, 2494, 2495, 2496, 2497, 2498, 2499, 2500, 2501, 2502,
    2503, 2504, 2505, 2506, 2507, 2508, 2509, 2510, 2511, 2512, 2513, 2514, 2515,
    2516, 2517, 2518, 2519, 2520, 2521, 2522, 2523, 2524, 2525, 2526, 2527, 2528,
    2529, 2530, 2531, 2532, 2533, 2534, 2535, 2536, 2537, 2538, 2539, 2540, 2541,
    2542, 2543, 2544, 2545, 2546, 2547, 2548, 2549, 2550, 2551, 2552, 2553, 2554,
    2555, 2556, 2557, 2558, 2559, 2560, 2561, 2562, 2563, 2564, 2565, 2566, 2567,
    2568, 2569, 2570, 2571, 2572, 2573, 2574, 2575, 2576, 2577, 2578, 2579, 2580,
    2581, 2582, 2583, 2584, 2585, 2586, 2587, 2588, 2589, 2590, 2591, 2592, 2593,
    2594, 2595, 2596, 2597, 2598, 2599, 2600, 2601, 2602, 2603, 2604, 2605, 2606,
    2607, 2608, 2609, 2610, 2611, 2612, 2613, 2614, 2615, 2616, 2617, 2618, 2619,
    2620, 2621, 2622, 2623, 2624, 2625, 2626, 2627, 2628, 2629, 2630, 2631, 2632,
    2633, 2634, 2635, 2636, 2637, 2638, 2639, 2640, 2641, 2642, 2643, 2644, 2645,
    2646, 2647, 2648, 2649, 2650, 2651, 2652, 2653, 2654, 2655, 2656, 2657, 2658,
    2659, 2660, 2661, 2662, 2663, 2664, 2665, 2666, 2667, 2668, 2669, 2670, 2671,
    2672, 2673, 2674, 2675, 2676, 2677, 2678, 2679, 2680, 2681, 2682, 2683, 2684,
    2685, 2686, 2687, 2688, 2689, 2690, 2691, 2692, 2693, 2694, 2695, 2696, 2697,
    2698, 2699, 2700, 2701, 2702, 2703, 2704, 2705, 2706, 2707, 2708, 2709, 2710,
    2711, 2712, 2713, 2714, 2715, 2716, 2717, 2718, 2719, 2720, 2721, 2722, 2723,
    2724, 2725, 2726, 2727, 2728, 2729, 2730, 2731, 2732, 2733, 2734, 2735, 2736,
    2737, 2738, 2739, 2740, 2741, 2742, 2743, 2744, 2745, 2746, 2747, 2748, 2749,
    2750, 2751, 2752, 2753, 2754, 2755, 2756, 2757, 2758, 2759, 2760, 2761, 2762,
    2763, 2764, 2765, 2766, 2767, 2768, 2769, 2770, 2771, 2772, 2773, 2774, 2775,
    2776, 2777, 2778, 2779, 2780, 2781, 2782, 2783, 2784, 2785, 2786, 2787, 2788,
    2789, 2790, 2791, 2792, 2793, 2794, 2795, 2796, 2797, 2798, 2799, 2800, 2801,
    2802, 2803, 2804, 2805, 2806, 2807, 2808, 2809, 2810, 2811, 2812, 2813, 2814,
    2815, 2816, 2817, 2818, 2819, 2820, 2821, 2822, 2823, 2824, 2825, 2826, 2827,
    2828, 2829, 2830, 2831, 2832, 2833, 2834, 2835, 2836, 2837, 2838, 2839, 2840,
    2841, 2842, 2843, 2844, 2845, 2846, 2847, 2848, 2849, 2850, 2851, 2852, 2853,
    2854, 2855, 2856, 2857, 2858, 2859, 2860, 2861, 2862, 2863, 2864, 2865, 2866,
    2867, 2868, 2869, 2870, 2871, 2872, 2873, 2874, 2875, 2876, 2877, 2878, 2879,
    2880, 2881, 2882, 2883, 2884, 2885, 2886, 2887, 2888, 2889, 2890, 2891, 2892,
    2893, 2894, 2895, 2896, 2897, 2898, 2899, 2900, 2901, 2902, 2903, 2904, 2905,
    2906, 2907, 2908, 2909, 2910, 2911, 2912, 2913, 2914, 2915, 2916, 2917, 2918,
    2919, 2920, 2921, 2922, 2923, 2924, 2925, 2926, 2927, 2928, 2929, 2930, 2931,
    2932, 2933, 2934, 2935, 2936, 2937, 2938, 2939, 2940, 2941, 2942, 2943, 2944,
    2945, 2946, 2947, 2948, 2949, 2950, 2951, 2952, 2953, 2954, 2955, 2956, 2957,
    2958, 2959, 2960, 2961, 2962, 2963, 2964, 2965, 2966, 2967, 2968, 2969, 2970,
    2971, 2972, 2973, 2974, 2975, 2976, 2977, 2978, 2979, 2980, 2981, 2982, 2983,
    2984, 2985, 2986, 2987, 2988, 2989, 2990, 2991, 2992, 2993, 2994, 2995, 2996,
    2997, 2998, 2999, 3000, 3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009,
    3010, 3011, 3012, 3013, 3014, 3015, 3016, 3017, 3018, 3019, 3020, 3021, 3022,
    3023, 3024, 3025, 3026, 3027, 3028, 3029, 3030, 3031, 3032, 3033, 3034, 3035,
    3036, 3037, 3038, 3039, 3040, 3041, 3042, 3043, 3044, 3045, 3046, 3047, 3048,
    3049, 3050, 3051, 3052, 3053, 3054, 3055, 3056, 3057, 3058, 3059, 3060, 3061,
    3062, 3063, 3064, 3065, 3066, 3067, 3068, 3069, 3070, 3071, 3072, 3073, 3074,
    3075, 3076, 3077, 3078, 3079, 3080, 3081, 3082, 3083, 3084, 3085, 3086, 3087,
    3088, 3089, 3090, 3091, 3092, 3093, 3094, 3095, 3096, 3097, 3098, 3099, 3100,
    3101, 3102, 3103, 3104, 3105, 3106, 3107, 3108, 3109, 3110, 3111, 3112, 3113,
    3114, 3115, 3116, 3117, 3118, 3119, 3120, 3121, 3122, 3123, 3124, 3125, 3126,
    3127, 3128, 3129, 3130, 3131, 3132, 3133, 3134, 3135, 3136, 3137, 3138, 3139,
    3140, 3141, 3142, 3143, 3144, 3145, 3146, 3147, 3148, 3149, 3150, 3151, 3152,
    3153, 3154, 3155, 3156, 3157, 3158, 3159, 3160, 3161, 3162, 3163, 3164, 3165,
    3166, 3167, 3168, 3169, 3170, 3171, 3172, 3173, 3174, 3175, 3176, 3177, 3178,
    3179, 3180, 3181, 3182, 3183, 3184, 3185, 3186, 3187, 3188, 3189, 3190, 3191,
    3192, 3193, 3194, 3195, 3196, 3197, 3198, 3199, 3200, 3201, 3202, 3203, 3204,
    3205, 3206, 3207, 3208, 3209, 3210, 3211, 3212, 3213, 3214, 3215, 3216, 3217,
    3218, 3219, 3220, 3221, 3222, 3223, 3224, 3225, 3226, 3227, 3228, 3229, 3230,
    3231, 3232, 3233, 3234, 3235, 3236, 3237, 3238, 3239, 3240, 3241, 3242, 3243,
    3244, 3245, 3246, 3247, 3248, 3249, 3250, 3251, 3252, 3253, 3254, 3255, 3256,
    3257, 3258, 3259, 3260, 3261, 3262, 3263, 3264, 3265, 3266, 3267, 3268, 3269,
    3270, 3271, 3272, 3273, 3274, 3275, 3276, 3277, 3278, 3279, 3280, 3281, 3282,
    3283, 3284, 3285, 3286, 3287, 3288, 3289, 3290, 3291, 3292, 3293, 3294, 3295,
    3296, 3297, 3298, 3299, 3300, 3301, 3302, 3303, 3304, 3305, 3306, 3307, 3308,
    3309, 3310, 3311, 3312, 3313, 3314, 3315, 3316, 3317, 3318, 3319, 3320, 3321,
    3322, 3323, 3324, 3325, 3326, 3327, 3328, 3329, 3330, 3331, 3332, 3333, 3334,
    3335, 3336, 3337, 3338, 3339, 3340, 3341, 3342, 3343, 3344, 3345, 3346, 3347,
    3348, 3349, 3350, 3351, 3352, 3353, 3354, 3355, 3356, 3357, 3358, 3359, 3360,
    3361, 3362, 3363, 3364, 3365, 3366, 3367, 3368, 3369, 3370, 3371, 3372, 3373,
    3374, 3375, 3376, 3377, 3378, 3379, 3380, 3381, 3382, 3383, 3384, 3385, 3386,
    3387, 3388, 3389, 3390, 3391, 3392, 3393, 3394, 3395, 3396, 3397, 3398, 3399,
    3400, 3401, 3402, 3403, 3404, 3405, 3406, 3407, 3408, 3409, 3410, 3411, 3412,
    3413, 3414, 3415, 3416, 3417, 3418, 3419, 3420, 3421, 3422, 3423, 3424, 3425,
    3426, 3427, 3428, 3429, 3430, 3431, 3432, 3433, 3434, 3435, 3436, 3437, 3438,
    3439, 3440, 3441, 3442, 3443, 3444, 3445, 3446, 3447, 3448, 3449, 3450, 3451,
    3452, 3453, 3454, 3455, 3456, 3457, 3458, 3459, 3460, 3461, 3462, 3463, 3464,
    3465, 3466, 3467, 3468, 3469, 3470, 3471, 3472, 3473, 3474, 3475, 3476, 3477,
    3478, 3479, 3480, 3481, 3482, 3483, 3484, 3485, 3486, 3487, 3488, 3489, 3490,
    3491, 3492, 3493, 3494, 3495, 3496, 3497, 3498, 3499, 3500, 3501, 3502, 3503,
    3504, 3505, 3506, 3507, 3508, 3509, 3510, 3511, 3512, 3513, 3514, 3515, 3516,
    3517, 3518, 3519, 3520, 3521, 3522, 3523, 3524, 3525, 3526, 3527, 3528, 3529,
    3530, 3531, 3532, 3533, 3534, 3535, 3536, 3537, 3538, 3539, 3540, 3541, 3542,
    3543, 3544, 3545, 3546, 3547, 3548, 3549, 3550, 3551, 3552, 3553, 3554, 3555,
    3556, 3557, 3558, 3559, 3560, 3561, 3562, 3563, 3564, 3565, 3566, 3567, 3568,
    3569, 3570, 3571, 3572, 3573, 3574, 3575, 3576, 3577, 3578, 3579, 3580, 3581,
    3582, 3583, 3584, 3585, 3586, 3587, 3588, 3589, 3590, 3591, 3592, 3593, 3594,
    3595, 3596, 3597, 3598, 3599, 3600, 3601, 3602, 3603, 3604, 3605, 3606, 3607,
    3608, 3609, 3610, 3611, 3612, 3613, 3614, 3615, 3616, 3617, 3618, 3619, 3620,
    3621, 3622, 3623, 3624, 3625, 3626, 3627, 3628, 3629, 3630, 3631, 3632, 3633,
    3634, 3635, 3636, 3637, 3638, 3639, 3640, 3641, 3642, 3643, 3644, 3645, 3646,
    3647, 3648, 3649, 3650, 3651, 3652, 3653, 3654, 3655, 3656, 3657, 3658, 3659,
    3660, 3661, 3662, 3663, 3664, 3665, 3666, 3667, 3668, 3669, 3670, 3671, 3672,
    3673, 3674, 3675, 3676, 3677, 3678, 3679, 3680, 3681, 3682, 3683, 3684, 3685,
    3686, 3687, 3688, 3689, 3690, 3691, 3692, 3693, 3694, 3695, 3696, 3697, 3698,
    3699, 3700, 3701, 3702, 3703, 3704, 3705, 3706, 3707, 3708, 3709, 3710, 3711,
    3712, 3713, 3714, 3715, 3716, 3717, 3718, 3719, 3720, 3721, 3722, 3723, 3724,
    3725, 3726, 3727, 3728, 3729, 3730, 3731, 3732, 3733, 3734, 3735, 3736, 3737,
    3738, 3739, 3740, 3741, 3742, 3743, 3744, 3745, 3746, 3747, 3748, 3749, 3750,
    3751, 3752, 3753, 3754, 3755, 3756, 3757, 3758, 3759, 3760, 3761, 3762, 3763,
    3764, 3765, 3766, 3767, 3768, 3769, 3770, 3771, 3772, 3773, 3774, 3775, 3776,
    3777, 3778, 3779, 3780, 3781, 3782, 3783, 3784, 3785, 3786, 3787, 3788, 3789,
    3790, 3791, 3792, 3793, 3794, 3795, 3796, 3797, 3798, 3799, 3800, 3801, 3802,
    3803, 3804, 3805, 3806, 3807, 3808, 3809, 3810, 3811, 3812, 3813, 3814, 3815,
    3816, 3817, 3818, 3819, 3820, 3821, 3822, 3823, 3824, 3825, 3826, 3827, 3828,
    3829, 3830, 3831, 3832, 3833, 3834, 3835, 3836, 3837, 3838, 3839, 3840, 3841,
    3842, 3843, 3844, 3845, 3846, 3847, 3848, 3849, 3850, 3851, 3852, 3853, 3854,
    3855, 3856, 3857, 3858, 3859, 3860, 3861, 3862, 3863, 3864, 3865, 3866, 3867,
    3868, 3869, 3870, 3871, 3872, 3873, 3874, 3875, 3876, 3877, 3878, 3879, 3880,
    3881, 3882, 3883, 3884, 3885, 3886, 3887, 3888, 3889, 3890, 3891, 3892, 3893,
    3894, 3895, 3896, 3897, 3898, 3899, 3900, 3901, 3902, 3903, 3904, 3905, 3906,
    3907, 3908, 3909, 3910, 3911, 3912, 3913, 3914, 3915, 3916, 3917, 3918, 3919,
    3920, 3921, 3922, 3923, 3924, 3925, 3926, 3927, 3928, 3929, 3930, 3931, 3932,
    3933, 3934, 3935, 3936, 3937, 3938, 3939, 3940, 3941, 3942, 3943, 3944, 3945,
    3946, 3947, 3948, 3949, 3950, 3951, 3952, 3953, 3954, 3955, 3956, 3957, 3958,
    3959, 3960, 3961, 3962, 3963, 3964, 3965, 3966, 3967, 3968, 3969, 3970, 3971,
    3972, 3973, 3974, 3975, 3976, 3977, 3978, 3979, 3980, 3981, 3982, 3983, 3984,
    3985, 3986, 3987, 3988, 3989, 3990, 3991, 3992, 3993, 3994, 3995, 3996, 3997,
    3998, 3999, 4000, 4001, 4002, 4003, 4004, 4005, 4006, 4007, 4008, 4009, 4010,
    4011, 4012, 4013, 4014, 4015, 4016, 4017, 4018, 4019, 4020, 4021, 4022, 4023,
    4024, 4025, 4026, 4027, 4028, 4029, 4030, 4031, 4032, 4033, 4034, 4035, 4036,
    4037, 4038, 4039, 4040, 4041, 4042, 4043, 4044, 4045, 4046, 4047, 4048, 4049,
    4050, 4051, 4052, 4053, 4054, 4055, 4056, 4057, 4058, 4059, 4060, 4061, 4062,
    4063, 4064, 4065, 4066, 4067, 4068, 4069, 4070, 4071, 4072, 4073, 4074, 4075,
    4076, 4077, 4078, 4079, 4080, 4081, 4082, 4083, 4084, 4085, 4086, 4087, 4088,
    4089, 4090, 4091, 4092, 4093, 4094, 4095, 4096, 4097, 4098, 4099, 4100, 4101,
    4102, 4103, 4104, 4105, 4106, 4107, 4108, 4109, 4110, 4111, 4112, 4113, 4114,
    4115, 4116, 4117, 4118, 4119, 4120, 4121, 4122, 4123, 4124, 4125, 4126, 4127,
    4128, 4129, 4130, 4131, 4132, 4133, 4134, 4135, 4136, 4137, 4138, 4139, 4140,
    4141, 4142, 4143, 4144, 4145, 4146, 4147, 4148, 4149, 4150, 4151, 4152, 4153,
    4154, 4155, 4156, 4157, 4158, 4159, 4160, 4161, 4162, 4163, 4164, 4165, 4166,
    4167, 4168, 4169, 4170, 4171, 4172, 4173, 4174, 4175, 4176, 4177, 4178, 4179,
    4180, 4181, 4182, 4183, 4184, 4185, 4186, 4187, 4188, 4189, 4190, 4191, 4192,
    4193, 4194, 4195, 4196, 4197, 4198, 4199, 4200, 4201, 4202, 4203, 4204, 4205,
    4206, 4207, 4208, 4209, 4210, 4211, 4212, 4213, 4214, 4215, 4216, 4217, 4218,
    4219, 4220, 4221, 4222, 4223, 4224, 4225, 4226, 4227, 4228, 4229, 4230, 4231,
    4232, 4233, 4234, 4235, 4236, 4237, 4238, 4239, 4240, 4241, 4242, 4243, 4244,
    4245, 4246, 4247, 4248, 4249, 4250, 4251, 4252, 4253, 4254, 4255, 4256, 4257,
    4258, 4259, 4260, 4261, 4262, 4263, 4264, 4265, 4266, 4267, 4268, 4269, 4270,
    4271, 4272, 4273, 4274, 4275, 4276, 4277, 4278, 4279, 4280, 4281, 4282, 4283,
    4284, 4285, 4286, 4287, 4288, 4289, 4290, 4291, 4292, 4293, 4294, 4295, 4296,
    4297, 4298, 4299, 4300, 4301, 4302, 4303, 4304, 4305, 4306, 4307, 4308, 4309,
    4310, 4311, 4312, 4313, 4314, 4315, 4316, 4317, 4318, 4319, 4320, 4321, 4322,
    4323, 4324, 4325, 4326, 4327, 4328, 4329, 4330, 4331, 4332, 4333, 4334, 4335,
    4336, 4337, 4338, 4339, 4340, 4341, 4342, 4343, 4344, 4345, 4346, 4347, 4348,
    4349, 4350, 4351, 4352, 4353, 4354, 4355, 4356, 4357, 4358, 4359, 4360, 4361,
    4362, 4363, 4364, 4365, 4366, 4367, 4368, 4369, 4370, 4371, 4372, 4373, 4374,
    4375, 4376, 4377, 4378, 4379, 4380, 4381, 4382, 4383, 4384, 4385, 4386, 4387,
    4388, 4389, 4390, 4391, 4392, 4393, 4394, 4395, 4396, 4397, 4398, 4399, 4400,
    4401, 4402, 4403, 4404, 4405, 4406, 4407, 4408, 4409, 4410, 4411, 4412, 4413,
    4414, 4415, 4416, 4417, 4418, 4419, 4420, 4421, 4422, 4423, 4424, 4425, 4426,
    4427, 4428, 4429, 4430, 4431, 4432, 4433, 4434, 4435, 4436, 4437, 4438, 4439,
    4440, 4441, 4442, 4443, 4444, 4445, 4446, 4447, 4448, 4449, 4450, 4451, 4452,
    4453, 4454, 4455, 4456, 4457, 4458, 4459, 4460, 4461, 4462, 4463, 4464, 4465,
    4466, 4467, 4468, 4469, 4470, 4471, 4472, 4473, 4474, 4475, 4476, 4477, 4478,
    4479, 4480, 4481, 4482, 4483, 4484, 4485, 4486, 4487, 4488, 4489, 4490, 4491,
    4492, 4493, 4494, 4495, 4496, 4497, 4498, 4499, 4500, 4501, 4502, 4503, 4504,
    4505, 4506, 4507, 4508, 4509, 4510, 4511, 4512, 4513, 4514, 4515, 4516, 4517,
    4518, 4519, 4520, 4521, 4522, 4523, 4524, 4525, 4526, 4527, 4528, 4529, 4530,
    4531, 4532, 4533, 4534, 4535, 4536, 4537, 4538, 4539, 4540, 4541, 4542, 4543,
    4544, 4545, 4546, 4547, 4548, 4549, 4550, 4551, 4552, 4553, 4554, 4555, 4556,
    4557, 4558, 4559, 4560, 4561, 4562, 4563, 4564, 4565, 4566, 4567, 4568, 4569,
    4570, 4571, 4572, 4573, 4574, 4575, 4576, 4577, 4578, 4579, 4580, 4581, 4582,
    4583, 4584, 4585, 4586, 4587, 4588, 4589, 4590, 4591, 4592, 4593, 4594, 4595,
    4596, 4597, 4598, 4599, 4600, 4601, 4602, 4603, 4604, 4605, 4606, 4607, 4608,
    4609, 4610, 4611, 4612, 4613, 4614, 4615, 4616, 4617, 4618, 4619, 4620, 4621,
    4622, 4623, 4624, 4625, 4626, 4627, 4628, 4629, 4630, 4631, 4632, 4633, 4634,
    4635, 4636, 4637, 4638, 4639, 4640, 4641, 4642, 4643, 4644, 4645, 4646, 4647,
    4648, 4649, 4650, 4651, 4652, 4653, 4654, 4655, 4656, 4657, 4658, 4659, 4660,
    4661, 4662, 4663, 4664, 4665, 4666, 4667, 4668, 4669, 4670, 4671, 4672, 4673,
    4674, 4675, 4676, 4677, 4678, 4679, 4680, 4681, 4682, 4683, 4684, 4685, 4686,
    4687, 4688, 4689, 4690, 4691, 4692, 4693, 4694, 4695, 4696, 4697, 4698, 4699,
    4700, 4701, 4702, 4703, 4704, 4705, 4706, 4707, 4708, 4709, 4710, 4711, 4712,
    4713, 4714, 4715, 4716, 4717, 4718, 4719, 4720, 4721, 4722, 4723, 4724, 4725,
    4726, 4727, 4728, 4729, 4730, 4731, 4732, 4733, 4734, 4735, 4736, 4737, 4738,
    4739, 4740, 4741, 4742, 4743, 4744, 4745, 4746, 4747, 4748, 4749, 4750, 4751,
    4752, 4753, 4754, 4755, 4756, 4757, 4758, 4759, 4760, 4761, 4762, 4763, 4764,
    4765, 4766, 4767, 4768, 4769, 4770, 4771, 4772, 4773, 4774, 4775, 4776, 4777,
    4778, 4779, 4780, 4781, 4782, 4783, 4784, 4785, 4786, 4787, 4788, 4789, 4790,
    4791, 4792, 4793, 4794, 4795, 4796, 4797, 4798, 4799, 4800, 4801, 4802, 4803,
    4804, 4805, 4806, 4807, 4808, 4809, 4810, 4811, 4812, 4813, 4814, 4815, 4816,
    4817, 4818, 4819, 4820, 4821, 4822, 4823, 4824, 4825, 4826, 4827, 4828, 4829,
    4830, 4831, 4832, 4833, 4834, 4835, 4836, 4837, 4838, 4839, 4840, 4841, 4842,
    4843, 4844, 4845, 4846, 4847, 4848, 4849, 4850, 4851, 4852, 4853, 4854, 4855,
    4856, 4857, 4858, 4859, 4860, 4861, 4862, 4863, 4864, 4865, 4866, 4867, 4868,
    4869, 4870, 4871, 4872, 4873, 4874, 4875, 4876, 4877, 4878, 4879, 4880, 4881,
    4882, 4883, 4884, 4885, 4886, 4887, 4888, 4889, 4890, 4891, 4892, 4893, 4894,
    4895, 4896, 4897, 4898, 4899, 4900, 4901, 4902, 4903, 4904, 4905, 4906, 4907,
    4908, 4909, 4910, 4911, 4912, 4913, 4914, 4915, 4916, 4917, 4918, 4919, 4920,
    4921, 4922, 4923, 4924, 4925, 4926, 4927, 4928, 4929, 4930, 4931, 4932, 4933,
    4934, 4935, 4936, 4937, 4938, 4939, 4940, 4941, 4942, 4943, 4944, 4945, 4946,
    4947, 4948, 4949, 4950, 4951, 4952, 4953, 4954, 4955, 4956, 4957, 4958, 4959,
    4960, 4961, 4962, 4963, 4964, 4965, 4966, 4967, 4968, 4969, 4970, 4971, 4972,
    4973, 4974, 4975, 4976, 4977, 4978, 4979, 4980, 4981, 4982, 4983, 4984, 4985,
    4986, 4987, 4988, 4989, 4990, 4991, 4992, 4993, 4994, 4995, 4996, 4997, 4998,
    4999, 5000, 5001, 5002, 5003, 5004, 5005, 5006, 5007, 5008, 5009, 5010, 5011,
    5012, 5013, 5014, 5015, 5016, 5017, 5018, 5019, 5020, 5021, 5022, 5023, 5024,
    5025, 5026, 5027, 5028, 5029, 5030, 5031, 5032, 5033, 5034, 5035, 5036, 5037,
    5038, 5039, 5040, 5041, 5042, 5043, 5044, 5045, 5046, 5047, 5048, 5049, 5050,
    5051, 5052, 5053, 5054, 5055, 5056, 5057, 5058, 5059, 5060, 5061, 5062, 5063,
    5064, 5065, 5066, 5067, 5068, 5069, 5070, 5071, 5072, 5073, 5074, 5075, 5076,
    5077, 5078, 5079, 5080, 5081, 5082, 5083, 5084, 5085, 5086, 5087, 5088, 5089,
    5090, 5091, 5092, 5093, 5094, 5095, 5096, 5097, 5098, 5099, 5100, 5101, 5102,
    5103, 5104, 5105, 5106, 5107, 5108, 5109, 5110, 5111, 5112, 5113, 5114, 5115,
    5116, 5117, 5118, 5119, 5120, 5121, 5122, 5123, 5124, 5125, 5126, 5127, 5128,
    5129, 5130, 5131, 5132, 5133, 5134, 5135, 5136, 5137, 5138, 5139, 5140, 5141,
    5142, 5143, 5144, 5145, 5146, 5147, 5148, 5149, 5150, 5151, 5152, 5153, 5154,
    5155, 5156, 5157, 5158, 5159, 5160, 5161, 5162, 5163, 5164, 5165, 5166, 5167,
    5168, 5169, 5170, 5171, 5172, 5173, 5174, 5175, 5176, 5177, 5178, 5179, 5180,
    5181, 5182, 5183, 5184, 5185, 5186, 5187, 5188, 5189, 5190, 5191, 5192, 5193,
    5194, 5195, 5196, 5197, 5198, 5199, 5200, 5201, 5202, 5203, 5204, 5205, 5206,
    5207, 5208, 5209, 5210, 5211, 5212, 5213, 5214, 5215, 5216, 5217, 5218, 5219,
    5220, 5221, 5222, 5223, 5224, 5225, 5226, 5227, 5228, 5229, 5230, 5231, 5232,
    5233, 5234, 5235, 5236, 5237, 5238, 5239, 5240, 5241, 5242, 5243, 5244, 5245,
    5246, 5247, 5248, 5249, 5250, 5251, 5252, 5253, 5254, 5255, 5256, 5257, 5258,
    5259, 5260, 5261, 5262, 5263, 5264, 5265, 5266, 5267, 5268, 5269, 5270, 5271,
    5272, 5273, 5274, 5275, 5276, 5277, 5278, 5279, 5280, 5281, 5282, 5283, 5284,
    5285, 5286, 5287, 5288, 5289, 5290, 5291, 5292, 5293, 5294, 5295, 5296, 5297,
    5298, 5299, 5300, 5301, 5302, 5303, 5304, 5305, 5306, 5307, 5308, 5309, 5310,
    5311, 5312, 5313, 5314, 5315, 5316, 5317, 5318, 5319, 5320, 5321, 5322, 5323,
    5324, 5325, 5326, 5327, 5328, 5329, 5330, 5331, 5332, 5333, 5334, 5335, 5336,
    5337, 5338, 5339, 5340, 5341, 5342, 5343, 5344, 5345, 5346, 5347, 5348, 5349,
    5350, 5351, 5352, 5353, 5354, 5355, 5356, 5357, 5358, 5359, 5360, 5361, 5362,
    5363, 5364, 5365, 5366, 5367, 5368, 5369, 5370, 5371, 5372, 5373, 5374, 5375,
    5376, 5377, 5378, 5379, 5380, 5381, 5382, 5383, 5384, 5385, 5386, 5387, 5388,
    5389, 5390, 5391, 5392, 5393, 5394, 5395, 5396, 5397, 5398, 5399, 5400, 5401,
    5402, 5403, 5404, 5405, 5406, 5407, 5408, 5409, 5410, 5411, 5412, 5413, 5414,
    5415, 5416, 5417, 5418, 5419, 5420, 5421, 5422, 5423, 5424, 5425, 5426, 5427,
    5428, 5429, 5430, 5431, 5432, 5433, 5434, 5435, 5436, 5437, 5438, 5439, 5440,
    5441, 5442, 5443, 5444, 5445, 5446, 5447, 5448, 5449, 5450, 5451, 5452, 5453,
    5454, 5455, 5456, 5457, 5458, 5459, 5460, 5461, 5462, 5463, 5464, 5465, 5466,
    5467, 5468, 5469, 5470, 5471, 5472, 5473, 5474, 5475, 5476, 5477, 5478, 5479,
    5480, 5481, 5482, 5483, 5484, 5485, 5486, 5487, 5488, 5489, 5490, 5491, 5492,
    5493, 5494, 5495, 5496, 5497, 5498, 5499, 5500, 5501, 5502, 5503, 5504, 5505,
    5506, 5507, 5508, 5509, 5510, 5511, 5512, 5513, 5514, 5515, 5516, 5517, 5518,
    5519, 5520, 5521, 5522, 5523, 5524, 5525, 5526, 5527, 5528, 5529, 5530, 5531,
    5532, 5533, 5534, 5535, 5536, 5537, 5538, 5539, 5540, 5541, 5542, 5543, 5544,
    5545, 5546, 5547, 5548, 5549, 5550, 5551, 5552, 5553, 5554, 5555, 5556, 5557,
    5558, 5559, 5560, 5561, 5562, 5563, 5564, 5565, 5566, 5567, 5568, 5569, 5570,
    5571, 5572, 5573, 5574, 5575, 5576, 5577, 5578, 5579, 5580, 5581, 5582, 5583,
    5584, 5585, 5586, 5587, 5588, 5589, 5590, 5591, 5592, 5593, 5594, 5595, 5596,
    5597, 5598, 5599, 5600, 5601, 5602, 5603, 5604, 5605, 5606, 5607, 5608, 5609,
    5610, 5611, 5612, 5613, 5614, 5615, 5616, 5617, 5618, 5619, 5620, 5621, 5622,
    5623, 5624, 5625, 5626, 5627, 5628, 5629, 5630, 5631, 5632, 5633, 5634, 5635,
    5636, 5637, 5638, 5639, 5640, 5641, 5642, 5643, 5644, 5645, 5646, 5647, 5648,
    5649, 5650, 5651, 5652, 5653, 5654, 5655, 5656, 5657, 5658, 5659, 5660, 5661,
    5662, 5663, 5664, 5665, 5666, 5667, 5668, 5669, 5670, 5671, 5672, 5673, 5674,
    5675, 5676, 5677, 5678, 5679, 5680, 5681, 5682, 5683, 5684, 5685, 5686, 5687,
    5688, 5689, 5690, 5691, 5692, 5693, 5694, 5695, 5696, 5697, 5698, 5699, 5700,
    5701, 5702, 5703, 5704, 5705, 5706, 5707, 5708, 5709, 5710, 5711, 5712, 5713,
    5714, 5715, 5716, 5717, 5718, 5719, 5720, 5721, 5722, 5723, 5724, 5725, 5726,
    5727, 5728, 5729, 5730, 5731, 5732, 5733, 5734, 5735, 5736, 5737, 5738, 5739,
    5740, 5741, 5742, 5743, 5744, 5745, 5746, 5747, 5748, 5749, 5750, 5751, 5752,
    5753, 5754, 5755, 5756, 5757, 5758, 5759, 5760, 5761, 5762, 5763, 5764, 5765,
    5766, 5767, 5768, 5769, 5770, 5771, 5772, 5773, 5774, 5775, 5776, 5777, 5778,
    5779, 5780, 5781, 5782, 5783, 5784, 5785, 5786, 5787, 5788, 5789, 5790, 5791,
    5792, 5793, 5794, 5795, 5796, 5797, 5798, 5799, 5800, 5801, 5802, 5803, 5804,
    5805, 5806, 5807, 5808, 5809, 5810, 5811, 5812, 5813, 5814, 5815, 5816, 5817,
    5818, 5819, 5820, 5821, 5822, 5823, 5824, 5825, 5826, 5827, 5828, 5829, 5830,
    5831, 5832, 5833, 5834, 5835, 5836, 5837, 5838, 5839, 5840, 5841, 5842, 5843,
    5844, 5845, 5846, 5847, 5848, 5849, 5850, 5851, 5852, 5853, 5854, 5855, 5856,
    5857, 5858, 5859, 5860, 5861, 5862, 5863, 5864, 5865, 5866, 5867, 5868, 5869,
    5870, 5871, 5872, 5873, 5874, 5875, 5876, 5877, 5878, 5879, 5880, 5881, 5882,
    5883, 5884, 5885, 5886, 5887, 5888, 5889, 5890, 5891, 5892, 5893, 5894, 5895,
    5896, 5897, 5898, 5899, 5900, 5901, 5902, 5903, 5904, 5905, 5906, 5907, 5908,
    5909, 5910, 5911, 5912, 5913, 5914, 5915, 5916, 5917, 5918, 5919, 5920, 5921,
    5922, 5923, 5924, 5925, 5926, 5927, 5928, 5929, 5930, 5931, 5932, 5933, 5934,
    5935, 5936, 5937, 5938, 5939, 5940, 5941, 5942, 5943, 5944, 5945, 5946, 5947,
    5948, 5949, 5950, 5951, 5952, 5953, 5954, 5955, 5956, 5957, 5958, 5959, 5960,
    5961, 5962, 5963, 5964, 5965, 5966, 5967, 5968, 5969, 5970, 5971, 5972, 5973,
    5974, 5975, 5976, 5977, 5978, 5979, 5980, 5981, 5982, 5983, 5984, 5985, 5986,
    5987, 5988, 5989, 5990, 5991, 5992, 5993, 5994, 5995, 5996, 5997, 5998, 5999,
    6000)
sx_vf <- unname(sx_vfold[rownames(sx_val_full)])
sx_vr <- sx_val_split("holdout", sx_vf)
sx_result <- list(folds = sx_vr$folds, predictions = sx_vr$predictions, trace = sx_vr$trace)
if (!is.null(sx_vfold)) sx_rep_man[[length(sx_rep_man) + 1]] <- data.frame(split = sx_vr$folds$split[1],
  row_id = as.integer(names(sx_vfold)), fold = unname(sx_vfold), stringsAsFactors = FALSE)
if (!is.null(sx_vdraws)) sx_rep_draws[[length(sx_rep_draws) + 1]] <- data.frame(b = sx_vdraws$b,
  position = stats::ave(seq_along(sx_vdraws$b), sx_vdraws$b, FUN = seq_along), row_id = sx_vdraws$row_id,
  draw_participant = sx_vdraws$draw_gid, draw_cluster = sx_vdraws$draw_cluster, stringsAsFactors = FALSE)
if (!is.null(sx_result$predictions)) sx_rep_pred[[length(sx_rep_pred) + 1]] <- sx_result$predictions
if (!is.null(sx_result$folds)) sx_rep_folds[[length(sx_rep_folds) + 1]] <- sx_result$folds
if (!is.null(sx_result$trace)) sx_rep_trace[[length(sx_rep_trace) + 1]] <- sx_result$trace
if (!is.null(sx_result$boot)) { sx_rep_boot[[length(sx_rep_boot) + 1]] <- sx_result$boot$draws
  if (!is.null(sx_result$boot$trace)) sx_rep_trace[[length(sx_rep_trace) + 1]] <- sx_result$boot$trace
  if (!is.null(sx_result$boot$coefs)) sx_rep_coef[[length(sx_rep_coef) + 1]] <- sx_result$boot$coefs }
sx_bind <- function(x) if (length(x)) do.call(rbind, x) else NULL
sx_P <- sx_bind(sx_rep_pred); sx_F <- sx_bind(sx_rep_folds); sx_B <- sx_bind(sx_rep_boot)
sx_C <- sx_bind(sx_rep_coef); sx_T <- sx_bind(sx_rep_trace); sx_M <- sx_bind(sx_rep_man); sx_D <- sx_bind(sx_rep_draws)
if (!is.null(sx_P)) utils::write.csv(sx_P, "reproduced_predictions.csv", row.names = FALSE)
if (!is.null(sx_F)) utils::write.csv(sx_F, "reproduced_folds.csv", row.names = FALSE)
if (!is.null(sx_B)) utils::write.csv(sx_B, "reproduced_bootstrap.csv", row.names = FALSE)
if (!is.null(sx_C)) utils::write.csv(sx_C, "reproduced_coefficients.csv", row.names = FALSE)
if (!is.null(sx_T)) utils::write.csv(sx_T, "reproduced_trace.csv", row.names = FALSE)
# ---- declarations embedded by StatExplore (independent of the exported files under test) ----
sx_schema <- list(
  manifest = list(keys = c("split", "row_id"), status_ok = NULL, cols = data.frame(name = c("split",
      "mode", "repeat", "row_id", "participant", "cluster", "fold"), type = c("text",
      "text", "int", "int", "text", "text", "int"), flags = c("", "", "", "", "",
      "", ""), stringsAsFactors = FALSE)),
  draws = list(keys = c("b", "position"), status_ok = NULL, cols = data.frame(name = c("b",
      "position", "row_id", "draw_participant", "draw_cluster", "original_participant",
      "original_cluster"), type = c("int", "int", "int", "text", "text", "text",
      "text"), flags = c("", "", "", "", "", "", ""), stringsAsFactors = FALSE)),
  predictions = list(keys = c("split", "fold", "row_id"), status_ok = NULL,
      cols = data.frame(name = c("split", "fold", "row_id", "observed", "predicted",
      "participant", "cluster"), type = c("text", "int", "int", "num", "num", "text",
      "text"), flags = c("", "", "", "tol=tol", "tol=tol", "", ""), stringsAsFactors = FALSE)),
  folds = list(keys = c("split", "fold"), status_ok = "scored", cols = data.frame(name = c("split",
      "fold", "status", "reason", "selected", "selected_index", "selected_key", "train_score",
      "visited", "scored", "n_sig_train", "n_train", "n_test", "train_mean", "train_groups",
      "test_groups", "train_clusters", "test_clusters", "excluded_incomplete", "excluded_unseen_levels",
      "excluded_unpredicted", "test_events", "diagnostics", "mode", "repeat"), type = c("text",
      "int", "text", "text", "text", "int", "text", "num", "int", "int", "int", "int",
      "int", "num", "int", "int", "int", "int", "int", "int", "int", "int", "text",
      "text", "int"), flags = c("", "", "", "", "", "na need=scored", "", "na inf tol=fit",
      "na", "na", "na", "", "", "na need=scored tol=tol", "na", "na", "na", "na",
      "na", "na", "na", "na", "", "", ""), stringsAsFactors = FALSE)),
  performance = list(keys = c("split", "fold", "weighting"), status_ok = NULL,
      cols = data.frame(name = c("split", "fold", "weighting", "n"), type = c("text",
      "int", "text", "int"), flags = c("", "", "", ""), stringsAsFactors = FALSE)),
  bootstrap = list(keys = c("b"), status_ok = "fitted", cols = data.frame(name = c("b",
      "status", "reason", "selected", "selected_index", "selected_key", "train_score",
      "visited", "scored", "n_sig_train", "coefficient", "estimate", "n_coef", "diagnostics",
      "flags", "n", "groups", "coefficient_label"), type = c("int", "text", "text",
      "text", "int", "text", "num", "int", "int", "int", "text", "num", "int", "text",
      "text", "int", "int", "text"), flags = c("", "", "", "", "na need=fitted",
      "", "na inf tol=fit", "na", "na", "na", "", "na tol=fit", "", "", "", "na need=fitted",
      "na need=fitted", ""), stringsAsFactors = FALSE)),
  coefs = list(keys = c("b", "selected_index", "coefficient"), status_ok = NULL,
      cols = data.frame(name = c("b", "selected_index", "selected_key", "term", "coefficient",
      "estimate"), type = c("int", "int", "text", "text", "text", "num"), flags = c("",
      "", "", "", "", "tol=fit"), stringsAsFactors = FALSE)),
  stability = list(keys = c("candidate_index"), status_ok = NULL, cols = data.frame(name = c("candidate_index",
      "candidate_key", "candidate", "selected", "attempted", "successful", "freq_of_attempted",
      "freq_of_successful", "flagged_fits", "coefficient", "positive_sign", "estimate_p2.5",
      "estimate_median", "estimate_p97.5"), type = c("int", "text", "text", "int",
      "int", "int", "num", "num", "int", "text", "num", "num", "num", "num"), flags = c("",
      "", "", "", "", "", "na tol=tight", "na tol=tight", "", "", "na tol=tight",
      "na tol=fit", "na tol=fit", "na tol=fit"), stringsAsFactors = FALSE)),
  estimands = list(keys = c("candidate_index", "coefficient"), status_ok = NULL,
      cols = data.frame(name = c("candidate_index", "candidate", "term", "coefficient",
      "coefficient_label", "draws_selected", "draws_with_estimate", "positive_sign",
      "estimate_p2.5", "estimate_median", "estimate_p97.5"), type = c("int", "text",
      "text", "text", "text", "int", "int", "num", "num", "num", "num"), flags = c("",
      "", "", "", "", "", "", "na tol=tight", "na tol=fit", "na tol=fit", "na tol=fit"),
      stringsAsFactors = FALSE)),
  trace = list(keys = c("part", "candidate_index"), status_ok = NULL, cols = data.frame(name = c("part",
      "candidate_index", "status", "reason", "loglik", "statistic", "df", "log_p",
      "reference_loglik", "aic", "score", "flags", "reference_flags", "rows_sig"),
      type = c("text", "int", "text", "text", "num", "num", "num", "num", "num",
      "num", "num", "text", "text", "text"), flags = c("", "", "", "", "na tol=fit",
      "na inf tol=fit", "na tol=fit", "na inf tol=fit", "na tol=fit", "na tol=fit",
      "na inf tol=fit", "", "", ""), stringsAsFactors = FALSE)),
  realized = list(keys = c("split", "fold"), status_ok = NULL, cols = data.frame(name = c("split",
      "mode", "fold", "requested_fraction", "test_units", "units", "realized_unit_fraction",
      "test_rows", "rows", "realized_row_fraction", "rule"), type = c("text", "text",
      "int", "num", "int", "int", "num", "int", "int", "num", "text"), flags = c("",
      "", "", "tol=tight", "", "", "na tol=tight", "", "", "na tol=tight", ""), stringsAsFactors = FALSE)),
  ledger = list(keys = c("part"), status_ok = NULL, cols = data.frame(name = c("part",
      "mode", "split", "fold", "b", "chunk", "status", "committed"), type = c("text",
      "text", "text", "int", "int", "int", "text", "bool"), flags = c("", "", "",
      "na", "na", "", "", ""), stringsAsFactors = FALSE)))
sx_expect <- data.frame(file = c("split_manifest.csv", "bootstrap_draws.csv",
    "predictions.csv", "folds.csv", "performance.csv", "stability.csv", "bootstrap_results.csv",
    "bootstrap_estimands.csv", "bootstrap_coefficients.csv", "candidate_trace.csv",
    "realized_sizes.csv", "execution_ledger.csv"), required = c(TRUE, FALSE, TRUE,
    TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, TRUE, TRUE, TRUE), rows = c(12000, 0,
    1200, 1, 2, 0, 0, 0, 0, 3, 3, 3), applicable = c(TRUE, FALSE, TRUE, TRUE, TRUE,
    FALSE, FALSE, FALSE, FALSE, TRUE, TRUE, TRUE), stringsAsFactors = FALSE)
sx_ledger <- data.frame(`part` = c("holdout:fold1", "cv1:fold1", "cv1:fold2"),
    `mode` = c("holdout", "cv", "cv"), `split` = c("holdout", "cv1", "cv1"), `fold` = c(1,
    1, 2), `b` = c(NA, NA, NA), `chunk` = c(1, 2, 2), `status` = c("scored", "not_run",
    "not_run"), `committed` = c(TRUE, FALSE, FALSE), stringsAsFactors = FALSE, check.names = FALSE)
sx_pend_M <- data.frame(`split` = c("cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1",
    "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1", "cv1"), `row_id` = c(1,
    2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23,
    24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43,
    44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63,
    64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83,
    84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102,
    103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118,
    119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134,
    135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150,
    151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166,
    167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182,
    183, 184, 185, 186, 187, 188, 189, 190, 191, 192, 193, 194, 195, 196, 197, 198,
    199, 200, 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214,
    215, 216, 217, 218, 219, 220, 221, 222, 223, 224, 225, 226, 227, 228, 229, 230,
    231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 242, 243, 244, 245, 246,
    247, 248, 249, 250, 251, 252, 253, 254, 255, 256, 257, 258, 259, 260, 261, 262,
    263, 264, 265, 266, 267, 268, 269, 270, 271, 272, 273, 274, 275, 276, 277, 278,
    279, 280, 281, 282, 283, 284, 285, 286, 287, 288, 289, 290, 291, 292, 293, 294,
    295, 296, 297, 298, 299, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310,
    311, 312, 313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326,
    327, 328, 329, 330, 331, 332, 333, 334, 335, 336, 337, 338, 339, 340, 341, 342,
    343, 344, 345, 346, 347, 348, 349, 350, 351, 352, 353, 354, 355, 356, 357, 358,
    359, 360, 361, 362, 363, 364, 365, 366, 367, 368, 369, 370, 371, 372, 373, 374,
    375, 376, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386, 387, 388, 389, 390,
    391, 392, 393, 394, 395, 396, 397, 398, 399, 400, 401, 402, 403, 404, 405, 406,
    407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420, 421, 422,
    423, 424, 425, 426, 427, 428, 429, 430, 431, 432, 433, 434, 435, 436, 437, 438,
    439, 440, 441, 442, 443, 444, 445, 446, 447, 448, 449, 450, 451, 452, 453, 454,
    455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 467, 468, 469, 470,
    471, 472, 473, 474, 475, 476, 477, 478, 479, 480, 481, 482, 483, 484, 485, 486,
    487, 488, 489, 490, 491, 492, 493, 494, 495, 496, 497, 498, 499, 500, 501, 502,
    503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518,
    519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534,
    535, 536, 537, 538, 539, 540, 541, 542, 543, 544, 545, 546, 547, 548, 549, 550,
    551, 552, 553, 554, 555, 556, 557, 558, 559, 560, 561, 562, 563, 564, 565, 566,
    567, 568, 569, 570, 571, 572, 573, 574, 575, 576, 577, 578, 579, 580, 581, 582,
    583, 584, 585, 586, 587, 588, 589, 590, 591, 592, 593, 594, 595, 596, 597, 598,
    599, 600, 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614,
    615, 616, 617, 618, 619, 620, 621, 622, 623, 624, 625, 626, 627, 628, 629, 630,
    631, 632, 633, 634, 635, 636, 637, 638, 639, 640, 641, 642, 643, 644, 645, 646,
    647, 648, 649, 650, 651, 652, 653, 654, 655, 656, 657, 658, 659, 660, 661, 662,
    663, 664, 665, 666, 667, 668, 669, 670, 671, 672, 673, 674, 675, 676, 677, 678,
    679, 680, 681, 682, 683, 684, 685, 686, 687, 688, 689, 690, 691, 692, 693, 694,
    695, 696, 697, 698, 699, 700, 701, 702, 703, 704, 705, 706, 707, 708, 709, 710,
    711, 712, 713, 714, 715, 716, 717, 718, 719, 720, 721, 722, 723, 724, 725, 726,
    727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742,
    743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758,
    759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774,
    775, 776, 777, 778, 779, 780, 781, 782, 783, 784, 785, 786, 787, 788, 789, 790,
    791, 792, 793, 794, 795, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 806,
    807, 808, 809, 810, 811, 812, 813, 814, 815, 816, 817, 818, 819, 820, 821, 822,
    823, 824, 825, 826, 827, 828, 829, 830, 831, 832, 833, 834, 835, 836, 837, 838,
    839, 840, 841, 842, 843, 844, 845, 846, 847, 848, 849, 850, 851, 852, 853, 854,
    855, 856, 857, 858, 859, 860, 861, 862, 863, 864, 865, 866, 867, 868, 869, 870,
    871, 872, 873, 874, 875, 876, 877, 878, 879, 880, 881, 882, 883, 884, 885, 886,
    887, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 899, 900, 901, 902,
    903, 904, 905, 906, 907, 908, 909, 910, 911, 912, 913, 914, 915, 916, 917, 918,
    919, 920, 921, 922, 923, 924, 925, 926, 927, 928, 929, 930, 931, 932, 933, 934,
    935, 936, 937, 938, 939, 940, 941, 942, 943, 944, 945, 946, 947, 948, 949, 950,
    951, 952, 953, 954, 955, 956, 957, 958, 959, 960, 961, 962, 963, 964, 965, 966,
    967, 968, 969, 970, 971, 972, 973, 974, 975, 976, 977, 978, 979, 980, 981, 982,
    983, 984, 985, 986, 987, 988, 989, 990, 991, 992, 993, 994, 995, 996, 997, 998,
    999, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011,
    1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020, 1021, 1022, 1023, 1024,
    1025, 1026, 1027, 1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1036, 1037,
    1038, 1039, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050,
    1051, 1052, 1053, 1054, 1055, 1056, 1057, 1058, 1059, 1060, 1061, 1062, 1063,
    1064, 1065, 1066, 1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076,
    1077, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 1085, 1086, 1087, 1088, 1089,
    1090, 1091, 1092, 1093, 1094, 1095, 1096, 1097, 1098, 1099, 1100, 1101, 1102,
    1103, 1104, 1105, 1106, 1107, 1108, 1109, 1110, 1111, 1112, 1113, 1114, 1115,
    1116, 1117, 1118, 1119, 1120, 1121, 1122, 1123, 1124, 1125, 1126, 1127, 1128,
    1129, 1130, 1131, 1132, 1133, 1134, 1135, 1136, 1137, 1138, 1139, 1140, 1141,
    1142, 1143, 1144, 1145, 1146, 1147, 1148, 1149, 1150, 1151, 1152, 1153, 1154,
    1155, 1156, 1157, 1158, 1159, 1160, 1161, 1162, 1163, 1164, 1165, 1166, 1167,
    1168, 1169, 1170, 1171, 1172, 1173, 1174, 1175, 1176, 1177, 1178, 1179, 1180,
    1181, 1182, 1183, 1184, 1185, 1186, 1187, 1188, 1189, 1190, 1191, 1192, 1193,
    1194, 1195, 1196, 1197, 1198, 1199, 1200, 1201, 1202, 1203, 1204, 1205, 1206,
    1207, 1208, 1209, 1210, 1211, 1212, 1213, 1214, 1215, 1216, 1217, 1218, 1219,
    1220, 1221, 1222, 1223, 1224, 1225, 1226, 1227, 1228, 1229, 1230, 1231, 1232,
    1233, 1234, 1235, 1236, 1237, 1238, 1239, 1240, 1241, 1242, 1243, 1244, 1245,
    1246, 1247, 1248, 1249, 1250, 1251, 1252, 1253, 1254, 1255, 1256, 1257, 1258,
    1259, 1260, 1261, 1262, 1263, 1264, 1265, 1266, 1267, 1268, 1269, 1270, 1271,
    1272, 1273, 1274, 1275, 1276, 1277, 1278, 1279, 1280, 1281, 1282, 1283, 1284,
    1285, 1286, 1287, 1288, 1289, 1290, 1291, 1292, 1293, 1294, 1295, 1296, 1297,
    1298, 1299, 1300, 1301, 1302, 1303, 1304, 1305, 1306, 1307, 1308, 1309, 1310,
    1311, 1312, 1313, 1314, 1315, 1316, 1317, 1318, 1319, 1320, 1321, 1322, 1323,
    1324, 1325, 1326, 1327, 1328, 1329, 1330, 1331, 1332, 1333, 1334, 1335, 1336,
    1337, 1338, 1339, 1340, 1341, 1342, 1343, 1344, 1345, 1346, 1347, 1348, 1349,
    1350, 1351, 1352, 1353, 1354, 1355, 1356, 1357, 1358, 1359, 1360, 1361, 1362,
    1363, 1364, 1365, 1366, 1367, 1368, 1369, 1370, 1371, 1372, 1373, 1374, 1375,
    1376, 1377, 1378, 1379, 1380, 1381, 1382, 1383, 1384, 1385, 1386, 1387, 1388,
    1389, 1390, 1391, 1392, 1393, 1394, 1395, 1396, 1397, 1398, 1399, 1400, 1401,
    1402, 1403, 1404, 1405, 1406, 1407, 1408, 1409, 1410, 1411, 1412, 1413, 1414,
    1415, 1416, 1417, 1418, 1419, 1420, 1421, 1422, 1423, 1424, 1425, 1426, 1427,
    1428, 1429, 1430, 1431, 1432, 1433, 1434, 1435, 1436, 1437, 1438, 1439, 1440,
    1441, 1442, 1443, 1444, 1445, 1446, 1447, 1448, 1449, 1450, 1451, 1452, 1453,
    1454, 1455, 1456, 1457, 1458, 1459, 1460, 1461, 1462, 1463, 1464, 1465, 1466,
    1467, 1468, 1469, 1470, 1471, 1472, 1473, 1474, 1475, 1476, 1477, 1478, 1479,
    1480, 1481, 1482, 1483, 1484, 1485, 1486, 1487, 1488, 1489, 1490, 1491, 1492,
    1493, 1494, 1495, 1496, 1497, 1498, 1499, 1500, 1501, 1502, 1503, 1504, 1505,
    1506, 1507, 1508, 1509, 1510, 1511, 1512, 1513, 1514, 1515, 1516, 1517, 1518,
    1519, 1520, 1521, 1522, 1523, 1524, 1525, 1526, 1527, 1528, 1529, 1530, 1531,
    1532, 1533, 1534, 1535, 1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544,
    1545, 1546, 1547, 1548, 1549, 1550, 1551, 1552, 1553, 1554, 1555, 1556, 1557,
    1558, 1559, 1560, 1561, 1562, 1563, 1564, 1565, 1566, 1567, 1568, 1569, 1570,
    1571, 1572, 1573, 1574, 1575, 1576, 1577, 1578, 1579, 1580, 1581, 1582, 1583,
    1584, 1585, 1586, 1587, 1588, 1589, 1590, 1591, 1592, 1593, 1594, 1595, 1596,
    1597, 1598, 1599, 1600, 1601, 1602, 1603, 1604, 1605, 1606, 1607, 1608, 1609,
    1610, 1611, 1612, 1613, 1614, 1615, 1616, 1617, 1618, 1619, 1620, 1621, 1622,
    1623, 1624, 1625, 1626, 1627, 1628, 1629, 1630, 1631, 1632, 1633, 1634, 1635,
    1636, 1637, 1638, 1639, 1640, 1641, 1642, 1643, 1644, 1645, 1646, 1647, 1648,
    1649, 1650, 1651, 1652, 1653, 1654, 1655, 1656, 1657, 1658, 1659, 1660, 1661,
    1662, 1663, 1664, 1665, 1666, 1667, 1668, 1669, 1670, 1671, 1672, 1673, 1674,
    1675, 1676, 1677, 1678, 1679, 1680, 1681, 1682, 1683, 1684, 1685, 1686, 1687,
    1688, 1689, 1690, 1691, 1692, 1693, 1694, 1695, 1696, 1697, 1698, 1699, 1700,
    1701, 1702, 1703, 1704, 1705, 1706, 1707, 1708, 1709, 1710, 1711, 1712, 1713,
    1714, 1715, 1716, 1717, 1718, 1719, 1720, 1721, 1722, 1723, 1724, 1725, 1726,
    1727, 1728, 1729, 1730, 1731, 1732, 1733, 1734, 1735, 1736, 1737, 1738, 1739,
    1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748, 1749, 1750, 1751, 1752,
    1753, 1754, 1755, 1756, 1757, 1758, 1759, 1760, 1761, 1762, 1763, 1764, 1765,
    1766, 1767, 1768, 1769, 1770, 1771, 1772, 1773, 1774, 1775, 1776, 1777, 1778,
    1779, 1780, 1781, 1782, 1783, 1784, 1785, 1786, 1787, 1788, 1789, 1790, 1791,
    1792, 1793, 1794, 1795, 1796, 1797, 1798, 1799, 1800, 1801, 1802, 1803, 1804,
    1805, 1806, 1807, 1808, 1809, 1810, 1811, 1812, 1813, 1814, 1815, 1816, 1817,
    1818, 1819, 1820, 1821, 1822, 1823, 1824, 1825, 1826, 1827, 1828, 1829, 1830,
    1831, 1832, 1833, 1834, 1835, 1836, 1837, 1838, 1839, 1840, 1841, 1842, 1843,
    1844, 1845, 1846, 1847, 1848, 1849, 1850, 1851, 1852, 1853, 1854, 1855, 1856,
    1857, 1858, 1859, 1860, 1861, 1862, 1863, 1864, 1865, 1866, 1867, 1868, 1869,
    1870, 1871, 1872, 1873, 1874, 1875, 1876, 1877, 1878, 1879, 1880, 1881, 1882,
    1883, 1884, 1885, 1886, 1887, 1888, 1889, 1890, 1891, 1892, 1893, 1894, 1895,
    1896, 1897, 1898, 1899, 1900, 1901, 1902, 1903, 1904, 1905, 1906, 1907, 1908,
    1909, 1910, 1911, 1912, 1913, 1914, 1915, 1916, 1917, 1918, 1919, 1920, 1921,
    1922, 1923, 1924, 1925, 1926, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1934,
    1935, 1936, 1937, 1938, 1939, 1940, 1941, 1942, 1943, 1944, 1945, 1946, 1947,
    1948, 1949, 1950, 1951, 1952, 1953, 1954, 1955, 1956, 1957, 1958, 1959, 1960,
    1961, 1962, 1963, 1964, 1965, 1966, 1967, 1968, 1969, 1970, 1971, 1972, 1973,
    1974, 1975, 1976, 1977, 1978, 1979, 1980, 1981, 1982, 1983, 1984, 1985, 1986,
    1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999,
    2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012,
    2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025,
    2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035, 2036, 2037, 2038,
    2039, 2040, 2041, 2042, 2043, 2044, 2045, 2046, 2047, 2048, 2049, 2050, 2051,
    2052, 2053, 2054, 2055, 2056, 2057, 2058, 2059, 2060, 2061, 2062, 2063, 2064,
    2065, 2066, 2067, 2068, 2069, 2070, 2071, 2072, 2073, 2074, 2075, 2076, 2077,
    2078, 2079, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090,
    2091, 2092, 2093, 2094, 2095, 2096, 2097, 2098, 2099, 2100, 2101, 2102, 2103,
    2104, 2105, 2106, 2107, 2108, 2109, 2110, 2111, 2112, 2113, 2114, 2115, 2116,
    2117, 2118, 2119, 2120, 2121, 2122, 2123, 2124, 2125, 2126, 2127, 2128, 2129,
    2130, 2131, 2132, 2133, 2134, 2135, 2136, 2137, 2138, 2139, 2140, 2141, 2142,
    2143, 2144, 2145, 2146, 2147, 2148, 2149, 2150, 2151, 2152, 2153, 2154, 2155,
    2156, 2157, 2158, 2159, 2160, 2161, 2162, 2163, 2164, 2165, 2166, 2167, 2168,
    2169, 2170, 2171, 2172, 2173, 2174, 2175, 2176, 2177, 2178, 2179, 2180, 2181,
    2182, 2183, 2184, 2185, 2186, 2187, 2188, 2189, 2190, 2191, 2192, 2193, 2194,
    2195, 2196, 2197, 2198, 2199, 2200, 2201, 2202, 2203, 2204, 2205, 2206, 2207,
    2208, 2209, 2210, 2211, 2212, 2213, 2214, 2215, 2216, 2217, 2218, 2219, 2220,
    2221, 2222, 2223, 2224, 2225, 2226, 2227, 2228, 2229, 2230, 2231, 2232, 2233,
    2234, 2235, 2236, 2237, 2238, 2239, 2240, 2241, 2242, 2243, 2244, 2245, 2246,
    2247, 2248, 2249, 2250, 2251, 2252, 2253, 2254, 2255, 2256, 2257, 2258, 2259,
    2260, 2261, 2262, 2263, 2264, 2265, 2266, 2267, 2268, 2269, 2270, 2271, 2272,
    2273, 2274, 2275, 2276, 2277, 2278, 2279, 2280, 2281, 2282, 2283, 2284, 2285,
    2286, 2287, 2288, 2289, 2290, 2291, 2292, 2293, 2294, 2295, 2296, 2297, 2298,
    2299, 2300, 2301, 2302, 2303, 2304, 2305, 2306, 2307, 2308, 2309, 2310, 2311,
    2312, 2313, 2314, 2315, 2316, 2317, 2318, 2319, 2320, 2321, 2322, 2323, 2324,
    2325, 2326, 2327, 2328, 2329, 2330, 2331, 2332, 2333, 2334, 2335, 2336, 2337,
    2338, 2339, 2340, 2341, 2342, 2343, 2344, 2345, 2346, 2347, 2348, 2349, 2350,
    2351, 2352, 2353, 2354, 2355, 2356, 2357, 2358, 2359, 2360, 2361, 2362, 2363,
    2364, 2365, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376,
    2377, 2378, 2379, 2380, 2381, 2382, 2383, 2384, 2385, 2386, 2387, 2388, 2389,
    2390, 2391, 2392, 2393, 2394, 2395, 2396, 2397, 2398, 2399, 2400, 2401, 2402,
    2403, 2404, 2405, 2406, 2407, 2408, 2409, 2410, 2411, 2412, 2413, 2414, 2415,
    2416, 2417, 2418, 2419, 2420, 2421, 2422, 2423, 2424, 2425, 2426, 2427, 2428,
    2429, 2430, 2431, 2432, 2433, 2434, 2435, 2436, 2437, 2438, 2439, 2440, 2441,
    2442, 2443, 2444, 2445, 2446, 2447, 2448, 2449, 2450, 2451, 2452, 2453, 2454,
    2455, 2456, 2457, 2458, 2459, 2460, 2461, 2462, 2463, 2464, 2465, 2466, 2467,
    2468, 2469, 2470, 2471, 2472, 2473, 2474, 2475, 2476, 2477, 2478, 2479, 2480,
    2481, 2482, 2483, 2484, 2485, 2486, 2487, 2488, 2489, 2490, 2491, 2492, 2493,
    2494, 2495, 2496, 2497, 2498, 2499, 2500, 2501, 2502, 2503, 2504, 2505, 2506,
    2507, 2508, 2509, 2510, 2511, 2512, 2513, 2514, 2515, 2516, 2517, 2518, 2519,
    2520, 2521, 2522, 2523, 2524, 2525, 2526, 2527, 2528, 2529, 2530, 2531, 2532,
    2533, 2534, 2535, 2536, 2537, 2538, 2539, 2540, 2541, 2542, 2543, 2544, 2545,
    2546, 2547, 2548, 2549, 2550, 2551, 2552, 2553, 2554, 2555, 2556, 2557, 2558,
    2559, 2560, 2561, 2562, 2563, 2564, 2565, 2566, 2567, 2568, 2569, 2570, 2571,
    2572, 2573, 2574, 2575, 2576, 2577, 2578, 2579, 2580, 2581, 2582, 2583, 2584,
    2585, 2586, 2587, 2588, 2589, 2590, 2591, 2592, 2593, 2594, 2595, 2596, 2597,
    2598, 2599, 2600, 2601, 2602, 2603, 2604, 2605, 2606, 2607, 2608, 2609, 2610,
    2611, 2612, 2613, 2614, 2615, 2616, 2617, 2618, 2619, 2620, 2621, 2622, 2623,
    2624, 2625, 2626, 2627, 2628, 2629, 2630, 2631, 2632, 2633, 2634, 2635, 2636,
    2637, 2638, 2639, 2640, 2641, 2642, 2643, 2644, 2645, 2646, 2647, 2648, 2649,
    2650, 2651, 2652, 2653, 2654, 2655, 2656, 2657, 2658, 2659, 2660, 2661, 2662,
    2663, 2664, 2665, 2666, 2667, 2668, 2669, 2670, 2671, 2672, 2673, 2674, 2675,
    2676, 2677, 2678, 2679, 2680, 2681, 2682, 2683, 2684, 2685, 2686, 2687, 2688,
    2689, 2690, 2691, 2692, 2693, 2694, 2695, 2696, 2697, 2698, 2699, 2700, 2701,
    2702, 2703, 2704, 2705, 2706, 2707, 2708, 2709, 2710, 2711, 2712, 2713, 2714,
    2715, 2716, 2717, 2718, 2719, 2720, 2721, 2722, 2723, 2724, 2725, 2726, 2727,
    2728, 2729, 2730, 2731, 2732, 2733, 2734, 2735, 2736, 2737, 2738, 2739, 2740,
    2741, 2742, 2743, 2744, 2745, 2746, 2747, 2748, 2749, 2750, 2751, 2752, 2753,
    2754, 2755, 2756, 2757, 2758, 2759, 2760, 2761, 2762, 2763, 2764, 2765, 2766,
    2767, 2768, 2769, 2770, 2771, 2772, 2773, 2774, 2775, 2776, 2777, 2778, 2779,
    2780, 2781, 2782, 2783, 2784, 2785, 2786, 2787, 2788, 2789, 2790, 2791, 2792,
    2793, 2794, 2795, 2796, 2797, 2798, 2799, 2800, 2801, 2802, 2803, 2804, 2805,
    2806, 2807, 2808, 2809, 2810, 2811, 2812, 2813, 2814, 2815, 2816, 2817, 2818,
    2819, 2820, 2821, 2822, 2823, 2824, 2825, 2826, 2827, 2828, 2829, 2830, 2831,
    2832, 2833, 2834, 2835, 2836, 2837, 2838, 2839, 2840, 2841, 2842, 2843, 2844,
    2845, 2846, 2847, 2848, 2849, 2850, 2851, 2852, 2853, 2854, 2855, 2856, 2857,
    2858, 2859, 2860, 2861, 2862, 2863, 2864, 2865, 2866, 2867, 2868, 2869, 2870,
    2871, 2872, 2873, 2874, 2875, 2876, 2877, 2878, 2879, 2880, 2881, 2882, 2883,
    2884, 2885, 2886, 2887, 2888, 2889, 2890, 2891, 2892, 2893, 2894, 2895, 2896,
    2897, 2898, 2899, 2900, 2901, 2902, 2903, 2904, 2905, 2906, 2907, 2908, 2909,
    2910, 2911, 2912, 2913, 2914, 2915, 2916, 2917, 2918, 2919, 2920, 2921, 2922,
    2923, 2924, 2925, 2926, 2927, 2928, 2929, 2930, 2931, 2932, 2933, 2934, 2935,
    2936, 2937, 2938, 2939, 2940, 2941, 2942, 2943, 2944, 2945, 2946, 2947, 2948,
    2949, 2950, 2951, 2952, 2953, 2954, 2955, 2956, 2957, 2958, 2959, 2960, 2961,
    2962, 2963, 2964, 2965, 2966, 2967, 2968, 2969, 2970, 2971, 2972, 2973, 2974,
    2975, 2976, 2977, 2978, 2979, 2980, 2981, 2982, 2983, 2984, 2985, 2986, 2987,
    2988, 2989, 2990, 2991, 2992, 2993, 2994, 2995, 2996, 2997, 2998, 2999, 3000,
    3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010, 3011, 3012, 3013,
    3014, 3015, 3016, 3017, 3018, 3019, 3020, 3021, 3022, 3023, 3024, 3025, 3026,
    3027, 3028, 3029, 3030, 3031, 3032, 3033, 3034, 3035, 3036, 3037, 3038, 3039,
    3040, 3041, 3042, 3043, 3044, 3045, 3046, 3047, 3048, 3049, 3050, 3051, 3052,
    3053, 3054, 3055, 3056, 3057, 3058, 3059, 3060, 3061, 3062, 3063, 3064, 3065,
    3066, 3067, 3068, 3069, 3070, 3071, 3072, 3073, 3074, 3075, 3076, 3077, 3078,
    3079, 3080, 3081, 3082, 3083, 3084, 3085, 3086, 3087, 3088, 3089, 3090, 3091,
    3092, 3093, 3094, 3095, 3096, 3097, 3098, 3099, 3100, 3101, 3102, 3103, 3104,
    3105, 3106, 3107, 3108, 3109, 3110, 3111, 3112, 3113, 3114, 3115, 3116, 3117,
    3118, 3119, 3120, 3121, 3122, 3123, 3124, 3125, 3126, 3127, 3128, 3129, 3130,
    3131, 3132, 3133, 3134, 3135, 3136, 3137, 3138, 3139, 3140, 3141, 3142, 3143,
    3144, 3145, 3146, 3147, 3148, 3149, 3150, 3151, 3152, 3153, 3154, 3155, 3156,
    3157, 3158, 3159, 3160, 3161, 3162, 3163, 3164, 3165, 3166, 3167, 3168, 3169,
    3170, 3171, 3172, 3173, 3174, 3175, 3176, 3177, 3178, 3179, 3180, 3181, 3182,
    3183, 3184, 3185, 3186, 3187, 3188, 3189, 3190, 3191, 3192, 3193, 3194, 3195,
    3196, 3197, 3198, 3199, 3200, 3201, 3202, 3203, 3204, 3205, 3206, 3207, 3208,
    3209, 3210, 3211, 3212, 3213, 3214, 3215, 3216, 3217, 3218, 3219, 3220, 3221,
    3222, 3223, 3224, 3225, 3226, 3227, 3228, 3229, 3230, 3231, 3232, 3233, 3234,
    3235, 3236, 3237, 3238, 3239, 3240, 3241, 3242, 3243, 3244, 3245, 3246, 3247,
    3248, 3249, 3250, 3251, 3252, 3253, 3254, 3255, 3256, 3257, 3258, 3259, 3260,
    3261, 3262, 3263, 3264, 3265, 3266, 3267, 3268, 3269, 3270, 3271, 3272, 3273,
    3274, 3275, 3276, 3277, 3278, 3279, 3280, 3281, 3282, 3283, 3284, 3285, 3286,
    3287, 3288, 3289, 3290, 3291, 3292, 3293, 3294, 3295, 3296, 3297, 3298, 3299,
    3300, 3301, 3302, 3303, 3304, 3305, 3306, 3307, 3308, 3309, 3310, 3311, 3312,
    3313, 3314, 3315, 3316, 3317, 3318, 3319, 3320, 3321, 3322, 3323, 3324, 3325,
    3326, 3327, 3328, 3329, 3330, 3331, 3332, 3333, 3334, 3335, 3336, 3337, 3338,
    3339, 3340, 3341, 3342, 3343, 3344, 3345, 3346, 3347, 3348, 3349, 3350, 3351,
    3352, 3353, 3354, 3355, 3356, 3357, 3358, 3359, 3360, 3361, 3362, 3363, 3364,
    3365, 3366, 3367, 3368, 3369, 3370, 3371, 3372, 3373, 3374, 3375, 3376, 3377,
    3378, 3379, 3380, 3381, 3382, 3383, 3384, 3385, 3386, 3387, 3388, 3389, 3390,
    3391, 3392, 3393, 3394, 3395, 3396, 3397, 3398, 3399, 3400, 3401, 3402, 3403,
    3404, 3405, 3406, 3407, 3408, 3409, 3410, 3411, 3412, 3413, 3414, 3415, 3416,
    3417, 3418, 3419, 3420, 3421, 3422, 3423, 3424, 3425, 3426, 3427, 3428, 3429,
    3430, 3431, 3432, 3433, 3434, 3435, 3436, 3437, 3438, 3439, 3440, 3441, 3442,
    3443, 3444, 3445, 3446, 3447, 3448, 3449, 3450, 3451, 3452, 3453, 3454, 3455,
    3456, 3457, 3458, 3459, 3460, 3461, 3462, 3463, 3464, 3465, 3466, 3467, 3468,
    3469, 3470, 3471, 3472, 3473, 3474, 3475, 3476, 3477, 3478, 3479, 3480, 3481,
    3482, 3483, 3484, 3485, 3486, 3487, 3488, 3489, 3490, 3491, 3492, 3493, 3494,
    3495, 3496, 3497, 3498, 3499, 3500, 3501, 3502, 3503, 3504, 3505, 3506, 3507,
    3508, 3509, 3510, 3511, 3512, 3513, 3514, 3515, 3516, 3517, 3518, 3519, 3520,
    3521, 3522, 3523, 3524, 3525, 3526, 3527, 3528, 3529, 3530, 3531, 3532, 3533,
    3534, 3535, 3536, 3537, 3538, 3539, 3540, 3541, 3542, 3543, 3544, 3545, 3546,
    3547, 3548, 3549, 3550, 3551, 3552, 3553, 3554, 3555, 3556, 3557, 3558, 3559,
    3560, 3561, 3562, 3563, 3564, 3565, 3566, 3567, 3568, 3569, 3570, 3571, 3572,
    3573, 3574, 3575, 3576, 3577, 3578, 3579, 3580, 3581, 3582, 3583, 3584, 3585,
    3586, 3587, 3588, 3589, 3590, 3591, 3592, 3593, 3594, 3595, 3596, 3597, 3598,
    3599, 3600, 3601, 3602, 3603, 3604, 3605, 3606, 3607, 3608, 3609, 3610, 3611,
    3612, 3613, 3614, 3615, 3616, 3617, 3618, 3619, 3620, 3621, 3622, 3623, 3624,
    3625, 3626, 3627, 3628, 3629, 3630, 3631, 3632, 3633, 3634, 3635, 3636, 3637,
    3638, 3639, 3640, 3641, 3642, 3643, 3644, 3645, 3646, 3647, 3648, 3649, 3650,
    3651, 3652, 3653, 3654, 3655, 3656, 3657, 3658, 3659, 3660, 3661, 3662, 3663,
    3664, 3665, 3666, 3667, 3668, 3669, 3670, 3671, 3672, 3673, 3674, 3675, 3676,
    3677, 3678, 3679, 3680, 3681, 3682, 3683, 3684, 3685, 3686, 3687, 3688, 3689,
    3690, 3691, 3692, 3693, 3694, 3695, 3696, 3697, 3698, 3699, 3700, 3701, 3702,
    3703, 3704, 3705, 3706, 3707, 3708, 3709, 3710, 3711, 3712, 3713, 3714, 3715,
    3716, 3717, 3718, 3719, 3720, 3721, 3722, 3723, 3724, 3725, 3726, 3727, 3728,
    3729, 3730, 3731, 3732, 3733, 3734, 3735, 3736, 3737, 3738, 3739, 3740, 3741,
    3742, 3743, 3744, 3745, 3746, 3747, 3748, 3749, 3750, 3751, 3752, 3753, 3754,
    3755, 3756, 3757, 3758, 3759, 3760, 3761, 3762, 3763, 3764, 3765, 3766, 3767,
    3768, 3769, 3770, 3771, 3772, 3773, 3774, 3775, 3776, 3777, 3778, 3779, 3780,
    3781, 3782, 3783, 3784, 3785, 3786, 3787, 3788, 3789, 3790, 3791, 3792, 3793,
    3794, 3795, 3796, 3797, 3798, 3799, 3800, 3801, 3802, 3803, 3804, 3805, 3806,
    3807, 3808, 3809, 3810, 3811, 3812, 3813, 3814, 3815, 3816, 3817, 3818, 3819,
    3820, 3821, 3822, 3823, 3824, 3825, 3826, 3827, 3828, 3829, 3830, 3831, 3832,
    3833, 3834, 3835, 3836, 3837, 3838, 3839, 3840, 3841, 3842, 3843, 3844, 3845,
    3846, 3847, 3848, 3849, 3850, 3851, 3852, 3853, 3854, 3855, 3856, 3857, 3858,
    3859, 3860, 3861, 3862, 3863, 3864, 3865, 3866, 3867, 3868, 3869, 3870, 3871,
    3872, 3873, 3874, 3875, 3876, 3877, 3878, 3879, 3880, 3881, 3882, 3883, 3884,
    3885, 3886, 3887, 3888, 3889, 3890, 3891, 3892, 3893, 3894, 3895, 3896, 3897,
    3898, 3899, 3900, 3901, 3902, 3903, 3904, 3905, 3906, 3907, 3908, 3909, 3910,
    3911, 3912, 3913, 3914, 3915, 3916, 3917, 3918, 3919, 3920, 3921, 3922, 3923,
    3924, 3925, 3926, 3927, 3928, 3929, 3930, 3931, 3932, 3933, 3934, 3935, 3936,
    3937, 3938, 3939, 3940, 3941, 3942, 3943, 3944, 3945, 3946, 3947, 3948, 3949,
    3950, 3951, 3952, 3953, 3954, 3955, 3956, 3957, 3958, 3959, 3960, 3961, 3962,
    3963, 3964, 3965, 3966, 3967, 3968, 3969, 3970, 3971, 3972, 3973, 3974, 3975,
    3976, 3977, 3978, 3979, 3980, 3981, 3982, 3983, 3984, 3985, 3986, 3987, 3988,
    3989, 3990, 3991, 3992, 3993, 3994, 3995, 3996, 3997, 3998, 3999, 4000, 4001,
    4002, 4003, 4004, 4005, 4006, 4007, 4008, 4009, 4010, 4011, 4012, 4013, 4014,
    4015, 4016, 4017, 4018, 4019, 4020, 4021, 4022, 4023, 4024, 4025, 4026, 4027,
    4028, 4029, 4030, 4031, 4032, 4033, 4034, 4035, 4036, 4037, 4038, 4039, 4040,
    4041, 4042, 4043, 4044, 4045, 4046, 4047, 4048, 4049, 4050, 4051, 4052, 4053,
    4054, 4055, 4056, 4057, 4058, 4059, 4060, 4061, 4062, 4063, 4064, 4065, 4066,
    4067, 4068, 4069, 4070, 4071, 4072, 4073, 4074, 4075, 4076, 4077, 4078, 4079,
    4080, 4081, 4082, 4083, 4084, 4085, 4086, 4087, 4088, 4089, 4090, 4091, 4092,
    4093, 4094, 4095, 4096, 4097, 4098, 4099, 4100, 4101, 4102, 4103, 4104, 4105,
    4106, 4107, 4108, 4109, 4110, 4111, 4112, 4113, 4114, 4115, 4116, 4117, 4118,
    4119, 4120, 4121, 4122, 4123, 4124, 4125, 4126, 4127, 4128, 4129, 4130, 4131,
    4132, 4133, 4134, 4135, 4136, 4137, 4138, 4139, 4140, 4141, 4142, 4143, 4144,
    4145, 4146, 4147, 4148, 4149, 4150, 4151, 4152, 4153, 4154, 4155, 4156, 4157,
    4158, 4159, 4160, 4161, 4162, 4163, 4164, 4165, 4166, 4167, 4168, 4169, 4170,
    4171, 4172, 4173, 4174, 4175, 4176, 4177, 4178, 4179, 4180, 4181, 4182, 4183,
    4184, 4185, 4186, 4187, 4188, 4189, 4190, 4191, 4192, 4193, 4194, 4195, 4196,
    4197, 4198, 4199, 4200, 4201, 4202, 4203, 4204, 4205, 4206, 4207, 4208, 4209,
    4210, 4211, 4212, 4213, 4214, 4215, 4216, 4217, 4218, 4219, 4220, 4221, 4222,
    4223, 4224, 4225, 4226, 4227, 4228, 4229, 4230, 4231, 4232, 4233, 4234, 4235,
    4236, 4237, 4238, 4239, 4240, 4241, 4242, 4243, 4244, 4245, 4246, 4247, 4248,
    4249, 4250, 4251, 4252, 4253, 4254, 4255, 4256, 4257, 4258, 4259, 4260, 4261,
    4262, 4263, 4264, 4265, 4266, 4267, 4268, 4269, 4270, 4271, 4272, 4273, 4274,
    4275, 4276, 4277, 4278, 4279, 4280, 4281, 4282, 4283, 4284, 4285, 4286, 4287,
    4288, 4289, 4290, 4291, 4292, 4293, 4294, 4295, 4296, 4297, 4298, 4299, 4300,
    4301, 4302, 4303, 4304, 4305, 4306, 4307, 4308, 4309, 4310, 4311, 4312, 4313,
    4314, 4315, 4316, 4317, 4318, 4319, 4320, 4321, 4322, 4323, 4324, 4325, 4326,
    4327, 4328, 4329, 4330, 4331, 4332, 4333, 4334, 4335, 4336, 4337, 4338, 4339,
    4340, 4341, 4342, 4343, 4344, 4345, 4346, 4347, 4348, 4349, 4350, 4351, 4352,
    4353, 4354, 4355, 4356, 4357, 4358, 4359, 4360, 4361, 4362, 4363, 4364, 4365,
    4366, 4367, 4368, 4369, 4370, 4371, 4372, 4373, 4374, 4375, 4376, 4377, 4378,
    4379, 4380, 4381, 4382, 4383, 4384, 4385, 4386, 4387, 4388, 4389, 4390, 4391,
    4392, 4393, 4394, 4395, 4396, 4397, 4398, 4399, 4400, 4401, 4402, 4403, 4404,
    4405, 4406, 4407, 4408, 4409, 4410, 4411, 4412, 4413, 4414, 4415, 4416, 4417,
    4418, 4419, 4420, 4421, 4422, 4423, 4424, 4425, 4426, 4427, 4428, 4429, 4430,
    4431, 4432, 4433, 4434, 4435, 4436, 4437, 4438, 4439, 4440, 4441, 4442, 4443,
    4444, 4445, 4446, 4447, 4448, 4449, 4450, 4451, 4452, 4453, 4454, 4455, 4456,
    4457, 4458, 4459, 4460, 4461, 4462, 4463, 4464, 4465, 4466, 4467, 4468, 4469,
    4470, 4471, 4472, 4473, 4474, 4475, 4476, 4477, 4478, 4479, 4480, 4481, 4482,
    4483, 4484, 4485, 4486, 4487, 4488, 4489, 4490, 4491, 4492, 4493, 4494, 4495,
    4496, 4497, 4498, 4499, 4500, 4501, 4502, 4503, 4504, 4505, 4506, 4507, 4508,
    4509, 4510, 4511, 4512, 4513, 4514, 4515, 4516, 4517, 4518, 4519, 4520, 4521,
    4522, 4523, 4524, 4525, 4526, 4527, 4528, 4529, 4530, 4531, 4532, 4533, 4534,
    4535, 4536, 4537, 4538, 4539, 4540, 4541, 4542, 4543, 4544, 4545, 4546, 4547,
    4548, 4549, 4550, 4551, 4552, 4553, 4554, 4555, 4556, 4557, 4558, 4559, 4560,
    4561, 4562, 4563, 4564, 4565, 4566, 4567, 4568, 4569, 4570, 4571, 4572, 4573,
    4574, 4575, 4576, 4577, 4578, 4579, 4580, 4581, 4582, 4583, 4584, 4585, 4586,
    4587, 4588, 4589, 4590, 4591, 4592, 4593, 4594, 4595, 4596, 4597, 4598, 4599,
    4600, 4601, 4602, 4603, 4604, 4605, 4606, 4607, 4608, 4609, 4610, 4611, 4612,
    4613, 4614, 4615, 4616, 4617, 4618, 4619, 4620, 4621, 4622, 4623, 4624, 4625,
    4626, 4627, 4628, 4629, 4630, 4631, 4632, 4633, 4634, 4635, 4636, 4637, 4638,
    4639, 4640, 4641, 4642, 4643, 4644, 4645, 4646, 4647, 4648, 4649, 4650, 4651,
    4652, 4653, 4654, 4655, 4656, 4657, 4658, 4659, 4660, 4661, 4662, 4663, 4664,
    4665, 4666, 4667, 4668, 4669, 4670, 4671, 4672, 4673, 4674, 4675, 4676, 4677,
    4678, 4679, 4680, 4681, 4682, 4683, 4684, 4685, 4686, 4687, 4688, 4689, 4690,
    4691, 4692, 4693, 4694, 4695, 4696, 4697, 4698, 4699, 4700, 4701, 4702, 4703,
    4704, 4705, 4706, 4707, 4708, 4709, 4710, 4711, 4712, 4713, 4714, 4715, 4716,
    4717, 4718, 4719, 4720, 4721, 4722, 4723, 4724, 4725, 4726, 4727, 4728, 4729,
    4730, 4731, 4732, 4733, 4734, 4735, 4736, 4737, 4738, 4739, 4740, 4741, 4742,
    4743, 4744, 4745, 4746, 4747, 4748, 4749, 4750, 4751, 4752, 4753, 4754, 4755,
    4756, 4757, 4758, 4759, 4760, 4761, 4762, 4763, 4764, 4765, 4766, 4767, 4768,
    4769, 4770, 4771, 4772, 4773, 4774, 4775, 4776, 4777, 4778, 4779, 4780, 4781,
    4782, 4783, 4784, 4785, 4786, 4787, 4788, 4789, 4790, 4791, 4792, 4793, 4794,
    4795, 4796, 4797, 4798, 4799, 4800, 4801, 4802, 4803, 4804, 4805, 4806, 4807,
    4808, 4809, 4810, 4811, 4812, 4813, 4814, 4815, 4816, 4817, 4818, 4819, 4820,
    4821, 4822, 4823, 4824, 4825, 4826, 4827, 4828, 4829, 4830, 4831, 4832, 4833,
    4834, 4835, 4836, 4837, 4838, 4839, 4840, 4841, 4842, 4843, 4844, 4845, 4846,
    4847, 4848, 4849, 4850, 4851, 4852, 4853, 4854, 4855, 4856, 4857, 4858, 4859,
    4860, 4861, 4862, 4863, 4864, 4865, 4866, 4867, 4868, 4869, 4870, 4871, 4872,
    4873, 4874, 4875, 4876, 4877, 4878, 4879, 4880, 4881, 4882, 4883, 4884, 4885,
    4886, 4887, 4888, 4889, 4890, 4891, 4892, 4893, 4894, 4895, 4896, 4897, 4898,
    4899, 4900, 4901, 4902, 4903, 4904, 4905, 4906, 4907, 4908, 4909, 4910, 4911,
    4912, 4913, 4914, 4915, 4916, 4917, 4918, 4919, 4920, 4921, 4922, 4923, 4924,
    4925, 4926, 4927, 4928, 4929, 4930, 4931, 4932, 4933, 4934, 4935, 4936, 4937,
    4938, 4939, 4940, 4941, 4942, 4943, 4944, 4945, 4946, 4947, 4948, 4949, 4950,
    4951, 4952, 4953, 4954, 4955, 4956, 4957, 4958, 4959, 4960, 4961, 4962, 4963,
    4964, 4965, 4966, 4967, 4968, 4969, 4970, 4971, 4972, 4973, 4974, 4975, 4976,
    4977, 4978, 4979, 4980, 4981, 4982, 4983, 4984, 4985, 4986, 4987, 4988, 4989,
    4990, 4991, 4992, 4993, 4994, 4995, 4996, 4997, 4998, 4999, 5000, 5001, 5002,
    5003, 5004, 5005, 5006, 5007, 5008, 5009, 5010, 5011, 5012, 5013, 5014, 5015,
    5016, 5017, 5018, 5019, 5020, 5021, 5022, 5023, 5024, 5025, 5026, 5027, 5028,
    5029, 5030, 5031, 5032, 5033, 5034, 5035, 5036, 5037, 5038, 5039, 5040, 5041,
    5042, 5043, 5044, 5045, 5046, 5047, 5048, 5049, 5050, 5051, 5052, 5053, 5054,
    5055, 5056, 5057, 5058, 5059, 5060, 5061, 5062, 5063, 5064, 5065, 5066, 5067,
    5068, 5069, 5070, 5071, 5072, 5073, 5074, 5075, 5076, 5077, 5078, 5079, 5080,
    5081, 5082, 5083, 5084, 5085, 5086, 5087, 5088, 5089, 5090, 5091, 5092, 5093,
    5094, 5095, 5096, 5097, 5098, 5099, 5100, 5101, 5102, 5103, 5104, 5105, 5106,
    5107, 5108, 5109, 5110, 5111, 5112, 5113, 5114, 5115, 5116, 5117, 5118, 5119,
    5120, 5121, 5122, 5123, 5124, 5125, 5126, 5127, 5128, 5129, 5130, 5131, 5132,
    5133, 5134, 5135, 5136, 5137, 5138, 5139, 5140, 5141, 5142, 5143, 5144, 5145,
    5146, 5147, 5148, 5149, 5150, 5151, 5152, 5153, 5154, 5155, 5156, 5157, 5158,
    5159, 5160, 5161, 5162, 5163, 5164, 5165, 5166, 5167, 5168, 5169, 5170, 5171,
    5172, 5173, 5174, 5175, 5176, 5177, 5178, 5179, 5180, 5181, 5182, 5183, 5184,
    5185, 5186, 5187, 5188, 5189, 5190, 5191, 5192, 5193, 5194, 5195, 5196, 5197,
    5198, 5199, 5200, 5201, 5202, 5203, 5204, 5205, 5206, 5207, 5208, 5209, 5210,
    5211, 5212, 5213, 5214, 5215, 5216, 5217, 5218, 5219, 5220, 5221, 5222, 5223,
    5224, 5225, 5226, 5227, 5228, 5229, 5230, 5231, 5232, 5233, 5234, 5235, 5236,
    5237, 5238, 5239, 5240, 5241, 5242, 5243, 5244, 5245, 5246, 5247, 5248, 5249,
    5250, 5251, 5252, 5253, 5254, 5255, 5256, 5257, 5258, 5259, 5260, 5261, 5262,
    5263, 5264, 5265, 5266, 5267, 5268, 5269, 5270, 5271, 5272, 5273, 5274, 5275,
    5276, 5277, 5278, 5279, 5280, 5281, 5282, 5283, 5284, 5285, 5286, 5287, 5288,
    5289, 5290, 5291, 5292, 5293, 5294, 5295, 5296, 5297, 5298, 5299, 5300, 5301,
    5302, 5303, 5304, 5305, 5306, 5307, 5308, 5309, 5310, 5311, 5312, 5313, 5314,
    5315, 5316, 5317, 5318, 5319, 5320, 5321, 5322, 5323, 5324, 5325, 5326, 5327,
    5328, 5329, 5330, 5331, 5332, 5333, 5334, 5335, 5336, 5337, 5338, 5339, 5340,
    5341, 5342, 5343, 5344, 5345, 5346, 5347, 5348, 5349, 5350, 5351, 5352, 5353,
    5354, 5355, 5356, 5357, 5358, 5359, 5360, 5361, 5362, 5363, 5364, 5365, 5366,
    5367, 5368, 5369, 5370, 5371, 5372, 5373, 5374, 5375, 5376, 5377, 5378, 5379,
    5380, 5381, 5382, 5383, 5384, 5385, 5386, 5387, 5388, 5389, 5390, 5391, 5392,
    5393, 5394, 5395, 5396, 5397, 5398, 5399, 5400, 5401, 5402, 5403, 5404, 5405,
    5406, 5407, 5408, 5409, 5410, 5411, 5412, 5413, 5414, 5415, 5416, 5417, 5418,
    5419, 5420, 5421, 5422, 5423, 5424, 5425, 5426, 5427, 5428, 5429, 5430, 5431,
    5432, 5433, 5434, 5435, 5436, 5437, 5438, 5439, 5440, 5441, 5442, 5443, 5444,
    5445, 5446, 5447, 5448, 5449, 5450, 5451, 5452, 5453, 5454, 5455, 5456, 5457,
    5458, 5459, 5460, 5461, 5462, 5463, 5464, 5465, 5466, 5467, 5468, 5469, 5470,
    5471, 5472, 5473, 5474, 5475, 5476, 5477, 5478, 5479, 5480, 5481, 5482, 5483,
    5484, 5485, 5486, 5487, 5488, 5489, 5490, 5491, 5492, 5493, 5494, 5495, 5496,
    5497, 5498, 5499, 5500, 5501, 5502, 5503, 5504, 5505, 5506, 5507, 5508, 5509,
    5510, 5511, 5512, 5513, 5514, 5515, 5516, 5517, 5518, 5519, 5520, 5521, 5522,
    5523, 5524, 5525, 5526, 5527, 5528, 5529, 5530, 5531, 5532, 5533, 5534, 5535,
    5536, 5537, 5538, 5539, 5540, 5541, 5542, 5543, 5544, 5545, 5546, 5547, 5548,
    5549, 5550, 5551, 5552, 5553, 5554, 5555, 5556, 5557, 5558, 5559, 5560, 5561,
    5562, 5563, 5564, 5565, 5566, 5567, 5568, 5569, 5570, 5571, 5572, 5573, 5574,
    5575, 5576, 5577, 5578, 5579, 5580, 5581, 5582, 5583, 5584, 5585, 5586, 5587,
    5588, 5589, 5590, 5591, 5592, 5593, 5594, 5595, 5596, 5597, 5598, 5599, 5600,
    5601, 5602, 5603, 5604, 5605, 5606, 5607, 5608, 5609, 5610, 5611, 5612, 5613,
    5614, 5615, 5616, 5617, 5618, 5619, 5620, 5621, 5622, 5623, 5624, 5625, 5626,
    5627, 5628, 5629, 5630, 5631, 5632, 5633, 5634, 5635, 5636, 5637, 5638, 5639,
    5640, 5641, 5642, 5643, 5644, 5645, 5646, 5647, 5648, 5649, 5650, 5651, 5652,
    5653, 5654, 5655, 5656, 5657, 5658, 5659, 5660, 5661, 5662, 5663, 5664, 5665,
    5666, 5667, 5668, 5669, 5670, 5671, 5672, 5673, 5674, 5675, 5676, 5677, 5678,
    5679, 5680, 5681, 5682, 5683, 5684, 5685, 5686, 5687, 5688, 5689, 5690, 5691,
    5692, 5693, 5694, 5695, 5696, 5697, 5698, 5699, 5700, 5701, 5702, 5703, 5704,
    5705, 5706, 5707, 5708, 5709, 5710, 5711, 5712, 5713, 5714, 5715, 5716, 5717,
    5718, 5719, 5720, 5721, 5722, 5723, 5724, 5725, 5726, 5727, 5728, 5729, 5730,
    5731, 5732, 5733, 5734, 5735, 5736, 5737, 5738, 5739, 5740, 5741, 5742, 5743,
    5744, 5745, 5746, 5747, 5748, 5749, 5750, 5751, 5752, 5753, 5754, 5755, 5756,
    5757, 5758, 5759, 5760, 5761, 5762, 5763, 5764, 5765, 5766, 5767, 5768, 5769,
    5770, 5771, 5772, 5773, 5774, 5775, 5776, 5777, 5778, 5779, 5780, 5781, 5782,
    5783, 5784, 5785, 5786, 5787, 5788, 5789, 5790, 5791, 5792, 5793, 5794, 5795,
    5796, 5797, 5798, 5799, 5800, 5801, 5802, 5803, 5804, 5805, 5806, 5807, 5808,
    5809, 5810, 5811, 5812, 5813, 5814, 5815, 5816, 5817, 5818, 5819, 5820, 5821,
    5822, 5823, 5824, 5825, 5826, 5827, 5828, 5829, 5830, 5831, 5832, 5833, 5834,
    5835, 5836, 5837, 5838, 5839, 5840, 5841, 5842, 5843, 5844, 5845, 5846, 5847,
    5848, 5849, 5850, 5851, 5852, 5853, 5854, 5855, 5856, 5857, 5858, 5859, 5860,
    5861, 5862, 5863, 5864, 5865, 5866, 5867, 5868, 5869, 5870, 5871, 5872, 5873,
    5874, 5875, 5876, 5877, 5878, 5879, 5880, 5881, 5882, 5883, 5884, 5885, 5886,
    5887, 5888, 5889, 5890, 5891, 5892, 5893, 5894, 5895, 5896, 5897, 5898, 5899,
    5900, 5901, 5902, 5903, 5904, 5905, 5906, 5907, 5908, 5909, 5910, 5911, 5912,
    5913, 5914, 5915, 5916, 5917, 5918, 5919, 5920, 5921, 5922, 5923, 5924, 5925,
    5926, 5927, 5928, 5929, 5930, 5931, 5932, 5933, 5934, 5935, 5936, 5937, 5938,
    5939, 5940, 5941, 5942, 5943, 5944, 5945, 5946, 5947, 5948, 5949, 5950, 5951,
    5952, 5953, 5954, 5955, 5956, 5957, 5958, 5959, 5960, 5961, 5962, 5963, 5964,
    5965, 5966, 5967, 5968, 5969, 5970, 5971, 5972, 5973, 5974, 5975, 5976, 5977,
    5978, 5979, 5980, 5981, 5982, 5983, 5984, 5985, 5986, 5987, 5988, 5989, 5990,
    5991, 5992, 5993, 5994, 5995, 5996, 5997, 5998, 5999, 6000), `fold` = c(1, 1,
    1, 1, 2, 2, 2, 1, 2, 1, 2, 1, 1, 1, 1, 2, 1, 1, 2, 2, 1, 1, 2, 1, 2, 1, 2, 2,
    2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1,
    2, 2, 2, 2, 1, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2, 2, 2, 1,
    2, 1, 2, 1, 1, 1, 2, 1, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2,
    1, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 1, 1, 2, 1, 2, 2, 1,
    2, 1, 2, 1, 2, 2, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2,
    1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 2, 1, 2, 2,
    1, 2, 1, 1, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 2, 2,
    2, 1, 2, 1, 2, 1, 2, 1, 1, 2, 2, 1, 1, 1, 1, 2, 1, 2, 2, 1, 2, 2, 2, 2, 1, 2,
    1, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 1, 1, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2,
    1, 1, 1, 2, 1, 1, 2, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 2, 1, 2, 2, 2, 1, 1, 1, 1,
    1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 2, 2,
    2, 1, 2, 2, 2, 1, 1, 2, 2, 1, 1, 2, 1, 2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2,
    2, 1, 2, 2, 1, 2, 1, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 2, 2, 2, 1, 1, 2, 1, 2,
    1, 2, 1, 1, 1, 1, 2, 1, 2, 2, 1, 1, 1, 2, 2, 1, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2,
    2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 2, 2, 2,
    1, 2, 2, 2, 2, 2, 1, 2, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 2, 1, 2, 2, 1, 1,
    2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 2, 2, 1,
    1, 2, 2, 2, 1, 2, 1, 2, 2, 2, 2, 2, 1, 2, 2, 1, 2, 2, 1, 1, 1, 1, 2, 1, 2, 1,
    1, 1, 1, 1, 1, 2, 2, 1, 2, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 2, 2, 2, 1, 2,
    1, 1, 2, 2, 1, 1, 1, 2, 2, 2, 1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 2, 2, 1, 2, 1,
    1, 1, 1, 1, 2, 2, 1, 1, 2, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 2, 2, 2, 1, 2, 1, 1,
    2, 2, 2, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 1, 2,
    1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 2, 2, 1, 2, 1, 1, 1, 1, 2, 2, 2, 2, 1, 2, 1,
    2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 2, 1, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2,
    2, 1, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 2, 1, 1, 1, 1, 2, 2, 2, 1, 1, 2,
    1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 2, 2, 1, 2, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2, 1,
    2, 1, 1, 2, 2, 1, 2, 2, 2, 1, 1, 2, 1, 1, 1, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1, 2,
    2, 2, 1, 2, 1, 2, 2, 1, 1, 2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 2, 2, 2, 1, 1, 1, 1,
    1, 2, 1, 1, 2, 1, 1, 1, 2, 1, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1, 1, 2, 1, 2, 2, 1,
    1, 1, 1, 2, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 2, 2, 1, 1,
    2, 1, 2, 1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 1, 1, 1,
    2, 2, 1, 2, 2, 1, 1, 1, 1, 2, 2, 2, 1, 2, 2, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1,
    1, 2, 2, 1, 2, 2, 1, 1, 2, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 2, 1,
    1, 2, 1, 2, 2, 2, 1, 1, 2, 2, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 1, 2, 1, 1,
    1, 2, 2, 1, 2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 2, 2, 1, 2, 2, 1, 1, 1, 2, 2, 1, 2,
    1, 1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1,
    2, 1, 2, 2, 1, 1, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 1, 2, 1, 2, 1, 2, 2, 2, 2, 2,
    1, 2, 2, 1, 2, 1, 2, 2, 2, 2, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2,
    1, 1, 1, 1, 2, 1, 2, 2, 2, 2, 1, 2, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 1, 1, 2,
    1, 2, 1, 1, 2, 2, 2, 2, 1, 2, 2, 1, 1, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2,
    2, 1, 2, 2, 1, 1, 2, 1, 2, 2, 2, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 2, 1, 1, 1,
    1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2,
    2, 1, 2, 2, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 2, 2, 1, 2,
    1, 1, 1, 1, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2,
    2, 2, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 2, 1, 2, 1, 1, 1, 2, 1, 2, 1, 2,
    2, 2, 2, 2, 1, 1, 1, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 2, 2, 1, 1, 2, 1, 2, 2,
    1, 2, 2, 2, 2, 1, 2, 2, 1, 2, 2, 1, 2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 2, 2, 2, 1, 1, 1, 1, 2, 2, 1,
    1, 2, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 2, 2, 1, 1, 2, 1, 1, 2, 2, 2, 1,
    1, 1, 2, 1, 2, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 2, 2, 1, 2, 2, 1, 2, 1, 2, 2,
    1, 1, 2, 2, 1, 1, 2, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 1,
    1, 1, 2, 1, 2, 2, 2, 1, 1, 2, 1, 1, 2, 2, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 2, 1,
    1, 1, 1, 1, 2, 2, 2, 1, 1, 2, 2, 1, 1, 2, 1, 2, 2, 2, 1, 1, 2, 1, 1, 1, 2, 1,
    2, 1, 2, 2, 1, 2, 2, 2, 1, 2, 2, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 2, 1, 2,
    1, 2, 2, 1, 2, 2, 1, 1, 2, 2, 2, 1, 2, 2, 2, 2, 1, 2, 1, 1, 1, 2, 1, 2, 2, 2,
    2, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 2, 2, 2,
    2, 2, 2, 1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 2, 2, 1, 2, 1,
    1, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 1, 1, 2,
    2, 2, 2, 1, 1, 1, 2, 1, 2, 2, 2, 2, 1, 1, 2, 1, 2, 2, 2, 1, 1, 1, 2, 1, 2, 1,
    1, 2, 1, 1, 1, 2, 2, 1, 2, 2, 2, 2, 1, 2, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1,
    1, 2, 1, 2, 1, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 1, 1, 1, 1,
    2, 2, 1, 1, 2, 1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 2, 2, 1, 2, 2, 1, 1,
    1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 2, 2, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 2, 1, 2,
    2, 2, 1, 2, 2, 1, 1, 2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 2, 2, 1, 1, 1, 2, 1, 1, 2,
    1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 1, 1, 2, 2, 1,
    1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 2, 2, 2,
    1, 1, 1, 2, 2, 1, 2, 1, 2, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 1,
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 1, 2, 1, 2, 1,
    2, 2, 2, 2, 1, 2, 2, 1, 2, 2, 2, 2, 1, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1,
    2, 2, 1, 2, 2, 2, 1, 1, 2, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1,
    2, 2, 2, 1, 2, 1, 1, 2, 2, 1, 1, 1, 1, 2, 2, 1, 2, 1, 1, 1, 1, 2, 2, 2, 2, 2,
    1, 2, 2, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 2, 1, 2, 1, 2, 1, 1, 1, 1, 2, 2, 2, 1,
    1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 1,
    2, 2, 2, 2, 1, 2, 2, 1, 2, 2, 1, 1, 1, 2, 1, 2, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1,
    1, 1, 2, 1, 1, 1, 1, 2, 1, 2, 2, 2, 2, 2, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 2, 2,
    2, 2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 1, 2, 1, 2, 2, 1, 1, 2, 1, 2, 2, 2, 1, 1, 1,
    2, 2, 1, 1, 1, 2, 2, 1, 2, 1, 1, 2, 1, 1, 1, 1, 2, 2, 1, 2, 1, 1, 1, 1, 1, 2,
    2, 2, 2, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 2, 2, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1,
    2, 2, 1, 1, 2, 2, 1, 1, 2, 2, 2, 1, 1, 2, 2, 1, 1, 1, 2, 2, 2, 2, 1, 2, 1, 2,
    2, 1, 2, 1, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1, 2, 2, 2, 2, 1, 2, 2, 1, 2, 1, 2, 1,
    2, 2, 1, 2, 2, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 2, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1,
    1, 2, 1, 1, 2, 1, 2, 1, 1, 1, 1, 2, 2, 2, 1, 2, 2, 2, 1, 1, 2, 1, 1, 1, 2, 1,
    1, 1, 1, 2, 2, 2, 2, 1, 2, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 2, 2, 1, 1, 1,
    2, 1, 1, 1, 1, 2, 2, 2, 1, 1, 2, 1, 2, 1, 1, 2, 2, 2, 2, 1, 2, 2, 2, 2, 1, 2,
    1, 2, 2, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 1, 2, 2, 1, 2, 1, 2, 2,
    1, 2, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1,
    2, 2, 2, 2, 2, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 2, 2, 1, 2, 2, 2, 1, 1, 1, 1,
    1, 1, 2, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 2, 2, 1, 1, 2, 1, 1, 1, 1, 1,
    1, 1, 2, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 1, 1,
    1, 2, 2, 2, 1, 2, 1, 2, 2, 2, 2, 2, 1, 1, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2,
    2, 2, 2, 1, 2, 1, 1, 2, 2, 1, 1, 1, 1, 2, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1,
    1, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2,
    1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1,
    1, 2, 1, 1, 2, 2, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 1, 1, 2, 1,
    2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 2, 1, 1, 1, 2, 2, 1, 1, 2, 1, 1, 2, 2,
    1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 2, 2, 2, 2, 1, 2, 1, 1, 1, 2, 1, 1,
    1, 2, 1, 1, 1, 2, 1, 2, 2, 2, 2, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 2, 2, 1,
    1, 2, 1, 1, 1, 2, 2, 1, 2, 2, 2, 2, 2, 1, 2, 1, 2, 2, 1, 1, 2, 1, 1, 2, 1, 2,
    2, 2, 2, 2, 2, 1, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2,
    2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 2, 2, 1, 1, 1, 1, 2, 2, 2, 2, 1, 2, 2, 2,
    2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 1, 2, 1, 2, 2, 2, 2, 1,
    2, 1, 1, 2, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 2, 1, 1,
    1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 2, 2, 1, 1, 2, 1, 2, 2, 2, 2, 2, 2, 1,
    1, 2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 2, 1, 1, 2, 2, 2,
    2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1,
    1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1,
    2, 1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 2, 2, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 2,
    2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2, 2, 2, 1, 2, 2, 1, 1, 2, 1,
    2, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 2, 2, 2, 1, 2, 1, 1, 1, 2, 1, 2, 2, 1,
    1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 1, 1, 2, 2, 1, 2, 1, 2, 1, 1, 1, 2, 2, 1, 1, 1,
    1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 2, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1,
    1, 1, 2, 2, 2, 1, 1, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 2, 1, 1, 1, 1, 2, 1, 2,
    1, 2, 1, 2, 1, 1, 1, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2, 2, 1, 1, 2, 1, 1, 2, 2, 1,
    1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 1, 1, 1, 1, 2,
    1, 2, 2, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1,
    1, 2, 1, 2, 2, 2, 1, 2, 2, 2, 2, 1, 1, 1, 2, 2, 2, 1, 2, 2, 2, 2, 1, 2, 1, 1,
    1, 1, 2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 2, 2, 1, 2, 1, 2,
    1, 1, 2, 2, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 2, 1, 1, 2, 1, 1, 2, 1,
    1, 2, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 1, 2, 1, 1, 1, 1, 2,
    2, 1, 1, 2, 2, 2, 2, 1, 2, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1, 1,
    2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 2,
    2, 1, 2, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 2, 2,
    2, 1, 1, 2, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1, 2, 1, 1, 2,
    2, 1, 1, 1, 2, 2, 1, 2, 1, 1, 1, 1, 2, 2, 2, 1, 2, 2, 2, 2, 2, 1, 2, 1, 1, 1,
    1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 2, 1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 2, 1,
    1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 2, 2, 1, 2, 1, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1,
    1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 2, 1, 2, 2, 1, 1, 2, 2, 2, 2, 2, 1, 2, 2,
    2, 2, 1, 2, 1, 1, 2, 2, 2, 2, 1, 2, 1, 2, 1, 1, 2, 1, 1, 1, 2, 2, 2, 2, 2, 2,
    2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 2, 1, 2, 2, 2, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1,
    1, 2, 1, 2, 1, 1, 1, 2, 2, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 2, 2, 1, 1, 2, 1, 1,
    2, 1, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 1, 2,
    1, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 2, 2, 1, 2, 1,
    1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 2, 2, 2, 2, 2, 1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2,
    1, 1, 2, 1, 2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 2,
    2, 2, 2, 1, 2, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 2, 2, 1,
    1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 2, 2, 1, 2, 1, 1, 2, 1, 1, 1, 1, 2,
    1, 2, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1,
    2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 2, 2, 2, 1, 2, 1, 2, 2, 2, 1, 2, 2, 1,
    2, 1, 2, 1, 1, 1, 1, 2, 2, 2, 1, 1, 2, 2, 1, 1, 1, 2, 2, 2, 1, 2, 1, 1, 1, 1,
    1, 2, 2, 1, 2, 2, 1, 2, 1, 1, 2, 1, 2, 2, 2, 1, 1, 1, 1, 2, 1, 2, 2, 2, 2, 2,
    2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 1, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 2, 1, 1,
    2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 1, 2, 2, 2, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 2,
    1, 2, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 1, 2, 2, 2, 1, 2, 1, 2, 1, 2, 2,
    1, 2, 1, 1, 1, 2, 2, 1, 2, 2, 1, 1, 1, 2, 2, 1, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1,
    2, 1, 1, 2, 2, 1, 1, 2, 2, 2, 1, 2, 2, 2, 2, 1, 2, 1, 1, 2, 2, 1, 2, 1, 1, 2,
    2, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 2, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 1, 1, 1, 1,
    1, 2, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 2, 2,
    2, 1, 2, 2, 1, 2, 2, 2, 1, 1, 2, 1, 2, 2, 2, 2, 2, 1, 2, 1, 1, 1, 1, 1, 2, 2,
    1, 2, 2, 1, 2, 2, 2, 2, 1, 2, 2, 1, 2, 2, 2, 2, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1,
    1, 2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 2, 1, 1, 1, 2, 2, 2, 2, 1, 2, 1, 2, 2, 2, 1,
    1, 1, 1, 1, 2, 2, 2, 2, 1, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1,
    2, 2, 1, 1, 1, 1, 1, 2, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 1, 2, 2, 2, 2,
    1, 2, 2, 1, 2, 2, 1, 1, 2, 1, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 1, 1, 1, 1,
    1, 2, 2, 2, 1, 1, 2, 2, 1, 1, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 2, 2, 1, 1, 2,
    2, 2, 1, 2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 2, 1, 1, 2, 1, 1, 2, 2, 2, 2, 1, 2, 2,
    1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1, 2, 1, 1, 2, 2, 1, 1,
    2, 2, 1, 1, 1, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1,
    1, 1, 1, 1, 2, 2, 1, 2, 1, 2, 2, 2, 1, 2, 1, 2, 2, 1, 1, 2, 1, 2, 1, 1, 1, 1,
    1, 1, 1, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 2, 1, 1, 2, 1, 1, 2, 2,
    2, 1, 2, 1, 1, 1, 2, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 2, 2, 1, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1, 1,
    2, 1, 2, 1, 2, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2, 2, 2, 1,
    2, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2, 2, 1,
    1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 2, 1, 2,
    2, 2, 2, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 2, 2, 2,
    2, 2, 1, 2, 2, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 1, 1, 1,
    2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 2, 2, 1, 2, 1, 2, 1, 1, 2, 1, 1, 2, 2, 2, 1, 2,
    2, 2, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 2, 1,
    1, 1, 2, 2, 2, 1, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 2, 2, 1, 2, 1, 1, 1, 2, 2, 1,
    2, 2, 2, 2, 1, 2, 1, 1, 1, 1, 2, 2, 1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 2, 1, 2, 1,
    1, 2, 1, 2, 2, 2, 1, 2, 1, 2, 1, 1, 2, 2, 1, 2, 2, 1, 2, 2, 1, 2, 1, 2, 2, 2,
    1, 1, 2, 2, 2, 1, 2, 1, 2, 2, 2, 2, 1, 2, 1, 1, 1, 2, 2, 2, 2, 1, 2, 1, 2, 1,
    2, 1, 1, 1, 1, 2, 1, 2, 2, 2, 1, 2, 2, 1, 2, 2, 2, 2, 1, 1, 2, 1, 1, 1, 1, 1,
    1, 1, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 2, 1, 1, 2,
    1, 2, 1, 2, 2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1, 1, 2, 1, 1, 2, 2, 2, 1,
    2, 2, 1, 2, 2, 2, 2, 1, 1, 2, 2, 1, 2, 2, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 2, 2,
    1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 1, 2, 2, 2, 2, 1, 2, 1, 2, 1, 2, 2, 1,
    1, 2, 2, 1, 1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 1, 1, 2, 2, 2, 2, 1, 2, 2, 2,
    1, 1, 1, 2, 2, 1, 2, 2, 2, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 1, 1,
    1, 1, 2, 1, 1, 2, 2, 1, 1, 2, 1, 1, 1, 2, 2, 2, 1, 2, 2, 1, 2, 1, 1, 1, 2, 1,
    2, 2, 2, 1, 2, 1, 2, 1, 2, 2, 2, 2, 2, 1, 1, 1, 2, 1, 1, 2, 2, 1, 2, 1, 1, 2,
    1, 2, 1, 2, 2, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 2, 1, 2, 1, 1, 2, 2, 1, 2, 2,
    1, 2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 2, 2, 1, 1, 2,
    2, 2, 2, 2, 2, 2, 2, 1, 2, 1, 2, 1, 2, 1, 1, 1, 2, 1, 2, 2, 2, 1, 1, 2, 2, 1,
    2, 2, 1, 2, 2, 1, 2, 1, 1, 2, 2, 1, 2, 1, 1, 2, 1, 1, 1, 2, 2, 1, 2, 2, 1, 2,
    1, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 1, 2, 2, 2, 2, 1, 2, 1, 1, 1, 2, 1, 1, 1, 2,
    1, 1, 2, 2, 1, 1, 2, 1, 2, 2, 1, 2, 1, 2, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 2, 1,
    2, 1, 1, 1, 2, 1, 2, 1, 2, 1, 1, 2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 1, 2, 2, 1, 2,
    2, 2, 2, 1, 1, 2, 2, 2, 1, 2, 1, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 2, 2, 1, 2, 2,
    2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 2, 2, 2, 1, 2, 2,
    1, 2, 1, 2, 1, 2, 2, 2, 2, 1, 1, 1, 1, 2, 1, 1, 2, 1, 2, 1, 1, 1, 2, 2, 1, 1,
    1, 1, 2, 2, 2, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1, 2, 2, 1, 2, 1, 1, 1, 1, 2, 1, 2,
    1, 2, 1, 2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 1, 2, 2,
    2, 2, 1, 2, 2, 2, 2, 1, 2, 1, 2, 2, 2, 2, 1, 1, 2, 2, 2, 1, 2, 1, 1, 2, 1, 1,
    1, 1, 2, 1, 2, 1, 2, 2, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 2,
    1, 1, 2, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1, 2, 2, 1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 1,
    2, 1, 2, 1, 2, 2, 1, 2, 1, 1, 1, 2, 2, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 2, 1,
    1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 1, 1, 2, 2, 2, 1, 2, 2, 2, 1, 2,
    1, 1, 1, 2, 2, 1, 2, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 2, 2, 1, 1, 1, 1, 2, 2,
    1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1, 1, 2, 2, 2, 2, 2, 1, 2, 1,
    1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 2, 1,
    1, 2, 1, 1, 2, 2, 2, 1, 2, 2, 1, 1, 1, 1, 1, 2, 2, 1, 2, 1, 1, 2, 2, 1, 2, 2,
    1, 2, 1, 2, 1, 2, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 1, 2, 2, 1, 1, 1, 1, 2, 2, 2,
    2, 2, 2, 2, 2, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 2, 2, 2, 2, 1, 2, 2, 2, 1,
    2, 1, 2, 1, 2, 1, 2, 2, 2, 2, 1, 2, 1, 2, 2, 2, 2, 2, 1, 2, 2, 1, 2, 2, 2, 2,
    2, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 2, 2, 1, 2, 1, 1, 2, 2, 2, 1, 2, 2, 1, 1, 1,
    1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 2, 2, 2, 2, 1, 2, 2, 2, 1, 2,
    1, 2, 1, 2, 1, 1, 2, 1, 2, 1, 2, 2, 1, 1, 1, 1, 2, 2, 1, 2, 1, 1, 1, 1, 2, 2,
    1, 1, 2, 2, 1, 1, 2, 1, 2, 2, 2, 2, 1, 1, 2, 1, 2, 1, 2, 1, 1, 2, 2, 2, 1, 1,
    2, 2, 1, 1, 1, 2, 2, 1, 2, 2, 2, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 1, 2, 2, 1, 2,
    1, 2, 2, 1, 1, 2, 2, 1, 1, 1, 2, 2, 1, 1, 2, 1, 2, 2, 1, 2, 1, 2, 2, 1, 1, 2,
    2, 2, 1, 2, 1, 2, 2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 2, 2, 2, 2, 1, 2, 2, 2, 1, 2, 1, 2, 2, 1, 1,
    2, 1, 1, 2, 2, 2, 1, 2, 1, 1, 2, 1, 1, 2, 1, 2, 1, 1, 1, 1, 2, 1, 2, 2, 1, 2,
    1, 2, 1, 1, 2, 2, 1, 1, 2, 2, 1, 1, 2, 2, 1, 2, 2, 1, 1, 1, 1, 2, 1, 1, 1, 2,
    2, 2, 2, 1, 2, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1,
    1, 2, 2, 2, 1, 2, 1, 2, 2, 1, 1, 2, 2, 2, 2, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 2,
    2, 2, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1,
    1, 1, 1, 2, 2, 1, 2, 2, 1, 2, 1, 2, 1, 1, 1, 2, 1, 1, 2, 1, 1, 2, 2, 2, 2, 2,
    2, 1, 1, 1, 2, 2, 1, 2, 1, 1, 1, 2, 2, 1, 2, 2, 1, 1, 1, 2, 2, 2, 1, 2, 1, 2,
    2, 1, 1, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 1, 2, 1,
    2, 2, 2, 1, 2, 1, 2, 2, 1, 2, 2, 2, 2, 1, 1, 1, 1, 2, 2, 1, 1, 1, 2, 2, 2, 2,
    1, 2, 1, 1, 2, 2, 1, 2, 2, 2, 1, 1, 2, 2, 2, 2, 1, 2, 1, 2, 1, 2, 2, 2, 2, 2,
    1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 2, 2, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 2,
    2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 1, 2, 2, 1, 1, 2, 2, 1, 2, 1, 1, 1, 1, 2, 2, 1,
    2, 1, 2, 2, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 1, 2, 1,
    2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 1, 1, 1, 2, 1, 2, 2, 1, 1, 2, 1, 1, 1, 2, 1,
    2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2, 1, 2, 2, 1, 2, 2, 1, 1, 2, 2, 2, 1, 1, 1, 2,
    2, 2, 2, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 2, 1, 1, 1, 2, 2, 1, 2,
    1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 2, 1, 1, 1, 2, 2), stringsAsFactors = FALSE,
    check.names = FALSE)   # planned, not committed (not replayed)
sx_pend_D <- NULL   # planned, not committed
sx_plan_splits <- data.frame(`split` = c("holdout", "cv1"), `mode` = c("holdout",
    "cv"), `repeat` = c(1, 1), `rule` = c("ceil(fraction x units) test units", "units dealt round-robin over K folds in random order; rows per fold follow the units' sizes (no row balancing is promised)"),
    stringsAsFactors = FALSE, check.names = FALSE)
sx_val_cfg <- list(holdout_fraction = 0.2, k = 2)
sx_alias <- c(v001 = "ID", v002 = "x1", v003 = "x3", v004 = "x2", v005 = "y")
sx_app_status <- "cancelled"
sx_binary <- FALSE
sx_target <- "rows"
if (sx_binary) sx_schema$performance$cols <- rbind(sx_schema$performance$cols,
    data.frame(name = c("log_loss", "Brier", "AUC"), type = "num", flags = "na tol=tol",
    stringsAsFactors = FALSE)) else sx_schema$performance$cols <- rbind(sx_schema$performance$cols,
    data.frame(name = c("RMSE", "MAE", "R2_out_of_sample"), type = "num", flags = "na tol=tol",
    stringsAsFactors = FALSE))

# ---- verification against the app's exported evidence (AUD134-11; typed and complete since v1.3.6, AUD135-01/02/04) ----
# Every check is listed in validation_check_results.csv (PASS / FAIL / NOT APPLICABLE); the script exits with status 1
# when any check fails. A check is NOT APPLICABLE only when the embedded declaration says so - an indeterminate or
# malformed comparison is a FAIL. Every evidence file is read as TEXT (no type guessing: "001" stays "001", the literal
# "NA" is text, "" is the declared missing value) and parsed by the declared field type embedded below (never inferred
# from the file under test). Numbers: finite / +Inf / -Inf / missing / malformed are distinct; signed infinities match
# only the same sign; malformed text never matches anything. Keys are length-prefixed UTF-8 (no delimiter collisions)
# and must be unique on both sides; missing / extra / duplicate rows fail.
# Values are recomputed from the reproduced fits - predictions, folds, draws, coefficients and trace by replaying the
# committed chunks; performance, stability (selection frequencies over the DECLARED candidate pool, sign stability,
# type-7 percentiles), estimands and realized sizes by independent R code from those reproduced values. The planned
# split / draw manifests and the execution ledger are metadata: verified against the plan embedded in this script.
# Tolerances: predictions / observed / metrics abs 1e-6 + rel 1e-6; log p, statistics, log-likelihoods, AIC and
# coefficient estimates abs 1e-6 + rel 1e-6 (optimizer-sensitive mixed-model fits: rel 1e-5); fractions abs 1e-12 +
# rel 1e-12; counts, statuses, indices, keys and text exact.
sx_chk <- data.frame(check = character(), status = character(), detail = character(),
    stringsAsFactors = FALSE)
sx_add_chk <- function(check, ok, detail = "", applicable = TRUE) {
  st <- if (identical(applicable, FALSE)) "NOT APPLICABLE" else if (length(ok) == 1L && isTRUE(ok)) "PASS" else "FAIL"
  sx_chk[nrow(sx_chk) + 1L, ] <<- list(check, st, as.character(detail)[1])
  invisible(st == "PASS")
}
sx_read <- function(f) if (file.exists(f)) utils::read.csv(f, colClasses = "character",
    na.strings = character(0),
  check.names = FALSE, encoding = "UTF-8", strip.white = FALSE, stringsAsFactors = FALSE) else NULL
sx_num_re <- "^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][+-]?[0-9]+)?$"
# state of each value: "num" (finite), "inf", "-inf", "na" (declared missing) or "bad" (malformed / NaN)
sx_parse_num <- function(x) {
  n <- length(x)
  if (is.numeric(x) || is.logical(x)) {
    x <- as.numeric(x)
    st <- ifelse(is.nan(x), "bad", ifelse(is.na(x), "na", ifelse(is.infinite(x),
        ifelse(x > 0, "inf", "-inf"), "num")))
    return(list(value = x, state = st))
  }
  x <- as.character(x); st <- rep("bad", n); val <- rep(NA_real_, n)
  st[is.na(x) | x == ""] <- "na"
  pinf <- !is.na(x) & x %in% c("Inf", "+Inf"); ninf <- !is.na(x) & x == "-Inf"
  st[pinf] <- "inf"; val[pinf] <- Inf; st[ninf] <- "-inf"; val[ninf] <- -Inf
  fin <- which(!is.na(x) & grepl(sx_num_re, x))
  if (length(fin)) {
    v <- suppressWarnings(as.numeric(x[fin])); nz <- grepl("[1-9]", sub("[eE].*$", "", x[fin]))
    good <- is.finite(v) & !(v == 0 & nz)            # decimal overflow / silent underflow to 0 are malformed
    st[fin[good]] <- "num"; val[fin[good]] <- v[good]
  }
  list(value = val, state = st)
}
# typed numeric equality: total (never NA); missing equals missing only if `missing`, infinities only same-sign if `inf`
sx_num_ok <- function(a, b, abs_tol, rel_tol, missing = TRUE, inf = TRUE) {
  p <- sx_parse_num(a); q <- sx_parse_num(b)
  if (length(p$state) != length(q$state)) return(FALSE)
  ok <- rep(FALSE, length(p$state))
  ok[p$state == "na" & q$state == "na"] <- isTRUE(missing)
  i <- p$state %in% c("inf", "-inf") & q$state %in% c("inf", "-inf")
  ok[i] <- isTRUE(inf) & p$state[i] == q$state[i]
  f <- p$state == "num" & q$state == "num"
  x <- p$value[f]; y <- q$value[f]; sc <- pmax(abs(x), abs(y), 1)
  ok[f] <- abs(x / sc - y / sc) <= abs_tol / sc + rel_tol * pmax(abs(x), abs(y)) / sc
  ok
}
sx_parse_int <- function(x) {
  if (is.numeric(x) || is.logical(x)) {
    x <- as.numeric(x)
    st <- ifelse(is.na(x) & !is.nan(x), "na", ifelse(!is.na(x) & is.finite(x) & x == round(x) & abs(x) <= 2^53,
        "int", "bad"))
    v <- rep(NA_character_, length(x)); v[st == "int"] <- sprintf("%.0f", x[st == "int"] + 0)
    return(list(value = v, state = st))
  }
  x <- as.character(x)
  st <- ifelse(is.na(x) | x == "", "na", ifelse(grepl("^-?(0|[1-9][0-9]{0,15})$", x), "int", "bad"))
  v <- rep(NA_character_, length(x)); v[st == "int"] <- x[st == "int"]
  list(value = v, state = st)
}
sx_int_ok <- function(a, b, missing = FALSE) {
  p <- sx_parse_int(a); q <- sx_parse_int(b)
  if (length(p$state) != length(q$state)) return(FALSE)
  ok <- p$state == "int" & q$state == "int" & p$value == q$value
  ok[is.na(ok)] <- FALSE
  ok | (p$state == "na" & q$state == "na" & isTRUE(missing))
}
sx_text_ok <- function(a, b) {     # exact UTF-8 text; a missing text value is "" (declared convention)
  a <- as.character(a); b <- as.character(b); if (length(a) != length(b)) return(FALSE)
  a[is.na(a)] <- ""; b[is.na(b)] <- ""
  enc2utf8(a) == enc2utf8(b)
}
sx_bool_ok <- function(a, b) {
  tx <- function(x) if (is.logical(x)) ifelse(is.na(x), "bad", ifelse(x, "TRUE", "FALSE")) else
    ifelse(as.character(x) %in% c("TRUE", "FALSE"), as.character(x), "bad")
  x <- tx(a); y <- tx(b); if (length(x) != length(y)) return(FALSE)
  x != "bad" & x == y
}
# length-prefixed composite key (no delimiter collision); integer keys canonical; missing / malformed keys stop
sx_key <- function(d, cols, types) {
  if (!nrow(d)) return(character())
  parts <- lapply(seq_along(cols), function(i) {
    x <- d[[cols[i]]]
    if (is.null(x)) stop("key column ", cols[i], " missing")
    if (types[i] == "int") { p <- sx_parse_int(x); if (any(p$state != "int")) stop("invalid integer key ",
        cols[i]); x <- p$value }
    else { x <- as.character(x); if (anyNA(x)) stop("missing key ", cols[i]); x <- enc2utf8(x) }
    paste0(nchar(x, type = "bytes"), ":", x, ";")
  })
  do.call(paste0, parts)
}
sx_empty <- function(cols) as.data.frame(stats::setNames(lapply(cols, function(i) character()),
    cols),
                                         stringsAsFactors = FALSE, check.names = FALSE)
sx_tol <- c(1e-6, 1e-6)
sx_tol_fit <- c(1e-6, if (sx_long()) 1e-5 else 1e-6)
sx_tol_tight <- c(1e-12, 1e-12)
# compare one exported evidence file with its reproduced / recomputed table, field by declared field
sx_compare <- function(name, file, rep, spec, skip = character()) {
  app <- sx_read(file)
  if (is.null(app)) return(invisible(sx_add_chk(paste0(name, ": file"), FALSE,
      paste("required file missing:", file))))
  cols <- spec$cols$name; types <- spec$cols$type; flags <- spec$cols$flags
  okc <- identical(names(app), cols)
  sx_add_chk(paste0(name, ": columns"), okc, if (okc) "the declared columns, in order" else
             paste("expected", paste(cols, collapse = ","), "got",
                 paste(names(app), collapse = ",")))
  if (!okc) return(invisible(FALSE))
  if (is.null(rep)) rep <- sx_empty(cols)
  lack <- setdiff(setdiff(cols, skip), names(rep))
  if (length(lack)) return(invisible(sx_add_chk(paste0(name, ": reproduced columns"), FALSE,
                                                paste("not reproduced:",
                                                    paste(lack, collapse = ", ")))))
  kt <- types[match(spec$keys, cols)]
  ka <- tryCatch(sx_key(app, spec$keys, kt), error = function(e) e)
  kr <- tryCatch(sx_key(rep, spec$keys, kt), error = function(e) e)
  if (inherits(ka, "error") || inherits(kr, "error"))
    return(invisible(sx_add_chk(paste0(name, ": keys"), FALSE, conditionMessage(if (inherits(ka,
        "error")) ka else kr))))
  sx_add_chk(paste0(name, ": unique keys (app)"), !anyDuplicated(ka), paste(sum(duplicated(ka)),
      "duplicate key(s)"))
  sx_add_chk(paste0(name, ": unique keys (reproduced)"), !anyDuplicated(kr),
      paste(sum(duplicated(kr)), "duplicate key(s)"))
  sx_add_chk(paste0(name, ": same rows"), length(ka) == length(kr) && setequal(ka, kr),
             sprintf("app %d, reproduced %d, only in app %d, only reproduced %d",
                 length(ka), length(kr),
                     length(setdiff(ka, kr)), length(setdiff(kr, ka))))
  i <- match(kr, ka); k <- !is.na(i)
  A <- app[i[k], , drop = FALSE]; R <- rep[k, , drop = FALSE]
  st <- if (!is.null(spec$status_ok) && "status" %in% names(R)) as.character(R$status) else NULL
  for (j in seq_along(cols)) {
    col <- cols[j]
    if (col %in% c(spec$keys, skip)) next
    fl <- strsplit(flags[j], " ", fixed = TRUE)[[1]]
    na_ok <- "na" %in% fl; inf_ok <- "inf" %in% fl
    need <- sub("^need=", "", fl[startsWith(fl, "need=")]); tc <- sub("^tol=",
        "", fl[startsWith(fl, "tol=")])
    a <- A[[col]]; r <- R[[col]]
    res <- tryCatch(switch(types[j],
      text = sx_text_ok(a, r), int = sx_int_ok(a, r, na_ok), bool = sx_bool_ok(a, r),
      num = { tl <- if (identical(tc, "tight")) sx_tol_tight else if (identical(tc,
          "fit")) sx_tol_fit else sx_tol
              sx_num_ok(a, r, tl[1], tl[2], na_ok, inf_ok) },
      stop("unknown declared type ", types[j])), error = function(e) FALSE)
    if (length(need) && !is.null(st) && length(res) == length(st)) {
      present <- !(sx_parse_num(a)$state %in% c("na", "bad")) & !(sx_parse_num(r)$state %in% c("na",
          "bad"))
      res[st %in% need & !present] <- FALSE
    }
    d <- if (types[j] == "num") { x <- sx_parse_num(a)$value; y <- sx_parse_num(r)$value; dd <- abs(x - y)
           if (any(is.finite(dd))) sprintf("; max |difference| %.3g",
               max(dd[is.finite(dd)])) else "" } else ""
    sx_add_chk(paste0(name, ": ", col), length(res) == nrow(A) && all(res),
               paste0(sum(!res), " of ", length(res), " row(s) differ or are invalid", d))
  }
  invisible(TRUE)
}
# same label <=> same R group (identity mapping of the app's unit keys onto the analysed data's grouping)
sx_partition_ok <- function(labels, groups) {
  a <- as.character(labels); g <- as.character(groups)
  if (anyNA(a) || anyNA(g)) return(FALSE)
  pa <- paste0(nchar(a, type = "bytes"), ":", a, ";", g)
  length(unique(pa)) == length(unique(a)) && length(unique(a)) == length(unique(g))
}
sx_pos <- function(row_id) match(as.character(row_id), rownames(sx_val_full))
sx_unit_part <- function(row_id) { p <- sx_pos(row_id)
  if (sx_long()) as.character(sx_val_full$sx_gid)[p] else ifelse(is.na(p),
      NA_character_, as.character(row_id)) }
sx_unit_clus <- function(row_id) { p <- sx_pos(row_id)
  if (sx_long() && sx_disc_has_cluster) as.character(sx_val_full$sx_cluster)[p] else ifelse(is.na(p),
      NA_character_, "") }
sx_coef_display <- function(x) vapply(as.character(x), function(nm) {
  if (is.na(nm) || !nzchar(nm)) return("")
  out <- vapply(strsplit(nm, ":", fixed = TRUE)[[1]], function(p) {
    if (p %in% c("sx_time", "sx_timef")) return("Time")
    m <- regmatches(p, regexec("^(v[0-9]{3,})(.*)$", p))[[1]]
    if (length(m) == 3 && m[2] %in% names(sx_alias)) return(paste0(sx_alias[[m[2]]],
        if (nzchar(m[3])) paste0(" [", m[3], "]") else ""))
    p }, "", USE.NAMES = FALSE)
  paste(out, collapse = " × ")
}, "", USE.NAMES = FALSE)
sx_auc2 <- function(y, p) { n1 <- sum(y == 1); n0 <- sum(y == 0); if (n1 == 0 || n0 == 0) return(NA_real_)
  r <- rank(p); (sum(r[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0) }
sx_met <- function(y, p, b, binary) {
  if (binary) { q <- pmin(pmax(p, 1e-12), 1 - 1e-12)
    return(c(log_loss = -mean(y * log(q) + (1 - y) * log(1 - q)), Brier = mean((y - p)^2),
        AUC = sx_auc2(y, p))) }
  e <- y - p; den <- sum((y - b)^2)
  c(RMSE = sqrt(mean(e^2)), MAE = mean(abs(e)), R2_out_of_sample = if (den > 0) 1 - sum(e^2) / den else NA_real_)
}
# an independent R implementation of the app's aggregation (per fold; pooled observation-weighted; group-weighted)
sx_perf <- function(P, F, binary, target) {
  if (is.null(P) || !nrow(P)) return(NULL)
  F <- F[F$status == "scored", , drop = FALSE]
  P$base <- F$train_mean[match(paste(P$split, P$fold), paste(F$split, F$fold))]
  out <- list()
  for (k in unique(paste(P$split, P$fold))) {
    g <- P[paste(P$split, P$fold) == k, , drop = FALSE]
    out[[length(out) + 1]] <- data.frame(split = g$split[1], fold = g$fold[1],
        weighting = "fold", n = nrow(g),
                                         t(sx_met(g$observed,
                                             g$predicted, g$base, binary)), check.names = FALSE)
  }
  mode <- sub("[0-9]+$", "", P$split); unit <- if (target == "cluster") "cluster" else "participant"
  for (m in unique(mode)) {
    g <- P[mode == m, , drop = FALSE]
    out[[length(out) + 1]] <- data.frame(split = m, fold = 0, weighting = "observation-weighted (pooled rows)",
                                         n = nrow(g), t(sx_met(g$observed,
                                             g$predicted, g$base, binary)), check.names = FALSE)
    if (!binary && target != "rows") {
      u <- paste(g$split, g[[unit]]); se <- tapply((g$observed - g$predicted)^2, u, mean)
      ae <- tapply(abs(g$observed - g$predicted), u, mean)
      out[[length(out) + 1]] <- data.frame(split = m, fold = 0, weighting = paste0(unit,
          "-weighted (each ", unit, " once)"),
                                           n = length(se), RMSE = sqrt(mean(se)), MAE = mean(ae), R2_out_of_sample = NA_real_,
                                           check.names = FALSE)
    }
  }
  do.call(rbind, out)
}
# AUD135-02: selection frequencies over the DECLARED pool (index / key / label from the search setup, never from
# stability.csv), denominators = committed draws / successful draws, sign stability and type-7 percentiles of the
# estimates of the draws that selected the candidate; failed draws are never zeros
sx_pool <- data.frame(index = as.numeric(sx_val_index), key = as.character(sx_val_keys),
                      label = as.character(sx_val_labels), stringsAsFactors = FALSE)
sx_q <- function(e, p) if (length(e)) stats::quantile(e, p, type = 7, names = FALSE) else NA_real_
sx_stability <- function(B) {
  if (is.null(B) || !nrow(B)) return(NULL)
  ok <- B[B$status == "fitted", , drop = FALSE]; att <- nrow(B); nok <- nrow(ok)
  do.call(rbind, lapply(seq_len(nrow(sx_pool)), function(j) {
    sel <- ok[!is.na(ok$selected_index) & as.numeric(ok$selected_index) == sx_pool$index[j],
        , drop = FALSE]
    est <- suppressWarnings(as.numeric(sel$estimate)); est <- est[!is.na(est)]
    data.frame(candidate_index = sx_pool$index[j], candidate_key = sx_pool$key[j],
        candidate = sx_pool$label[j],
               selected = nrow(sel), attempted = att, successful = nok,
               freq_of_attempted = if (att) nrow(sel) / att else NA_real_,
               freq_of_successful = if (nok) nrow(sel) / nok else NA_real_,
               flagged_fits = sum(as.character(sel$diagnostics) != "clean"),
               coefficient = if (nrow(sel)) sx_coef_display(sel$coefficient[1]) else "",
               positive_sign = if (length(est)) mean(est > 0) else NA_real_, `estimate_p2.5` = sx_q(est,
                   0.025),
               estimate_median = if (length(est)) stats::median(est) else NA_real_, `estimate_p97.5` = sx_q(est,
                   0.975),
               check.names = FALSE, stringsAsFactors = FALSE)
  }))
}
sx_estimands <- function(B, C) {
  if (is.null(C) || !nrow(C)) return(NULL)
  ok <- B[B$status == "fitted", , drop = FALSE]
  g <- unique(C[, c("selected_index", "coefficient")])
  do.call(rbind, lapply(seq_len(nrow(g)), function(j) {
    ix <- as.numeric(g$selected_index[j]); cf <- g$coefficient[j]
    r <- C[as.numeric(C$selected_index) == ix & C$coefficient == cf, , drop = FALSE]
    est <- suppressWarnings(as.numeric(r$estimate)); est <- est[!is.na(est)]
    data.frame(candidate_index = ix, candidate = sx_pool$label[match(ix,
        sx_pool$index)], term = r$term[1],
               coefficient = cf, coefficient_label = sx_coef_display(cf),
               draws_selected = sum(!is.na(ok$selected_index) & as.numeric(ok$selected_index) == ix),
               draws_with_estimate = length(est), positive_sign = if (length(est)) mean(est > 0) else NA_real_,
               `estimate_p2.5` = sx_q(est, 0.025), estimate_median = if (length(est)) stats::median(est) else NA_real_,
               `estimate_p97.5` = sx_q(est, 0.975), check.names = FALSE, stringsAsFactors = FALSE)
  }))
}
# coefficient identity: every coefficient row belongs to a fitted draw of the same selected candidate, with the
# declared key, one term per (candidate, coefficient), and n_coef rows per draw
sx_coef_identity <- function(B, C) {
  if (is.null(C) || !nrow(C)) return(is.null(B) || !nrow(B) || all(as.numeric(B$n_coef[B$status == "fitted"]) == 0))
  ok <- B[B$status == "fitted", , drop = FALSE]; i <- match(C$b, ok$b)
  if (anyNA(i) || any(as.numeric(C$selected_index) != as.numeric(ok$selected_index[i]))) return(FALSE)
  if (any(C$selected_key != sx_pool$key[match(as.numeric(C$selected_index),
      sx_pool$index)])) return(FALSE)
  terms <- tapply(C$term, paste(C$selected_index, C$coefficient), function(t) length(unique(t)))
  n <- table(factor(C$b, levels = ok$b))
  all(terms == 1) && all(as.numeric(n) == as.numeric(ok$n_coef))
}
sx_realized <- function(M) {
  if (is.null(M) || !nrow(M)) return(NULL)
  unit <- if (sx_target == "rows") as.character(M$row_id) else if (sx_target == "cluster") sx_unit_clus(M$row_id) else
    sx_unit_part(M$row_id)
  out <- list()
  for (s in sx_plan_splits$split) {
    w <- M$split == s; f <- as.numeric(M$fold[w]); u <- unit[w]; md <- sx_plan_splits$mode[sx_plan_splits$split == s]
    n_all <- if (sx_target == "rows") length(u) else length(unique(u))
    for (k in sort(unique(f[f > 0]))) {
      te <- f == k; nu <- if (sx_target == "rows") sum(te) else length(unique(u[te]))
      out[[length(out) + 1]] <- data.frame(split = s, mode = md, fold = k,
        requested_fraction = if (md == "holdout") sx_val_cfg$holdout_fraction else 1 / sx_val_cfg$k,
        test_units = nu, units = n_all, realized_unit_fraction = if (n_all) nu / n_all else NA_real_,
        test_rows = sum(te), rows = length(f), realized_row_fraction = if (length(f)) sum(te) / length(f) else NA_real_,
        rule = sx_plan_splits$rule[sx_plan_splits$split == s], stringsAsFactors = FALSE)
    }
  }
  do.call(rbind, out)
}
# ---- required files (declared by the app from the validation's modes, embedded above) ----
for (i in seq_len(nrow(sx_expect))) {
  f <- sx_expect$file[i]
  if (!sx_expect$required[i]) { sx_add_chk(paste0("file ", f), TRUE, "not applicable to this validation",
      applicable = FALSE); next }
  ok <- file.exists(f)
  sx_add_chk(paste0("file ", f), ok, if (ok) "present" else "REQUIRED reference file missing")
  if (ok) { n <- nrow(sx_read(f)); sx_add_chk(paste0("file ", f, ": rows"), n == sx_expect$rows[i],
                                               sprintf("%d rows, expected %d",
                                                   n, sx_expect$rows[i])) }
}
sx_has <- function(f) any(sx_expect$file == f & sx_expect$required)
# ---- execution scope (AUD135-04): the ledger, and replayed = committed ----
sx_compare("execution ledger", "execution_ledger.csv", sx_ledger, sx_schema$ledger)
sx_rep_parts <- c(if (!is.null(sx_F)) paste0(sx_F$split, ":fold", sx_F$fold),
    if (!is.null(sx_B)) paste0("boot", sx_B$b))
sx_rep_status <- c(if (!is.null(sx_F)) as.character(sx_F$status), if (!is.null(sx_B)) as.character(sx_B$status))
sx_com <- sx_ledger[sx_ledger$committed, , drop = FALSE]
sx_add_chk("replay scope: the replayed parts are exactly the committed parts",
    setequal(sx_rep_parts, sx_com$part) &&
           length(sx_rep_parts) == nrow(sx_com), sprintf("replayed %d, committed %d",
               length(sx_rep_parts), nrow(sx_com)))
sx_add_chk("replay scope: replayed statuses equal the committed statuses",
           identical(unname(sx_rep_status[match(sx_com$part, sx_rep_parts)]),
               as.character(sx_com$status)),
           "status of every committed part")
# ---- planned manifests: committed parts from the replayed chunk code, pending parts from the embedded plan ----
if (sx_has("split_manifest.csv")) {
  M <- rbind(if (!is.null(sx_M)) sx_M[, c("split", "row_id", "fold")], sx_pend_M)
  if (!is.null(M) && nrow(M)) {
    M$mode <- sx_plan_splits$mode[match(M$split, sx_plan_splits$split)]
    M$`repeat` <- sx_plan_splits$`repeat`[match(M$split, sx_plan_splits$split)]
  }
  sx_compare("split manifest", "split_manifest.csv", M, sx_schema$manifest,
      skip = c("participant", "cluster"))
  app <- sx_read("split_manifest.csv")
  if (!is.null(app) && nrow(app)) {
    sx_add_chk("split manifest: every row is an analysed row", !anyNA(sx_pos(app$row_id)),
        "row_id in the analysed data")
    sx_add_chk("split manifest: participant keys identify the analysed participants",
               sx_partition_ok(app$participant, sx_unit_part(app$row_id)), "same key <=> same participant in R")
    sx_add_chk("split manifest: cluster keys identify the analysed clusters",
               sx_partition_ok(app$cluster, sx_unit_clus(app$row_id)), "same key <=> same cluster in R")
    sx_M_all <- M
  } else sx_M_all <- NULL
} else sx_M_all <- NULL
if (sx_has("bootstrap_draws.csv")) {
  D <- rbind(if (!is.null(sx_D)) sx_D, sx_pend_D)
  sx_compare("bootstrap draw manifest", "bootstrap_draws.csv", D, sx_schema$draws,
             skip = c("original_participant", "original_cluster"))
  app <- sx_read("bootstrap_draws.csv")
  if (!is.null(app) && nrow(app)) {
    sx_add_chk("bootstrap draw manifest: every row is an analysed row", !anyNA(sx_pos(app$row_id)),
        "row_id")
    sx_add_chk("bootstrap draw manifest: original participant keys identify the analysed participants",
               sx_partition_ok(app$original_participant, sx_unit_part(app$row_id)), "same key <=> same participant")
    sx_add_chk("bootstrap draw manifest: original cluster keys identify the analysed clusters",
               sx_partition_ok(app$original_cluster, sx_unit_clus(app$row_id)), "same key <=> same cluster")
    man <- sx_read("split_manifest.csv")
    if (!is.null(man) && nrow(man)) {
      j <- match(app$row_id, man$row_id)
      sx_add_chk("bootstrap draw manifest: original keys equal the split manifest's keys of the same rows",
                 !anyNA(j) && identical(app$original_participant, man$participant[j]) &&
                   identical(app$original_cluster, man$cluster[j]), "cross-file identity")
    }
  }
}
# ---- reproduced results ----
if (sx_has("predictions.csv")) sx_compare("predictions", "predictions.csv", sx_P,
    sx_schema$predictions)
if (sx_has("folds.csv")) {
  Fr <- sx_F
  if (!is.null(Fr) && nrow(Fr)) { Fr$mode <- sx_plan_splits$mode[match(Fr$split,
      sx_plan_splits$split)]
    Fr$`repeat` <- sx_plan_splits$`repeat`[match(Fr$split, sx_plan_splits$split)] }
  sx_compare("folds", "folds.csv", Fr, sx_schema$folds)
}
if (sx_has("performance.csv"))
  sx_compare("performance (recomputed in R from the reproduced predictions)", "performance.csv",
             sx_perf(sx_P, sx_F, sx_binary, sx_target), sx_schema$performance)
if (sx_has("realized_sizes.csv"))
  sx_compare("realized sizes (recomputed from the verified plan and the analysed units)",
      "realized_sizes.csv",
             sx_realized(sx_M_all), sx_schema$realized)
if (sx_has("bootstrap_results.csv")) {
  Br <- sx_B
  if (!is.null(Br) && nrow(Br)) Br$coefficient_label <- sx_coef_display(Br$coefficient)
  sx_compare("bootstrap draws", "bootstrap_results.csv", Br, sx_schema$bootstrap)
}
if (sx_has("bootstrap_coefficients.csv")) {
  sx_compare("bootstrap coefficients", "bootstrap_coefficients.csv", sx_C, sx_schema$coefs)
  sx_add_chk("bootstrap coefficients: identity (draw, selected candidate, declared key, term, n_coef)",
             isTRUE(tryCatch(sx_coef_identity(sx_B, sx_C), error = function(e) FALSE)), "reproduced coefficients")
}
if (sx_has("stability.csv"))
  sx_compare("stability (recomputed from the reproduced draws and the declared pool)",
      "stability.csv",
             sx_stability(sx_B), sx_schema$stability)
if (sx_has("bootstrap_estimands.csv"))
  sx_compare("bootstrap estimands (recomputed from the reproduced coefficients)",
      "bootstrap_estimands.csv",
             sx_estimands(sx_B, sx_C), sx_schema$estimands)
if (sx_has("candidate_trace.csv")) sx_compare("candidate trace", "candidate_trace.csv",
    sx_T, sx_schema$trace)
utils::write.csv(sx_chk, "validation_check_results.csv", row.names = FALSE)
sx_fail <- sx_chk$status == "FAIL"
print(sx_chk[sx_chk$status != "PASS", , drop = FALSE], row.names = FALSE)
sx_n_plan <- nrow(sx_ledger); sx_n_com <- sum(sx_ledger$committed)
cat(sprintf("Execution coverage: %d of %d planned parts committed and replayed; %d not run; %d dispatched without a validated response (not reproducible).\n",
            sx_n_com, sx_n_plan, sum(sx_ledger$status == "not_run"), sum(sx_ledger$status == "uncommitted")))
if (any(sx_fail)) {
  msg <- paste0("VERIFICATION FAILED: ", sum(sx_fail), " of ", nrow(sx_chk),
      " checks (see validation_check_results.csv): ",
                paste(utils::head(sx_chk$check[sx_fail], 5), collapse = "; "))
  if (interactive()) stop(msg, call. = FALSE) else { message(msg); quit(save = "no", status = 1) }
}
if (!is.null(sx_P)) cat("Predictions reproduced:", nrow(sx_P), "held-out rows.\n")
if (!is.null(sx_B)) cat("Bootstrap selections reproduced:", nrow(sx_B), "draws.\n")
cat(sprintf("All %d checks passed (%d not applicable).\n", sum(sx_chk$status == "PASS"),
    sum(sx_chk$status == "NOT APPLICABLE")))
cat(if (identical(sx_app_status, "complete") && sx_n_com == sx_n_plan) "The complete validation was reproduced.\n" else
    paste0("The export is ", toupper(sx_app_status), ": only its ", sx_n_com,
        " committed part(s) of ", sx_n_plan,
           " planned were reproduced; this is not a reproduction of a complete validation.\n"))

