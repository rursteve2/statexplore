Validation status: CANCELLED (2 planned part(s) not run)
Target: New independent observations — rows are the sampling units (only for searches without repeated measures).
Procedure: Whole selection pipeline (search repeated inside each training part); selection rule: Smallest training p-value (natural-log tail) of the candidate's primary test (the search's discovery ranking); exact ties: lower candidate index.
Candidate pool: the whole declared search space (3 candidates).
Search: 4cbc6f292e14 (fit identity d3ce1fe4e7954ea7…); validation run 13d3973deda2.
Modes: Holdout, Grouped K-fold cross-validation; holdout 20%, K = 2, repeats = 1, B = 200, seed = 11.
Execution: 1 of 3 planned parts committed (1 of 2 chunks); 2 not run.
This is a predictive check of the stated target, separate from the discovery p-values; it is not a confirmatory test, and bootstrap selection frequencies are not probabilities that a hypothesis is true.

Files: validation_reproduce.R (complete reproduction with self-checks, only with verified data), execution_ledger.csv (planned / committed / not run parts), candidate_trace.csv (every candidate in every training part / draw), bootstrap_estimands.csv, realized_sizes.csv, split_manifest.csv (the PLANNED fold of every analysed row per split; fold 0 = training only), bootstrap_draws.csv (planned draws: draw IDs and original IDs), predictions.csv (held-out rows), folds.csv, performance.csv, stability.csv, validation_code.R, bundle_inventory.json.
