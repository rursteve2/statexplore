StatExplore reproducibility bundle (1.3.6 (commit 090d120e691f))

Run in R (no network needed):  Rscript validation_reproduce.R   (from this folder), or source("validation_reproduce.R") from anywhere.
Data: validation_reproduce_data.csv (included: analysis columns only, exported with your consent)
R packages used by this script: Matrix, detectseparation, geepack, lme4, mmrm, nlme, nnet, ordinal
The script stops with a message if the data file differs from the exported one, if the analysed rows, outcome coding, design or grouping differ from the recorded model, or if n / logLik / AIC / BIC are not reproduced within abs 1e-4 + rel 1e-6.
Results and metadata in this folder are not anonymized. Treat the data file with the same care as the original data.
