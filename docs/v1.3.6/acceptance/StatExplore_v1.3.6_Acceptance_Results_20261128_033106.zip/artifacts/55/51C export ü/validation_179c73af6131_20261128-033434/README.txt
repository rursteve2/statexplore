Validation status: COMPLETE
Target: New clusters (e.g. new schools) — whole clusters with all their participants are held out; predictions use fixed effects only.
Procedure: Whole selection pipeline (search repeated inside each training part); selection rule: Smallest training p-value (natural-log tail) of the candidate's primary test (the search's discovery ranking); exact ties: lower candidate index.
Candidate pool: the whole declared search space (18 candidates).
Search: 0214a3e584a5 (fit identity 6f8776ab160dd3a3…); validation run 179c73af6131.
Modes: Bootstrap stability; holdout 20%, K = 5, repeats = 1, B = 20, seed = 133.
Execution: 20 of 20 planned parts committed (2 of 2 chunks).
This is a predictive check of the stated target, separate from the discovery p-values; it is not a confirmatory test, and bootstrap selection frequencies are not probabilities that a hypothesis is true.

Files: validation_reproduce.R (complete reproduction with self-checks, only with verified data), execution_ledger.csv (planned / committed / not run parts), candidate_trace.csv (every candidate in every training part / draw), bootstrap_estimands.csv, realized_sizes.csv, split_manifest.csv (the PLANNED fold of every analysed row per split; fold 0 = training only), bootstrap_draws.csv (planned draws: draw IDs and original IDs), predictions.csv (held-out rows), folds.csv, performance.csv, stability.csv, validation_code.R, bundle_inventory.json.
