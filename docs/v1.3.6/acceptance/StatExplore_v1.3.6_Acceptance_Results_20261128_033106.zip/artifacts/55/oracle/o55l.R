d <- utils::read.csv("C:/Users/Stephen/AppData/Local/Temp/sx_acceptance_20261128_033106_qsl6ho0s/inputs/StatExplore_Test55L_LegacyUnderflow.csv")
one <- function(a, b) { f1 <- stats::lm(stats::reformulate(c(a, b, paste0(a, ":", b)), "y"), d)
  f0 <- stats::lm(stats::reformulate(c(a, b), "y"), d); A <- stats::anova(f0, f1)
  stats::pf(A$F[2], A$Df[2], A$Res.Df[2], lower.tail = FALSE, log.p = TRUE) / log(10) }
cat(sprintf("%.10f", c(one("x1", "x3"), one("x1", "x2"), one("x3", "x2"))), sep = "\n")