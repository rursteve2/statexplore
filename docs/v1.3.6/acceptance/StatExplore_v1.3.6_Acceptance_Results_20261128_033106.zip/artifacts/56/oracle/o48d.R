suppressMessages(library(geepack))
d <- read.csv("C:/Users/Stephen/AppData/Local/Temp/sx_acceptance_20261128_033106_qsl6ho0s/inputs/StatExplore_Test48D_GEE.csv"); d <- d[order(d$ID, d$TIME), ]
d$occ <- as.integer(factor(d$TIME)); out <- NULL
for (cs in c("independence", "exchangeable", "ar1")) {
  m <- geeglm(Y ~ TIME * X, id = ID, waves = occ, corstr = cs, data = d, family = gaussian()); q <- QIC(m)
  out <- rbind(out, data.frame(corstr = m$corstr, QIC = q[["QIC"]], QICu = q[["QICu"]], CIC = q[["CIC"]]))
}
write.csv(out, "gee.csv", row.names = FALSE)