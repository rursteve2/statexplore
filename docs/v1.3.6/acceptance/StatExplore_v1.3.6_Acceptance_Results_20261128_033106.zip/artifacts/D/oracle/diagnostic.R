sx_long <- function() FALSE
sx_disc_has_cluster <- FALSE
sx_val_index <- c(0); sx_val_keys <- c("candidate0"); sx_val_labels <- c("candidate 0")
sx_val_full <- data.frame(y = 1:20, row.names = as.character(1:20))
sx_alias <- character()
# ---- StatExplore: discovery helpers ----
# Fit one candidate's full model once, then evaluate each planned hypothesis as a nested
# comparison with a reduced model (tests[[1]] is the candidate's declared focal test).
# v1.3.4 (V134-001 / V134-012): fit statistics are cached only under a FIT KEY that proves what was fitted - the
# content of every column the model uses (response, design variables, grouping, time, occasion) in the exact row order
# with the row identities, plus the estimation context (family, structure, cluster, REML/ML, GEE family and working
# correlation, optimizer rules) and the sample context set by the caller. Row names, counts or formulas alone never
# justify reuse; validation resets the cache for every training part and bootstrap draw (sx_cache_reset).
# AUD134-01: the primary-test score shared by EVERY selection path (AMD validation and the legacy stability / procedure
# CV): the natural-log upper tail of tests[[1]], taken from the test distribution itself (log.p = TRUE). NA when the fit
# is not ok / warning, the test was withheld or has no p: never log(0) and never a substituted value.
sx_primary_logp <- function(r) {
  if (is.null(r) || !(r$status %in% c("ok", "warning")) || !length(r$tests)) return(NA_real_)
  t1 <- r$tests[[1]]
  if (!is.null(t1$withheld) || is.null(t1$log_p) || !length(t1$log_p)) return(NA_real_)
  as.numeric(t1$log_p)[1]
}
# argmin with the declared tie rule: the smallest score wins; exact ties -> the lower candidate position; NA never wins
sx_select_min <- function(score) {
  ok <- which(!is.na(score))
  if (!length(ok)) NA_integer_ else ok[which.min(score[ok])]
}
# AUD134-10: hard budget of model-fitting invocations (validation sets a finite cap per chunk). Every call of a model
# fitter counts - full, reduced, null and selected refits - each optimizer retry counts as one more, and so do the
# auxiliary fits (binary separation check, GEE QIC independence refit). Cache hits are counted apart and cost nothing.


# ---- verification against the app's exported evidence (AUD134-11; typed and complete since v1.3.6, AUD135-01/02/04) ----
# Every check is listed in validation_check_results.csv (PASS / FAIL / NOT APPLICABLE); the script exits with status 1
# when any check fails. A check is NOT APPLICABLE only when the embedded declaration says so - an indeterminate or
# malformed comparison is a FAIL. Every evidence file is read as TEXT (no type guessing: "001" stays "001", the literal
# "NA" is text, "" is the declared missing value) and parsed by the declared field type embedded below (never inferred
# from the file under test). Numbers: finite / +Inf / -Inf / missing / malformed are distinct; signed infinities match
# only the same sign; malformed text never matches anything. Keys are length-prefixed UTF-8 (no delimiter collisions)
# and must be unique on both sides; missing / extra / duplicate rows fail.
# Values are recomputed from the reproduced fits - predictions, folds, draws, coefficients and trace by replaying the
# committed chunks; performance, stability (selection frequencies over the DECLARED candidate pool, sign stability,
# type-7 percentiles), estimands and realized sizes by independent R code from those reproduced values. The planned
# split / draw manifests and the execution ledger are metadata: verified against the plan embedded in this script.
# Tolerances: predictions / observed / metrics abs 1e-6 + rel 1e-6; log p, statistics, log-likelihoods, AIC and
# coefficient estimates abs 1e-6 + rel 1e-6 (optimizer-sensitive mixed-model fits: rel 1e-5); fractions abs 1e-12 +
# rel 1e-12; counts, statuses, indices, keys and text exact.
sx_chk <- data.frame(check = character(), status = character(), detail = character(), stringsAsFactors = FALSE)
sx_add_chk <- function(check, ok, detail = "", applicable = TRUE) {
  st <- if (identical(applicable, FALSE)) "NOT APPLICABLE" else if (length(ok) == 1L && isTRUE(ok)) "PASS" else "FAIL"
  sx_chk[nrow(sx_chk) + 1L, ] <<- list(check, st, as.character(detail)[1])
  invisible(st == "PASS")
}
sx_read <- function(f) if (file.exists(f)) utils::read.csv(f, colClasses = "character", na.strings = character(0),
  check.names = FALSE, encoding = "UTF-8", strip.white = FALSE, stringsAsFactors = FALSE) else NULL
sx_num_re <- "^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][+-]?[0-9]+)?$"
# state of each value: "num" (finite), "inf", "-inf", "na" (declared missing) or "bad" (malformed / NaN)
sx_parse_num <- function(x) {
  n <- length(x)
  if (is.numeric(x) || is.logical(x)) {
    x <- as.numeric(x)
    st <- ifelse(is.nan(x), "bad", ifelse(is.na(x), "na", ifelse(is.infinite(x), ifelse(x > 0, "inf", "-inf"), "num")))
    return(list(value = x, state = st))
  }
  x <- as.character(x); st <- rep("bad", n); val <- rep(NA_real_, n)
  st[is.na(x) | x == ""] <- "na"
  pinf <- !is.na(x) & x %in% c("Inf", "+Inf"); ninf <- !is.na(x) & x == "-Inf"
  st[pinf] <- "inf"; val[pinf] <- Inf; st[ninf] <- "-inf"; val[ninf] <- -Inf
  fin <- which(!is.na(x) & grepl(sx_num_re, x))
  if (length(fin)) {
    v <- suppressWarnings(as.numeric(x[fin])); nz <- grepl("[1-9]", sub("[eE].*$", "", x[fin]))
    good <- is.finite(v) & !(v == 0 & nz)            # decimal overflow / silent underflow to 0 are malformed
    st[fin[good]] <- "num"; val[fin[good]] <- v[good]
  }
  list(value = val, state = st)
}
# typed numeric equality: total (never NA); missing equals missing only if `missing`, infinities only same-sign if `inf`
sx_num_ok <- function(a, b, abs_tol, rel_tol, missing = TRUE, inf = TRUE) {
  p <- sx_parse_num(a); q <- sx_parse_num(b)
  if (length(p$state) != length(q$state)) return(FALSE)
  ok <- rep(FALSE, length(p$state))
  ok[p$state == "na" & q$state == "na"] <- isTRUE(missing)
  i <- p$state %in% c("inf", "-inf") & q$state %in% c("inf", "-inf")
  ok[i] <- isTRUE(inf) & p$state[i] == q$state[i]
  f <- p$state == "num" & q$state == "num"
  x <- p$value[f]; y <- q$value[f]; sc <- pmax(abs(x), abs(y), 1)
  ok[f] <- abs(x / sc - y / sc) <= abs_tol / sc + rel_tol * pmax(abs(x), abs(y)) / sc
  ok
}
sx_parse_int <- function(x) {
  if (is.numeric(x) || is.logical(x)) {
    x <- as.numeric(x)
    st <- ifelse(is.na(x) & !is.nan(x), "na", ifelse(!is.na(x) & is.finite(x) & x == round(x) & abs(x) <= 2^53, "int", "bad"))
    v <- rep(NA_character_, length(x)); v[st == "int"] <- sprintf("%.0f", x[st == "int"] + 0)
    return(list(value = v, state = st))
  }
  x <- as.character(x)
  st <- ifelse(is.na(x) | x == "", "na", ifelse(grepl("^-?(0|[1-9][0-9]{0,15})$", x), "int", "bad"))
  v <- rep(NA_character_, length(x)); v[st == "int"] <- x[st == "int"]
  list(value = v, state = st)
}
sx_int_ok <- function(a, b, missing = FALSE) {
  p <- sx_parse_int(a); q <- sx_parse_int(b)
  if (length(p$state) != length(q$state)) return(FALSE)
  ok <- p$state == "int" & q$state == "int" & p$value == q$value
  ok[is.na(ok)] <- FALSE
  ok | (p$state == "na" & q$state == "na" & isTRUE(missing))
}
sx_text_ok <- function(a, b) {     # exact UTF-8 text; a missing text value is "" (declared convention)
  a <- as.character(a); b <- as.character(b); if (length(a) != length(b)) return(FALSE)
  a[is.na(a)] <- ""; b[is.na(b)] <- ""
  enc2utf8(a) == enc2utf8(b)
}
sx_bool_ok <- function(a, b) {
  tx <- function(x) if (is.logical(x)) ifelse(is.na(x), "bad", ifelse(x, "TRUE", "FALSE")) else
    ifelse(as.character(x) %in% c("TRUE", "FALSE"), as.character(x), "bad")
  x <- tx(a); y <- tx(b); if (length(x) != length(y)) return(FALSE)
  x != "bad" & x == y
}
# length-prefixed composite key (no delimiter collision); integer keys canonical; missing / malformed keys stop
sx_key <- function(d, cols, types) {
  if (!nrow(d)) return(character())
  parts <- lapply(seq_along(cols), function(i) {
    x <- d[[cols[i]]]
    if (is.null(x)) stop("key column ", cols[i], " missing")
    if (types[i] == "int") { p <- sx_parse_int(x); if (any(p$state != "int")) stop("invalid integer key ", cols[i]); x <- p$value }
    else { x <- as.character(x); if (anyNA(x)) stop("missing key ", cols[i]); x <- enc2utf8(x) }
    paste0(nchar(x, type = "bytes"), ":", x, ";")
  })
  do.call(paste0, parts)
}
sx_empty <- function(cols) as.data.frame(stats::setNames(lapply(cols, function(i) character()), cols),
                                         stringsAsFactors = FALSE, check.names = FALSE)
sx_tol <- c(1e-6, 1e-6)
sx_tol_fit <- c(1e-6, if (sx_long()) 1e-5 else 1e-6)
sx_tol_tight <- c(1e-12, 1e-12)
# compare one exported evidence file with its reproduced / recomputed table, field by declared field
sx_compare <- function(name, file, rep, spec, skip = character()) {
  app <- sx_read(file)
  if (is.null(app)) return(invisible(sx_add_chk(paste0(name, ": file"), FALSE, paste("required file missing:", file))))
  cols <- spec$cols$name; types <- spec$cols$type; flags <- spec$cols$flags
  okc <- identical(names(app), cols)
  sx_add_chk(paste0(name, ": columns"), okc, if (okc) "the declared columns, in order" else
             paste("expected", paste(cols, collapse = ","), "got", paste(names(app), collapse = ",")))
  if (!okc) return(invisible(FALSE))
  if (is.null(rep)) rep <- sx_empty(cols)
  lack <- setdiff(setdiff(cols, skip), names(rep))
  if (length(lack)) return(invisible(sx_add_chk(paste0(name, ": reproduced columns"), FALSE,
                                                paste("not reproduced:", paste(lack, collapse = ", ")))))
  kt <- types[match(spec$keys, cols)]
  ka <- tryCatch(sx_key(app, spec$keys, kt), error = function(e) e)
  kr <- tryCatch(sx_key(rep, spec$keys, kt), error = function(e) e)
  if (inherits(ka, "error") || inherits(kr, "error"))
    return(invisible(sx_add_chk(paste0(name, ": keys"), FALSE, conditionMessage(if (inherits(ka, "error")) ka else kr))))
  sx_add_chk(paste0(name, ": unique keys (app)"), !anyDuplicated(ka), paste(sum(duplicated(ka)), "duplicate key(s)"))
  sx_add_chk(paste0(name, ": unique keys (reproduced)"), !anyDuplicated(kr), paste(sum(duplicated(kr)), "duplicate key(s)"))
  sx_add_chk(paste0(name, ": same rows"), length(ka) == length(kr) && setequal(ka, kr),
             sprintf("app %d, reproduced %d, only in app %d, only reproduced %d", length(ka), length(kr),
                     length(setdiff(ka, kr)), length(setdiff(kr, ka))))
  i <- match(kr, ka); k <- !is.na(i)
  A <- app[i[k], , drop = FALSE]; R <- rep[k, , drop = FALSE]
  st <- if (!is.null(spec$status_ok) && "status" %in% names(R)) as.character(R$status) else NULL
  for (j in seq_along(cols)) {
    col <- cols[j]
    if (col %in% c(spec$keys, skip)) next
    fl <- strsplit(flags[j], " ", fixed = TRUE)[[1]]
    na_ok <- "na" %in% fl; inf_ok <- "inf" %in% fl
    need <- sub("^need=", "", fl[startsWith(fl, "need=")]); tc <- sub("^tol=", "", fl[startsWith(fl, "tol=")])
    a <- A[[col]]; r <- R[[col]]
    res <- tryCatch(switch(types[j],
      text = sx_text_ok(a, r), int = sx_int_ok(a, r, na_ok), bool = sx_bool_ok(a, r),
      num = { tl <- if (identical(tc, "tight")) sx_tol_tight else if (identical(tc, "fit")) sx_tol_fit else sx_tol
              sx_num_ok(a, r, tl[1], tl[2], na_ok, inf_ok) },
      stop("unknown declared type ", types[j])), error = function(e) FALSE)
    if (length(need) && !is.null(st) && length(res) == length(st)) {
      present <- !(sx_parse_num(a)$state %in% c("na", "bad")) & !(sx_parse_num(r)$state %in% c("na", "bad"))
      res[st %in% need & !present] <- FALSE
    }
    d <- if (types[j] == "num") { x <- sx_parse_num(a)$value; y <- sx_parse_num(r)$value; dd <- abs(x - y)
           if (any(is.finite(dd))) sprintf("; max |difference| %.3g", max(dd[is.finite(dd)])) else "" } else ""
    sx_add_chk(paste0(name, ": ", col), length(res) == nrow(A) && all(res),
               paste0(sum(!res), " of ", length(res), " row(s) differ or are invalid", d))
  }
  invisible(TRUE)
}
# same label <=> same R group (identity mapping of the app's unit keys onto the analysed data's grouping)
sx_partition_ok <- function(labels, groups) {
  a <- as.character(labels); g <- as.character(groups)
  if (anyNA(a) || anyNA(g)) return(FALSE)
  pa <- paste0(nchar(a, type = "bytes"), ":", a, ";", g)
  length(unique(pa)) == length(unique(a)) && length(unique(a)) == length(unique(g))
}
sx_pos <- function(row_id) match(as.character(row_id), rownames(sx_val_full))
sx_unit_part <- function(row_id) { p <- sx_pos(row_id)
  if (sx_long()) as.character(sx_val_full$sx_gid)[p] else ifelse(is.na(p), NA_character_, as.character(row_id)) }
sx_unit_clus <- function(row_id) { p <- sx_pos(row_id)
  if (sx_long() && sx_disc_has_cluster) as.character(sx_val_full$sx_cluster)[p] else ifelse(is.na(p), NA_character_, "") }
sx_coef_display <- function(x) vapply(as.character(x), function(nm) {
  if (is.na(nm) || !nzchar(nm)) return("")
  out <- vapply(strsplit(nm, ":", fixed = TRUE)[[1]], function(p) {
    if (p %in% c("sx_time", "sx_timef")) return("Time")
    m <- regmatches(p, regexec("^(v[0-9]{3,})(.*)$", p))[[1]]
    if (length(m) == 3 && m[2] %in% names(sx_alias)) return(paste0(sx_alias[[m[2]]], if (nzchar(m[3])) paste0(" [", m[3], "]") else ""))
    p }, "", USE.NAMES = FALSE)
  paste(out, collapse = " × ")
}, "", USE.NAMES = FALSE)
sx_auc2 <- function(y, p) { n1 <- sum(y == 1); n0 <- sum(y == 0); if (n1 == 0 || n0 == 0) return(NA_real_)
  r <- rank(p); (sum(r[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0) }
sx_met <- function(y, p, b, binary) {
  if (binary) { q <- pmin(pmax(p, 1e-12), 1 - 1e-12)
    return(c(log_loss = -mean(y * log(q) + (1 - y) * log(1 - q)), Brier = mean((y - p)^2), AUC = sx_auc2(y, p))) }
  e <- y - p; den <- sum((y - b)^2)
  c(RMSE = sqrt(mean(e^2)), MAE = mean(abs(e)), R2_out_of_sample = if (den > 0) 1 - sum(e^2) / den else NA_real_)
}
# an independent R implementation of the app's aggregation (per fold; pooled observation-weighted; group-weighted)
sx_perf <- function(P, F, binary, target) {
  if (is.null(P) || !nrow(P)) return(NULL)
  F <- F[F$status == "scored", , drop = FALSE]
  P$base <- F$train_mean[match(paste(P$split, P$fold), paste(F$split, F$fold))]
  out <- list()
  for (k in unique(paste(P$split, P$fold))) {
    g <- P[paste(P$split, P$fold) == k, , drop = FALSE]
    out[[length(out) + 1]] <- data.frame(split = g$split[1], fold = g$fold[1], weighting = "fold", n = nrow(g),
                                         t(sx_met(g$observed, g$predicted, g$base, binary)), check.names = FALSE)
  }
  mode <- sub("[0-9]+$", "", P$split); unit <- if (target == "cluster") "cluster" else "participant"
  for (m in unique(mode)) {
    g <- P[mode == m, , drop = FALSE]
    out[[length(out) + 1]] <- data.frame(split = m, fold = 0, weighting = "observation-weighted (pooled rows)",
                                         n = nrow(g), t(sx_met(g$observed, g$predicted, g$base, binary)), check.names = FALSE)
    if (!binary && target != "rows") {
      u <- paste(g$split, g[[unit]]); se <- tapply((g$observed - g$predicted)^2, u, mean)
      ae <- tapply(abs(g$observed - g$predicted), u, mean)
      out[[length(out) + 1]] <- data.frame(split = m, fold = 0, weighting = paste0(unit, "-weighted (each ", unit, " once)"),
                                           n = length(se), RMSE = sqrt(mean(se)), MAE = mean(ae), R2_out_of_sample = NA_real_,
                                           check.names = FALSE)
    }
  }
  do.call(rbind, out)
}
# AUD135-02: selection frequencies over the DECLARED pool (index / key / label from the search setup, never from
# stability.csv), denominators = committed draws / successful draws, sign stability and type-7 percentiles of the
# estimates of the draws that selected the candidate; failed draws are never zeros
sx_pool <- data.frame(index = as.numeric(sx_val_index), key = as.character(sx_val_keys),
                      label = as.character(sx_val_labels), stringsAsFactors = FALSE)
sx_q <- function(e, p) if (length(e)) stats::quantile(e, p, type = 7, names = FALSE) else NA_real_
sx_stability <- function(B) {
  if (is.null(B) || !nrow(B)) return(NULL)
  ok <- B[B$status == "fitted", , drop = FALSE]; att <- nrow(B); nok <- nrow(ok)
  do.call(rbind, lapply(seq_len(nrow(sx_pool)), function(j) {
    sel <- ok[!is.na(ok$selected_index) & as.numeric(ok$selected_index) == sx_pool$index[j], , drop = FALSE]
    est <- suppressWarnings(as.numeric(sel$estimate)); est <- est[!is.na(est)]
    data.frame(candidate_index = sx_pool$index[j], candidate_key = sx_pool$key[j], candidate = sx_pool$label[j],
               selected = nrow(sel), attempted = att, successful = nok,
               freq_of_attempted = if (att) nrow(sel) / att else NA_real_,
               freq_of_successful = if (nok) nrow(sel) / nok else NA_real_,
               flagged_fits = sum(as.character(sel$diagnostics) != "clean"),
               coefficient = if (nrow(sel)) sx_coef_display(sel$coefficient[1]) else "",
               positive_sign = if (length(est)) mean(est > 0) else NA_real_, `estimate_p2.5` = sx_q(est, 0.025),
               estimate_median = if (length(est)) stats::median(est) else NA_real_, `estimate_p97.5` = sx_q(est, 0.975),
               check.names = FALSE, stringsAsFactors = FALSE)
  }))
}
sx_estimands <- function(B, C) {
  if (is.null(C) || !nrow(C)) return(NULL)
  ok <- B[B$status == "fitted", , drop = FALSE]
  g <- unique(C[, c("selected_index", "coefficient")])
  do.call(rbind, lapply(seq_len(nrow(g)), function(j) {
    ix <- as.numeric(g$selected_index[j]); cf <- g$coefficient[j]
    r <- C[as.numeric(C$selected_index) == ix & C$coefficient == cf, , drop = FALSE]
    est <- suppressWarnings(as.numeric(r$estimate)); est <- est[!is.na(est)]
    data.frame(candidate_index = ix, candidate = sx_pool$label[match(ix, sx_pool$index)], term = r$term[1],
               coefficient = cf, coefficient_label = sx_coef_display(cf),
               draws_selected = sum(!is.na(ok$selected_index) & as.numeric(ok$selected_index) == ix),
               draws_with_estimate = length(est), positive_sign = if (length(est)) mean(est > 0) else NA_real_,
               `estimate_p2.5` = sx_q(est, 0.025), estimate_median = if (length(est)) stats::median(est) else NA_real_,
               `estimate_p97.5` = sx_q(est, 0.975), check.names = FALSE, stringsAsFactors = FALSE)
  }))
}
# coefficient identity: every coefficient row belongs to a fitted draw of the same selected candidate, with the
# declared key, one term per (candidate, coefficient), and n_coef rows per draw
sx_coef_identity <- function(B, C) {
  if (is.null(C) || !nrow(C)) return(is.null(B) || !nrow(B) || all(as.numeric(B$n_coef[B$status == "fitted"]) == 0))
  ok <- B[B$status == "fitted", , drop = FALSE]; i <- match(C$b, ok$b)
  if (anyNA(i) || any(as.numeric(C$selected_index) != as.numeric(ok$selected_index[i]))) return(FALSE)
  if (any(C$selected_key != sx_pool$key[match(as.numeric(C$selected_index), sx_pool$index)])) return(FALSE)
  terms <- tapply(C$term, paste(C$selected_index, C$coefficient), function(t) length(unique(t)))
  n <- table(factor(C$b, levels = ok$b))
  all(terms == 1) && all(as.numeric(n) == as.numeric(ok$n_coef))
}
sx_realized <- function(M) {
  if (is.null(M) || !nrow(M)) return(NULL)
  unit <- if (sx_target == "rows") as.character(M$row_id) else if (sx_target == "cluster") sx_unit_clus(M$row_id) else
    sx_unit_part(M$row_id)
  out <- list()
  for (s in sx_plan_splits$split) {
    w <- M$split == s; f <- as.numeric(M$fold[w]); u <- unit[w]; md <- sx_plan_splits$mode[sx_plan_splits$split == s]
    n_all <- if (sx_target == "rows") length(u) else length(unique(u))
    for (k in sort(unique(f[f > 0]))) {
      te <- f == k; nu <- if (sx_target == "rows") sum(te) else length(unique(u[te]))
      out[[length(out) + 1]] <- data.frame(split = s, mode = md, fold = k,
        requested_fraction = if (md == "holdout") sx_val_cfg$holdout_fraction else 1 / sx_val_cfg$k,
        test_units = nu, units = n_all, realized_unit_fraction = if (n_all) nu / n_all else NA_real_,
        test_rows = sum(te), rows = length(f), realized_row_fraction = if (length(f)) sum(te) / length(f) else NA_real_,
        rule = sx_plan_splits$rule[sx_plan_splits$split == s], stringsAsFactors = FALSE)
    }
  }
  do.call(rbind, out)
}

res <- list()
add <- function(id, expected, actual) res[[length(res) + 1L]] <<- data.frame(test = id, expected = as.character(expected),
  actual = as.character(actual), status = if (identical(as.character(expected), as.character(actual))) "PASS" else "FAIL")
add("NUM-01 identical finite", TRUE, sx_num_ok(1, 1, 1e-6, 1e-6))
add("NUM-02 different finite", FALSE, sx_num_ok(1, 2, 1e-6, 1e-6))
add("NUM-03 both missing", TRUE, sx_num_ok(NA_real_, NA_real_, 1e-6, 1e-6))
add("NUM-04 same positive infinity", TRUE, sx_num_ok(Inf, Inf, 1e-6, 1e-6))
add("NUM-05 same negative infinity", TRUE, sx_num_ok(-Inf, -Inf, 1e-6, 1e-6))
add("NUM-06 opposite infinities", FALSE, sx_num_ok(-Inf, Inf, 1e-6, 1e-6))
add("NUM-07 finite versus infinity", FALSE, sx_num_ok(1, Inf, 1e-6, 1e-6))
add("NUM-08 invalid text versus missing", FALSE, sx_num_ok("corrupted", NA_real_, 1e-6, 1e-6))
add("NUM-09 both invalid numeric text", FALSE, sx_num_ok("bad", "bad", 1e-6, 1e-6))
utils::write.csv(data.frame(id = "1", participant = "001"), "app.csv", row.names = FALSE)
spec <- list(keys = "id", cols = data.frame(name = c("id", "participant"), type = c("int", "text"), flags = c("", ""),
             stringsAsFactors = FALSE))
sx_chk <- sx_chk[0, ]
sx_compare("identity", "app.csv", data.frame(id = 1L, participant = "1"), spec)
add("ID-01 numeric-looking string identity", "FAIL", sx_chk$status[sx_chk$check == "identity: participant"])
add("SEL-01 underflowed ordinary p distinct log tails", 2L, sx_select_min(c(-434, -651) * log(10)))
add("SEL-02 true tie", 1L, sx_select_min(c(-5, -5)))
add("SEL-03 withheld test rejected", TRUE, is.na(sx_primary_logp(list(status = "ok", tests = list(list(log_p = -5, withheld = "negative LR"))))))
# extra controls
add("X-01 decimal overflow is malformed", "bad", sx_parse_num("1e999")$state)
add("X-02 silent underflow is malformed", "bad", sx_parse_num("1e-400")$state)
add("X-03 subnormal is a number", "num", sx_parse_num("5e-324")$state)
add("X-04 NaN text is malformed", "bad", sx_parse_num("NaN")$state)
add("X-05 hex text is malformed", "bad", sx_parse_num("0x10")$state)
add("X-06 reproduced NaN is malformed", FALSE, sx_num_ok(NaN, NaN, 1e-6, 1e-6))
add("X-07 missing not allowed by the field", FALSE, sx_num_ok("", NA_real_, 1e-6, 1e-6, missing = FALSE))
add("X-08 infinity not allowed by the field", FALSE, sx_num_ok("Inf", Inf, 1e-6, 1e-6, inf = FALSE))
add("X-09 integer text 007 vs 7", FALSE, sx_int_ok("007", 7))
add("X-10 integer 7 vs 7", TRUE, sx_int_ok("7", 7))
add("X-11 non-integer reproduced count", FALSE, sx_int_ok("2", 2.5))
add("X-12 delimiter-collision keys differ", TRUE, length(unique(sx_key(data.frame(a = c("a|b", "a"), b = c("c", "b|c")),
                                                          c("a", "b"), c("text", "text")))) == 2L)
add("X-13 empty vs literal NA text", FALSE, sx_text_ok("NA", ""))
add("X-14 Unicode text exact", TRUE, sx_text_ok(enc2utf8("Z\u00fcrich \u00d7"), "Z\u00fcrich \u00d7"))
sx_chk <- sx_chk[0, ]
sx_add_chk("indeterminate", NA)
sx_add_chk("declared n/a", FALSE, applicable = FALSE)
sx_add_chk("vector", c(TRUE, TRUE))
add("X-15 NA comparison is FAIL", "FAIL", sx_chk$status[1])
add("X-16 NOT APPLICABLE only when declared", "NOT APPLICABLE", sx_chk$status[2])
add("X-17 a vector is not a pass", "FAIL", sx_chk$status[3])
tab <- do.call(rbind, res)
utils::write.csv(tab, "diagnostic_results.csv", row.names = FALSE)
print(tab[tab$status != "PASS", ])
cat("DIAG", sum(tab$status == "PASS"), "of", nrow(tab), "\n")
