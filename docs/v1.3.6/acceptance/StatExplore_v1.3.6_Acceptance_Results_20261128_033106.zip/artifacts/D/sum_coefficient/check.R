# ==== StatExplore AMD validation: complete reproduction ====
# Run from the exported folder (Rscript validation_reproduce.R). It needs the data file named in the data-load
# section and verifies its results against the CSV files StatExplore exported (same folder).

sx_long <- function() FALSE
sx_disc_has_cluster <- FALSE
sx_val_index <- c(0); sx_val_keys <- c("candidate0"); sx_val_labels <- c("candidate 0")
sx_val_full <- data.frame(y = 1:20, row.names = as.character(1:20))
sx_alias <- character()

sx_rep_pred <- list(); sx_rep_folds <- list(); sx_rep_boot <- list(); sx_rep_coef <- list()
sx_rep_trace <- list(); sx_rep_man <- list(); sx_rep_draws <- list()
# ---- committed chunk 1 ----
sx_vfold <- NULL; sx_vdraws <- NULL; sx_vr <- NULL
sx_result <- list(boot = list(draws = data.frame(`b` = c(1.0, 2.0), `status` = c("fitted", "fitted"), `reason` = c("", ""), `selected` = c("candidate 0", "candidate 0"), `selected_index` = c(0.0, 0.0), `selected_key` = c("candidate0", "candidate0"), `train_score` = c(-2.0, -3.0), `visited` = c(1.0, 1.0), `scored` = c(1.0, 1.0), `n_sig_train` = c(1.0, 1.0), `coefficient` = c("beta", "beta"), `estimate` = c(1.0, 3.0), `n_coef` = c(1.0, 1.0), `diagnostics` = c("clean", "clean"), `flags` = c("", ""), `n` = c(20.0, 20.0), `groups` = c(20.0, 20.0), stringsAsFactors = FALSE, check.names = FALSE), coefs = data.frame(`b` = c(1.0, 2.0), `selected_index` = c(0.0, 0.0), `selected_key` = c("candidate0", "candidate0"), `term` = c("beta", "beta"), `coefficient` = c("beta", "beta"), `estimate` = c(1.0, 3.0), stringsAsFactors = FALSE, check.names = FALSE)))
if (!is.null(sx_vfold)) sx_rep_man[[length(sx_rep_man) + 1]] <- data.frame(split = sx_vr$folds$split[1],
  row_id = as.integer(names(sx_vfold)), fold = unname(sx_vfold), stringsAsFactors = FALSE)
if (!is.null(sx_vdraws)) sx_rep_draws[[length(sx_rep_draws) + 1]] <- data.frame(b = sx_vdraws$b,
  position = stats::ave(seq_along(sx_vdraws$b), sx_vdraws$b, FUN = seq_along), row_id = sx_vdraws$row_id,
  draw_participant = sx_vdraws$draw_gid, draw_cluster = sx_vdraws$draw_cluster, stringsAsFactors = FALSE)
if (!is.null(sx_result$predictions)) sx_rep_pred[[length(sx_rep_pred) + 1]] <- sx_result$predictions
if (!is.null(sx_result$folds)) sx_rep_folds[[length(sx_rep_folds) + 1]] <- sx_result$folds
if (!is.null(sx_result$trace)) sx_rep_trace[[length(sx_rep_trace) + 1]] <- sx_result$trace
if (!is.null(sx_result$boot)) { sx_rep_boot[[length(sx_rep_boot) + 1]] <- sx_result$boot$draws
  if (!is.null(sx_result$boot$trace)) sx_rep_trace[[length(sx_rep_trace) + 1]] <- sx_result$boot$trace
  if (!is.null(sx_result$boot$coefs)) sx_rep_coef[[length(sx_rep_coef) + 1]] <- sx_result$boot$coefs }
sx_bind <- function(x) if (length(x)) do.call(rbind, x) else NULL
sx_P <- sx_bind(sx_rep_pred); sx_F <- sx_bind(sx_rep_folds); sx_B <- sx_bind(sx_rep_boot)
sx_C <- sx_bind(sx_rep_coef); sx_T <- sx_bind(sx_rep_trace); sx_M <- sx_bind(sx_rep_man); sx_D <- sx_bind(sx_rep_draws)
if (!is.null(sx_P)) utils::write.csv(sx_P, "reproduced_predictions.csv", row.names = FALSE)
if (!is.null(sx_F)) utils::write.csv(sx_F, "reproduced_folds.csv", row.names = FALSE)
if (!is.null(sx_B)) utils::write.csv(sx_B, "reproduced_bootstrap.csv", row.names = FALSE)
if (!is.null(sx_C)) utils::write.csv(sx_C, "reproduced_coefficients.csv", row.names = FALSE)
if (!is.null(sx_T)) utils::write.csv(sx_T, "reproduced_trace.csv", row.names = FALSE)
# ---- declarations embedded by StatExplore (independent of the exported files under test) ----
sx_schema <- list(
  manifest = list(keys = c("split", "row_id"), status_ok = NULL, cols = data.frame(name = c("split", "mode", "repeat", "row_id", "participant", "cluster", "fold"), type = c("text", "text", "int", "int", "text", "text", "int"), flags = c("", "", "", "", "", "", ""), stringsAsFactors = FALSE)),
  draws = list(keys = c("b", "position"), status_ok = NULL, cols = data.frame(name = c("b", "position", "row_id", "draw_participant", "draw_cluster", "original_participant", "original_cluster"), type = c("int", "int", "int", "text", "text", "text", "text"), flags = c("", "", "", "", "", "", ""), stringsAsFactors = FALSE)),
  predictions = list(keys = c("split", "fold", "row_id"), status_ok = NULL, cols = data.frame(name = c("split", "fold", "row_id", "observed", "predicted", "participant", "cluster"), type = c("text", "int", "int", "num", "num", "text", "text"), flags = c("", "", "", "tol=tol", "tol=tol", "", ""), stringsAsFactors = FALSE)),
  folds = list(keys = c("split", "fold"), status_ok = "scored", cols = data.frame(name = c("split", "fold", "status", "reason", "selected", "selected_index", "selected_key", "train_score", "visited", "scored", "n_sig_train", "n_train", "n_test", "train_mean", "train_groups", "test_groups", "train_clusters", "test_clusters", "excluded_incomplete", "excluded_unseen_levels", "excluded_unpredicted", "test_events", "diagnostics", "mode", "repeat"), type = c("text", "int", "text", "text", "text", "int", "text", "num", "int", "int", "int", "int", "int", "num", "int", "int", "int", "int", "int", "int", "int", "int", "text", "text", "int"), flags = c("", "", "", "", "", "na need=scored", "", "na inf tol=fit", "na", "na", "na", "", "", "na need=scored tol=tol", "na", "na", "na", "na", "na", "na", "na", "na", "", "", ""), stringsAsFactors = FALSE)),
  performance = list(keys = c("split", "fold", "weighting"), status_ok = NULL, cols = data.frame(name = c("split", "fold", "weighting", "n"), type = c("text", "int", "text", "int"), flags = c("", "", "", ""), stringsAsFactors = FALSE)),
  bootstrap = list(keys = c("b"), status_ok = "fitted", cols = data.frame(name = c("b", "status", "reason", "selected", "selected_index", "selected_key", "train_score", "visited", "scored", "n_sig_train", "coefficient", "estimate", "n_coef", "diagnostics", "flags", "n", "groups", "coefficient_label"), type = c("int", "text", "text", "text", "int", "text", "num", "int", "int", "int", "text", "num", "int", "text", "text", "int", "int", "text"), flags = c("", "", "", "", "na need=fitted", "", "na inf tol=fit", "na", "na", "na", "", "na tol=fit", "", "", "", "na need=fitted", "na need=fitted", ""), stringsAsFactors = FALSE)),
  coefs = list(keys = c("b", "selected_index", "coefficient"), status_ok = NULL, cols = data.frame(name = c("b", "selected_index", "selected_key", "term", "coefficient", "estimate"), type = c("int", "int", "text", "text", "text", "num"), flags = c("", "", "", "", "", "tol=fit"), stringsAsFactors = FALSE)),
  stability = list(keys = c("candidate_index"), status_ok = NULL, cols = data.frame(name = c("candidate_index", "candidate_key", "candidate", "selected", "attempted", "successful", "freq_of_attempted", "freq_of_successful", "flagged_fits", "coefficient", "positive_sign", "estimate_p2.5", "estimate_median", "estimate_p97.5"), type = c("int", "text", "text", "int", "int", "int", "num", "num", "int", "text", "num", "num", "num", "num"), flags = c("", "", "", "", "", "", "na tol=tight", "na tol=tight", "", "", "na tol=tight", "na tol=fit", "na tol=fit", "na tol=fit"), stringsAsFactors = FALSE)),
  estimands = list(keys = c("candidate_index", "coefficient"), status_ok = NULL, cols = data.frame(name = c("candidate_index", "candidate", "term", "coefficient", "coefficient_label", "draws_selected", "draws_with_estimate", "positive_sign", "estimate_p2.5", "estimate_median", "estimate_p97.5"), type = c("int", "text", "text", "text", "text", "int", "int", "num", "num", "num", "num"), flags = c("", "", "", "", "", "", "", "na tol=tight", "na tol=fit", "na tol=fit", "na tol=fit"), stringsAsFactors = FALSE)),
  trace = list(keys = c("part", "candidate_index"), status_ok = NULL, cols = data.frame(name = c("part", "candidate_index", "status", "reason", "loglik", "statistic", "df", "log_p", "reference_loglik", "aic", "score", "flags", "reference_flags", "rows_sig"), type = c("text", "int", "text", "text", "num", "num", "num", "num", "num", "num", "num", "text", "text", "text"), flags = c("", "", "", "", "na tol=fit", "na inf tol=fit", "na tol=fit", "na inf tol=fit", "na tol=fit", "na tol=fit", "na inf tol=fit", "", "", ""), stringsAsFactors = FALSE)),
  realized = list(keys = c("split", "fold"), status_ok = NULL, cols = data.frame(name = c("split", "mode", "fold", "requested_fraction", "test_units", "units", "realized_unit_fraction", "test_rows", "rows", "realized_row_fraction", "rule"), type = c("text", "text", "int", "num", "int", "int", "num", "int", "int", "num", "text"), flags = c("", "", "", "tol=tight", "", "", "na tol=tight", "", "", "na tol=tight", ""), stringsAsFactors = FALSE)),
  ledger = list(keys = c("part"), status_ok = NULL, cols = data.frame(name = c("part", "mode", "split", "fold", "b", "chunk", "status", "committed"), type = c("text", "text", "text", "int", "int", "int", "text", "bool"), flags = c("", "", "", "na", "na", "", "", ""), stringsAsFactors = FALSE)))
sx_expect <- data.frame(file = c("bootstrap_results.csv", "bootstrap_coefficients.csv", "stability.csv", "bootstrap_estimands.csv", "execution_ledger.csv"), required = c(TRUE, TRUE, TRUE, TRUE, TRUE), rows = c(2, 2, 1, 1, 2), applicable = c(TRUE, TRUE, TRUE, TRUE, TRUE), stringsAsFactors = FALSE)
sx_ledger <- data.frame(`part` = c("boot1", "boot2"), `mode` = c("bootstrap", "bootstrap"), `split` = c("", ""), `fold` = c(NA, NA), `b` = c(1, 2), `chunk` = c(1, 1), `status` = c("fitted", "fitted"), `committed` = c(TRUE, TRUE), stringsAsFactors = FALSE, check.names = FALSE)
sx_pend_M <- NULL   # planned, not committed (not replayed)
sx_pend_D <- NULL   # planned, not committed
sx_plan_splits <- data.frame(split = character(), mode = character(), `repeat` = numeric(), rule = character(), check.names = FALSE)
sx_val_cfg <- list(holdout_fraction = 0.2, k = 5)
sx_alias <- character()
sx_app_status <- "complete"
sx_binary <- FALSE
sx_target <- "rows"
if (sx_binary) sx_schema$performance$cols <- rbind(sx_schema$performance$cols, data.frame(name = c("log_loss", "Brier", "AUC"), type = "num", flags = "na tol=tol", stringsAsFactors = FALSE)) else sx_schema$performance$cols <- rbind(sx_schema$performance$cols, data.frame(name = c("RMSE", "MAE", "R2_out_of_sample"), type = "num", flags = "na tol=tol", stringsAsFactors = FALSE))

# ---- verification against the app's exported evidence (AUD134-11; typed and complete since v1.3.6, AUD135-01/02/04) ----
# Every check is listed in validation_check_results.csv (PASS / FAIL / NOT APPLICABLE); the script exits with status 1
# when any check fails. A check is NOT APPLICABLE only when the embedded declaration says so - an indeterminate or
# malformed comparison is a FAIL. Every evidence file is read as TEXT (no type guessing: "001" stays "001", the literal
# "NA" is text, "" is the declared missing value) and parsed by the declared field type embedded below (never inferred
# from the file under test). Numbers: finite / +Inf / -Inf / missing / malformed are distinct; signed infinities match
# only the same sign; malformed text never matches anything. Keys are length-prefixed UTF-8 (no delimiter collisions)
# and must be unique on both sides; missing / extra / duplicate rows fail.
# Values are recomputed from the reproduced fits - predictions, folds, draws, coefficients and trace by replaying the
# committed chunks; performance, stability (selection frequencies over the DECLARED candidate pool, sign stability,
# type-7 percentiles), estimands and realized sizes by independent R code from those reproduced values. The planned
# split / draw manifests and the execution ledger are metadata: verified against the plan embedded in this script.
# Tolerances: predictions / observed / metrics abs 1e-6 + rel 1e-6; log p, statistics, log-likelihoods, AIC and
# coefficient estimates abs 1e-6 + rel 1e-6 (optimizer-sensitive mixed-model fits: rel 1e-5); fractions abs 1e-12 +
# rel 1e-12; counts, statuses, indices, keys and text exact.
sx_chk <- data.frame(check = character(), status = character(), detail = character(), stringsAsFactors = FALSE)
sx_add_chk <- function(check, ok, detail = "", applicable = TRUE) {
  st <- if (identical(applicable, FALSE)) "NOT APPLICABLE" else if (length(ok) == 1L && isTRUE(ok)) "PASS" else "FAIL"
  sx_chk[nrow(sx_chk) + 1L, ] <<- list(check, st, as.character(detail)[1])
  invisible(st == "PASS")
}
sx_read <- function(f) if (file.exists(f)) utils::read.csv(f, colClasses = "character", na.strings = character(0),
  check.names = FALSE, encoding = "UTF-8", strip.white = FALSE, stringsAsFactors = FALSE) else NULL
sx_num_re <- "^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][+-]?[0-9]+)?$"
# state of each value: "num" (finite), "inf", "-inf", "na" (declared missing) or "bad" (malformed / NaN)
sx_parse_num <- function(x) {
  n <- length(x)
  if (is.numeric(x) || is.logical(x)) {
    x <- as.numeric(x)
    st <- ifelse(is.nan(x), "bad", ifelse(is.na(x), "na", ifelse(is.infinite(x), ifelse(x > 0, "inf", "-inf"), "num")))
    return(list(value = x, state = st))
  }
  x <- as.character(x); st <- rep("bad", n); val <- rep(NA_real_, n)
  st[is.na(x) | x == ""] <- "na"
  pinf <- !is.na(x) & x %in% c("Inf", "+Inf"); ninf <- !is.na(x) & x == "-Inf"
  st[pinf] <- "inf"; val[pinf] <- Inf; st[ninf] <- "-inf"; val[ninf] <- -Inf
  fin <- which(!is.na(x) & grepl(sx_num_re, x))
  if (length(fin)) {
    v <- suppressWarnings(as.numeric(x[fin])); nz <- grepl("[1-9]", sub("[eE].*$", "", x[fin]))
    good <- is.finite(v) & !(v == 0 & nz)            # decimal overflow / silent underflow to 0 are malformed
    st[fin[good]] <- "num"; val[fin[good]] <- v[good]
  }
  list(value = val, state = st)
}
# typed numeric equality: total (never NA); missing equals missing only if `missing`, infinities only same-sign if `inf`
sx_num_ok <- function(a, b, abs_tol, rel_tol, missing = TRUE, inf = TRUE) {
  p <- sx_parse_num(a); q <- sx_parse_num(b)
  if (length(p$state) != length(q$state)) return(FALSE)
  ok <- rep(FALSE, length(p$state))
  ok[p$state == "na" & q$state == "na"] <- isTRUE(missing)
  i <- p$state %in% c("inf", "-inf") & q$state %in% c("inf", "-inf")
  ok[i] <- isTRUE(inf) & p$state[i] == q$state[i]
  f <- p$state == "num" & q$state == "num"
  x <- p$value[f]; y <- q$value[f]; sc <- pmax(abs(x), abs(y), 1)
  ok[f] <- abs(x / sc - y / sc) <= abs_tol / sc + rel_tol * pmax(abs(x), abs(y)) / sc
  ok
}
sx_parse_int <- function(x) {
  if (is.numeric(x) || is.logical(x)) {
    x <- as.numeric(x)
    st <- ifelse(is.na(x) & !is.nan(x), "na", ifelse(!is.na(x) & is.finite(x) & x == round(x) & abs(x) <= 2^53, "int", "bad"))
    v <- rep(NA_character_, length(x)); v[st == "int"] <- sprintf("%.0f", x[st == "int"] + 0)
    return(list(value = v, state = st))
  }
  x <- as.character(x)
  st <- ifelse(is.na(x) | x == "", "na", ifelse(grepl("^-?(0|[1-9][0-9]{0,15})$", x), "int", "bad"))
  v <- rep(NA_character_, length(x)); v[st == "int"] <- x[st == "int"]
  list(value = v, state = st)
}
sx_int_ok <- function(a, b, missing = FALSE) {
  p <- sx_parse_int(a); q <- sx_parse_int(b)
  if (length(p$state) != length(q$state)) return(FALSE)
  ok <- p$state == "int" & q$state == "int" & p$value == q$value
  ok[is.na(ok)] <- FALSE
  ok | (p$state == "na" & q$state == "na" & isTRUE(missing))
}
sx_text_ok <- function(a, b) {     # exact UTF-8 text; a missing text value is "" (declared convention)
  a <- as.character(a); b <- as.character(b); if (length(a) != length(b)) return(FALSE)
  a[is.na(a)] <- ""; b[is.na(b)] <- ""
  enc2utf8(a) == enc2utf8(b)
}
sx_bool_ok <- function(a, b) {
  tx <- function(x) if (is.logical(x)) ifelse(is.na(x), "bad", ifelse(x, "TRUE", "FALSE")) else
    ifelse(as.character(x) %in% c("TRUE", "FALSE"), as.character(x), "bad")
  x <- tx(a); y <- tx(b); if (length(x) != length(y)) return(FALSE)
  x != "bad" & x == y
}
# length-prefixed composite key (no delimiter collision); integer keys canonical; missing / malformed keys stop
sx_key <- function(d, cols, types) {
  if (!nrow(d)) return(character())
  parts <- lapply(seq_along(cols), function(i) {
    x <- d[[cols[i]]]
    if (is.null(x)) stop("key column ", cols[i], " missing")
    if (types[i] == "int") { p <- sx_parse_int(x); if (any(p$state != "int")) stop("invalid integer key ", cols[i]); x <- p$value }
    else { x <- as.character(x); if (anyNA(x)) stop("missing key ", cols[i]); x <- enc2utf8(x) }
    paste0(nchar(x, type = "bytes"), ":", x, ";")
  })
  do.call(paste0, parts)
}
sx_empty <- function(cols) as.data.frame(stats::setNames(lapply(cols, function(i) character()), cols),
                                         stringsAsFactors = FALSE, check.names = FALSE)
sx_tol <- c(1e-6, 1e-6)
sx_tol_fit <- c(1e-6, if (sx_long()) 1e-5 else 1e-6)
sx_tol_tight <- c(1e-12, 1e-12)
# compare one exported evidence file with its reproduced / recomputed table, field by declared field
sx_compare <- function(name, file, rep, spec, skip = character()) {
  app <- sx_read(file)
  if (is.null(app)) return(invisible(sx_add_chk(paste0(name, ": file"), FALSE, paste("required file missing:", file))))
  cols <- spec$cols$name; types <- spec$cols$type; flags <- spec$cols$flags
  okc <- identical(names(app), cols)
  sx_add_chk(paste0(name, ": columns"), okc, if (okc) "the declared columns, in order" else
             paste("expected", paste(cols, collapse = ","), "got", paste(names(app), collapse = ",")))
  if (!okc) return(invisible(FALSE))
  if (is.null(rep)) rep <- sx_empty(cols)
  lack <- setdiff(setdiff(cols, skip), names(rep))
  if (length(lack)) return(invisible(sx_add_chk(paste0(name, ": reproduced columns"), FALSE,
                                                paste("not reproduced:", paste(lack, collapse = ", ")))))
  kt <- types[match(spec$keys, cols)]
  ka <- tryCatch(sx_key(app, spec$keys, kt), error = function(e) e)
  kr <- tryCatch(sx_key(rep, spec$keys, kt), error = function(e) e)
  if (inherits(ka, "error") || inherits(kr, "error"))
    return(invisible(sx_add_chk(paste0(name, ": keys"), FALSE, conditionMessage(if (inherits(ka, "error")) ka else kr))))
  sx_add_chk(paste0(name, ": unique keys (app)"), !anyDuplicated(ka), paste(sum(duplicated(ka)), "duplicate key(s)"))
  sx_add_chk(paste0(name, ": unique keys (reproduced)"), !anyDuplicated(kr), paste(sum(duplicated(kr)), "duplicate key(s)"))
  sx_add_chk(paste0(name, ": same rows"), length(ka) == length(kr) && setequal(ka, kr),
             sprintf("app %d, reproduced %d, only in app %d, only reproduced %d", length(ka), length(kr),
                     length(setdiff(ka, kr)), length(setdiff(kr, ka))))
  i <- match(kr, ka); k <- !is.na(i)
  A <- app[i[k], , drop = FALSE]; R <- rep[k, , drop = FALSE]
  st <- if (!is.null(spec$status_ok) && "status" %in% names(R)) as.character(R$status) else NULL
  for (j in seq_along(cols)) {
    col <- cols[j]
    if (col %in% c(spec$keys, skip)) next
    fl <- strsplit(flags[j], " ", fixed = TRUE)[[1]]
    na_ok <- "na" %in% fl; inf_ok <- "inf" %in% fl
    need <- sub("^need=", "", fl[startsWith(fl, "need=")]); tc <- sub("^tol=", "", fl[startsWith(fl, "tol=")])
    a <- A[[col]]; r <- R[[col]]
    res <- tryCatch(switch(types[j],
      text = sx_text_ok(a, r), int = sx_int_ok(a, r, na_ok), bool = sx_bool_ok(a, r),
      num = { tl <- if (identical(tc, "tight")) sx_tol_tight else if (identical(tc, "fit")) sx_tol_fit else sx_tol
              sx_num_ok(a, r, tl[1], tl[2], na_ok, inf_ok) },
      stop("unknown declared type ", types[j])), error = function(e) FALSE)
    if (length(need) && !is.null(st) && length(res) == length(st)) {
      present <- !(sx_parse_num(a)$state %in% c("na", "bad")) & !(sx_parse_num(r)$state %in% c("na", "bad"))
      res[st %in% need & !present] <- FALSE
    }
    d <- if (types[j] == "num") { x <- sx_parse_num(a)$value; y <- sx_parse_num(r)$value; dd <- abs(x - y)
           if (any(is.finite(dd))) sprintf("; max |difference| %.3g", max(dd[is.finite(dd)])) else "" } else ""
    sx_add_chk(paste0(name, ": ", col), length(res) == nrow(A) && all(res),
               paste0(sum(!res), " of ", length(res), " row(s) differ or are invalid", d))
  }
  invisible(TRUE)
}
# same label <=> same R group (identity mapping of the app's unit keys onto the analysed data's grouping)
sx_partition_ok <- function(labels, groups) {
  a <- as.character(labels); g <- as.character(groups)
  if (anyNA(a) || anyNA(g)) return(FALSE)
  pa <- paste0(nchar(a, type = "bytes"), ":", a, ";", g)
  length(unique(pa)) == length(unique(a)) && length(unique(a)) == length(unique(g))
}
sx_pos <- function(row_id) match(as.character(row_id), rownames(sx_val_full))
sx_unit_part <- function(row_id) { p <- sx_pos(row_id)
  if (sx_long()) as.character(sx_val_full$sx_gid)[p] else ifelse(is.na(p), NA_character_, as.character(row_id)) }
sx_unit_clus <- function(row_id) { p <- sx_pos(row_id)
  if (sx_long() && sx_disc_has_cluster) as.character(sx_val_full$sx_cluster)[p] else ifelse(is.na(p), NA_character_, "") }
sx_coef_display <- function(x) vapply(as.character(x), function(nm) {
  if (is.na(nm) || !nzchar(nm)) return("")
  out <- vapply(strsplit(nm, ":", fixed = TRUE)[[1]], function(p) {
    if (p %in% c("sx_time", "sx_timef")) return("Time")
    m <- regmatches(p, regexec("^(v[0-9]{3,})(.*)$", p))[[1]]
    if (length(m) == 3 && m[2] %in% names(sx_alias)) return(paste0(sx_alias[[m[2]]], if (nzchar(m[3])) paste0(" [", m[3], "]") else ""))
    p }, "", USE.NAMES = FALSE)
  paste(out, collapse = " × ")
}, "", USE.NAMES = FALSE)
sx_auc2 <- function(y, p) { n1 <- sum(y == 1); n0 <- sum(y == 0); if (n1 == 0 || n0 == 0) return(NA_real_)
  r <- rank(p); (sum(r[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0) }
sx_met <- function(y, p, b, binary) {
  if (binary) { q <- pmin(pmax(p, 1e-12), 1 - 1e-12)
    return(c(log_loss = -mean(y * log(q) + (1 - y) * log(1 - q)), Brier = mean((y - p)^2), AUC = sx_auc2(y, p))) }
  e <- y - p; den <- sum((y - b)^2)
  c(RMSE = sqrt(mean(e^2)), MAE = mean(abs(e)), R2_out_of_sample = if (den > 0) 1 - sum(e^2) / den else NA_real_)
}
# an independent R implementation of the app's aggregation (per fold; pooled observation-weighted; group-weighted)
sx_perf <- function(P, F, binary, target) {
  if (is.null(P) || !nrow(P)) return(NULL)
  F <- F[F$status == "scored", , drop = FALSE]
  P$base <- F$train_mean[match(paste(P$split, P$fold), paste(F$split, F$fold))]
  out <- list()
  for (k in unique(paste(P$split, P$fold))) {
    g <- P[paste(P$split, P$fold) == k, , drop = FALSE]
    out[[length(out) + 1]] <- data.frame(split = g$split[1], fold = g$fold[1], weighting = "fold", n = nrow(g),
                                         t(sx_met(g$observed, g$predicted, g$base, binary)), check.names = FALSE)
  }
  mode <- sub("[0-9]+$", "", P$split); unit <- if (target == "cluster") "cluster" else "participant"
  for (m in unique(mode)) {
    g <- P[mode == m, , drop = FALSE]
    out[[length(out) + 1]] <- data.frame(split = m, fold = 0, weighting = "observation-weighted (pooled rows)",
                                         n = nrow(g), t(sx_met(g$observed, g$predicted, g$base, binary)), check.names = FALSE)
    if (!binary && target != "rows") {
      u <- paste(g$split, g[[unit]]); se <- tapply((g$observed - g$predicted)^2, u, mean)
      ae <- tapply(abs(g$observed - g$predicted), u, mean)
      out[[length(out) + 1]] <- data.frame(split = m, fold = 0, weighting = paste0(unit, "-weighted (each ", unit, " once)"),
                                           n = length(se), RMSE = sqrt(mean(se)), MAE = mean(ae), R2_out_of_sample = NA_real_,
                                           check.names = FALSE)
    }
  }
  do.call(rbind, out)
}
# AUD135-02: selection frequencies over the DECLARED pool (index / key / label from the search setup, never from
# stability.csv), denominators = committed draws / successful draws, sign stability and type-7 percentiles of the
# estimates of the draws that selected the candidate; failed draws are never zeros
sx_pool <- data.frame(index = as.numeric(sx_val_index), key = as.character(sx_val_keys),
                      label = as.character(sx_val_labels), stringsAsFactors = FALSE)
sx_q <- function(e, p) if (length(e)) stats::quantile(e, p, type = 7, names = FALSE) else NA_real_
sx_stability <- function(B) {
  if (is.null(B) || !nrow(B)) return(NULL)
  ok <- B[B$status == "fitted", , drop = FALSE]; att <- nrow(B); nok <- nrow(ok)
  do.call(rbind, lapply(seq_len(nrow(sx_pool)), function(j) {
    sel <- ok[!is.na(ok$selected_index) & as.numeric(ok$selected_index) == sx_pool$index[j], , drop = FALSE]
    est <- suppressWarnings(as.numeric(sel$estimate)); est <- est[!is.na(est)]
    data.frame(candidate_index = sx_pool$index[j], candidate_key = sx_pool$key[j], candidate = sx_pool$label[j],
               selected = nrow(sel), attempted = att, successful = nok,
               freq_of_attempted = if (att) nrow(sel) / att else NA_real_,
               freq_of_successful = if (nok) nrow(sel) / nok else NA_real_,
               flagged_fits = sum(as.character(sel$diagnostics) != "clean"),
               coefficient = if (nrow(sel)) sx_coef_display(sel$coefficient[1]) else "",
               positive_sign = if (length(est)) mean(est > 0) else NA_real_, `estimate_p2.5` = sx_q(est, 0.025),
               estimate_median = if (length(est)) stats::median(est) else NA_real_, `estimate_p97.5` = sx_q(est, 0.975),
               check.names = FALSE, stringsAsFactors = FALSE)
  }))
}
sx_estimands <- function(B, C) {
  if (is.null(C) || !nrow(C)) return(NULL)
  ok <- B[B$status == "fitted", , drop = FALSE]
  g <- unique(C[, c("selected_index", "coefficient")])
  do.call(rbind, lapply(seq_len(nrow(g)), function(j) {
    ix <- as.numeric(g$selected_index[j]); cf <- g$coefficient[j]
    r <- C[as.numeric(C$selected_index) == ix & C$coefficient == cf, , drop = FALSE]
    est <- suppressWarnings(as.numeric(r$estimate)); est <- est[!is.na(est)]
    data.frame(candidate_index = ix, candidate = sx_pool$label[match(ix, sx_pool$index)], term = r$term[1],
               coefficient = cf, coefficient_label = sx_coef_display(cf),
               draws_selected = sum(!is.na(ok$selected_index) & as.numeric(ok$selected_index) == ix),
               draws_with_estimate = length(est), positive_sign = if (length(est)) mean(est > 0) else NA_real_,
               `estimate_p2.5` = sx_q(est, 0.025), estimate_median = if (length(est)) stats::median(est) else NA_real_,
               `estimate_p97.5` = sx_q(est, 0.975), check.names = FALSE, stringsAsFactors = FALSE)
  }))
}
# coefficient identity: every coefficient row belongs to a fitted draw of the same selected candidate, with the
# declared key, one term per (candidate, coefficient), and n_coef rows per draw
sx_coef_identity <- function(B, C) {
  if (is.null(C) || !nrow(C)) return(is.null(B) || !nrow(B) || all(as.numeric(B$n_coef[B$status == "fitted"]) == 0))
  ok <- B[B$status == "fitted", , drop = FALSE]; i <- match(C$b, ok$b)
  if (anyNA(i) || any(as.numeric(C$selected_index) != as.numeric(ok$selected_index[i]))) return(FALSE)
  if (any(C$selected_key != sx_pool$key[match(as.numeric(C$selected_index), sx_pool$index)])) return(FALSE)
  terms <- tapply(C$term, paste(C$selected_index, C$coefficient), function(t) length(unique(t)))
  n <- table(factor(C$b, levels = ok$b))
  all(terms == 1) && all(as.numeric(n) == as.numeric(ok$n_coef))
}
sx_realized <- function(M) {
  if (is.null(M) || !nrow(M)) return(NULL)
  unit <- if (sx_target == "rows") as.character(M$row_id) else if (sx_target == "cluster") sx_unit_clus(M$row_id) else
    sx_unit_part(M$row_id)
  out <- list()
  for (s in sx_plan_splits$split) {
    w <- M$split == s; f <- as.numeric(M$fold[w]); u <- unit[w]; md <- sx_plan_splits$mode[sx_plan_splits$split == s]
    n_all <- if (sx_target == "rows") length(u) else length(unique(u))
    for (k in sort(unique(f[f > 0]))) {
      te <- f == k; nu <- if (sx_target == "rows") sum(te) else length(unique(u[te]))
      out[[length(out) + 1]] <- data.frame(split = s, mode = md, fold = k,
        requested_fraction = if (md == "holdout") sx_val_cfg$holdout_fraction else 1 / sx_val_cfg$k,
        test_units = nu, units = n_all, realized_unit_fraction = if (n_all) nu / n_all else NA_real_,
        test_rows = sum(te), rows = length(f), realized_row_fraction = if (length(f)) sum(te) / length(f) else NA_real_,
        rule = sx_plan_splits$rule[sx_plan_splits$split == s], stringsAsFactors = FALSE)
    }
  }
  do.call(rbind, out)
}
# ---- required files (declared by the app from the validation's modes, embedded above) ----
for (i in seq_len(nrow(sx_expect))) {
  f <- sx_expect$file[i]
  if (!sx_expect$required[i]) { sx_add_chk(paste0("file ", f), TRUE, "not applicable to this validation", applicable = FALSE); next }
  ok <- file.exists(f)
  sx_add_chk(paste0("file ", f), ok, if (ok) "present" else "REQUIRED reference file missing")
  if (ok) { n <- nrow(sx_read(f)); sx_add_chk(paste0("file ", f, ": rows"), n == sx_expect$rows[i],
                                               sprintf("%d rows, expected %d", n, sx_expect$rows[i])) }
}
sx_has <- function(f) any(sx_expect$file == f & sx_expect$required)
# ---- execution scope (AUD135-04): the ledger, and replayed = committed ----
sx_compare("execution ledger", "execution_ledger.csv", sx_ledger, sx_schema$ledger)
sx_rep_parts <- c(if (!is.null(sx_F)) paste0(sx_F$split, ":fold", sx_F$fold), if (!is.null(sx_B)) paste0("boot", sx_B$b))
sx_rep_status <- c(if (!is.null(sx_F)) as.character(sx_F$status), if (!is.null(sx_B)) as.character(sx_B$status))
sx_com <- sx_ledger[sx_ledger$committed, , drop = FALSE]
sx_add_chk("replay scope: the replayed parts are exactly the committed parts", setequal(sx_rep_parts, sx_com$part) &&
           length(sx_rep_parts) == nrow(sx_com), sprintf("replayed %d, committed %d", length(sx_rep_parts), nrow(sx_com)))
sx_add_chk("replay scope: replayed statuses equal the committed statuses",
           identical(unname(sx_rep_status[match(sx_com$part, sx_rep_parts)]), as.character(sx_com$status)),
           "status of every committed part")
# ---- planned manifests: committed parts from the replayed chunk code, pending parts from the embedded plan ----
if (sx_has("split_manifest.csv")) {
  M <- rbind(if (!is.null(sx_M)) sx_M[, c("split", "row_id", "fold")], sx_pend_M)
  if (!is.null(M) && nrow(M)) {
    M$mode <- sx_plan_splits$mode[match(M$split, sx_plan_splits$split)]
    M$`repeat` <- sx_plan_splits$`repeat`[match(M$split, sx_plan_splits$split)]
  }
  sx_compare("split manifest", "split_manifest.csv", M, sx_schema$manifest, skip = c("participant", "cluster"))
  app <- sx_read("split_manifest.csv")
  if (!is.null(app) && nrow(app)) {
    sx_add_chk("split manifest: every row is an analysed row", !anyNA(sx_pos(app$row_id)), "row_id in the analysed data")
    sx_add_chk("split manifest: participant keys identify the analysed participants",
               sx_partition_ok(app$participant, sx_unit_part(app$row_id)), "same key <=> same participant in R")
    sx_add_chk("split manifest: cluster keys identify the analysed clusters",
               sx_partition_ok(app$cluster, sx_unit_clus(app$row_id)), "same key <=> same cluster in R")
    sx_M_all <- M
  } else sx_M_all <- NULL
} else sx_M_all <- NULL
if (sx_has("bootstrap_draws.csv")) {
  D <- rbind(if (!is.null(sx_D)) sx_D, sx_pend_D)
  sx_compare("bootstrap draw manifest", "bootstrap_draws.csv", D, sx_schema$draws,
             skip = c("original_participant", "original_cluster"))
  app <- sx_read("bootstrap_draws.csv")
  if (!is.null(app) && nrow(app)) {
    sx_add_chk("bootstrap draw manifest: every row is an analysed row", !anyNA(sx_pos(app$row_id)), "row_id")
    sx_add_chk("bootstrap draw manifest: original participant keys identify the analysed participants",
               sx_partition_ok(app$original_participant, sx_unit_part(app$row_id)), "same key <=> same participant")
    sx_add_chk("bootstrap draw manifest: original cluster keys identify the analysed clusters",
               sx_partition_ok(app$original_cluster, sx_unit_clus(app$row_id)), "same key <=> same cluster")
    man <- sx_read("split_manifest.csv")
    if (!is.null(man) && nrow(man)) {
      j <- match(app$row_id, man$row_id)
      sx_add_chk("bootstrap draw manifest: original keys equal the split manifest's keys of the same rows",
                 !anyNA(j) && identical(app$original_participant, man$participant[j]) &&
                   identical(app$original_cluster, man$cluster[j]), "cross-file identity")
    }
  }
}
# ---- reproduced results ----
if (sx_has("predictions.csv")) sx_compare("predictions", "predictions.csv", sx_P, sx_schema$predictions)
if (sx_has("folds.csv")) {
  Fr <- sx_F
  if (!is.null(Fr) && nrow(Fr)) { Fr$mode <- sx_plan_splits$mode[match(Fr$split, sx_plan_splits$split)]
    Fr$`repeat` <- sx_plan_splits$`repeat`[match(Fr$split, sx_plan_splits$split)] }
  sx_compare("folds", "folds.csv", Fr, sx_schema$folds)
}
if (sx_has("performance.csv"))
  sx_compare("performance (recomputed in R from the reproduced predictions)", "performance.csv",
             sx_perf(sx_P, sx_F, sx_binary, sx_target), sx_schema$performance)
if (sx_has("realized_sizes.csv"))
  sx_compare("realized sizes (recomputed from the verified plan and the analysed units)", "realized_sizes.csv",
             sx_realized(sx_M_all), sx_schema$realized)
if (sx_has("bootstrap_results.csv")) {
  Br <- sx_B
  if (!is.null(Br) && nrow(Br)) Br$coefficient_label <- sx_coef_display(Br$coefficient)
  sx_compare("bootstrap draws", "bootstrap_results.csv", Br, sx_schema$bootstrap)
}
if (sx_has("bootstrap_coefficients.csv")) {
  sx_compare("bootstrap coefficients", "bootstrap_coefficients.csv", sx_C, sx_schema$coefs)
  sx_add_chk("bootstrap coefficients: identity (draw, selected candidate, declared key, term, n_coef)",
             isTRUE(tryCatch(sx_coef_identity(sx_B, sx_C), error = function(e) FALSE)), "reproduced coefficients")
}
if (sx_has("stability.csv"))
  sx_compare("stability (recomputed from the reproduced draws and the declared pool)", "stability.csv",
             sx_stability(sx_B), sx_schema$stability)
if (sx_has("bootstrap_estimands.csv"))
  sx_compare("bootstrap estimands (recomputed from the reproduced coefficients)", "bootstrap_estimands.csv",
             sx_estimands(sx_B, sx_C), sx_schema$estimands)
if (sx_has("candidate_trace.csv")) sx_compare("candidate trace", "candidate_trace.csv", sx_T, sx_schema$trace)
utils::write.csv(sx_chk, "validation_check_results.csv", row.names = FALSE)
sx_fail <- sx_chk$status == "FAIL"
print(sx_chk[sx_chk$status != "PASS", , drop = FALSE], row.names = FALSE)
sx_n_plan <- nrow(sx_ledger); sx_n_com <- sum(sx_ledger$committed)
cat(sprintf("Execution coverage: %d of %d planned parts committed and replayed; %d not run; %d dispatched without a validated response (not reproducible).\n",
            sx_n_com, sx_n_plan, sum(sx_ledger$status == "not_run"), sum(sx_ledger$status == "uncommitted")))
if (any(sx_fail)) {
  msg <- paste0("VERIFICATION FAILED: ", sum(sx_fail), " of ", nrow(sx_chk), " checks (see validation_check_results.csv): ",
                paste(utils::head(sx_chk$check[sx_fail], 5), collapse = "; "))
  if (interactive()) stop(msg, call. = FALSE) else { message(msg); quit(save = "no", status = 1) }
}
if (!is.null(sx_P)) cat("Predictions reproduced:", nrow(sx_P), "held-out rows.\n")
if (!is.null(sx_B)) cat("Bootstrap selections reproduced:", nrow(sx_B), "draws.\n")
cat(sprintf("All %d checks passed (%d not applicable).\n", sum(sx_chk$status == "PASS"), sum(sx_chk$status == "NOT APPLICABLE")))
cat(if (identical(sx_app_status, "complete") && sx_n_com == sx_n_plan) "The complete validation was reproduced.\n" else
    paste0("The export is ", toupper(sx_app_status), ": only its ", sx_n_com, " committed part(s) of ", sx_n_plan,
           " planned were reproduced; this is not a reproduction of a complete validation.\n"))

